the program could be started like

java -jar ~/NetBeansProjects/manualEntry/dist/manualEntry.jar

The program will store a file called user.prop and the workoutsession named Training<date><time>.xml
in the current working directory. ManualEntry also accepts 1 commandline parameter specifing the directory
where to store the 2 files. I typically create the files at the SportsTracker working directory to keep
everything together.
For example

java -jar ~/NetBeansProjects/manualEntry/dist/manualEntry.jar $HOME/SportsTracker-5.1.0-bin/myData/


Version info:
Version 2.1 17-11-2010
- fix rounding error in max and avg pace

Version 2   10-11-2010
- added reading the complete previous saved training
- added default initalization for date and time
- added os dependend look and feel.

Version 1
- first version

Good luck Eric

