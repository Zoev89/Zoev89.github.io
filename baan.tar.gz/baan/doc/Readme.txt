Huidige gebruikte versie fltk is fltk-2.0.x-r6916
Voor het compileren van het baan programma de volgende environment variablen aanpassen
FLTK_PATH
Zet het volgende op het einde van de ~/.bashrc file
export FLTK_PATH=~/guiTool/fltk
Als je codelite gebruikt voor het bouwen neem dan
FLTK_PATH=$(HOME)/guiTool/fltk
op in de Settings->Environment Variables

Voor het starten van het baan programma moet ik weten waar
de baan.blk file staat hier voor dus 
BAAN_PATH
Zet het volgende op het einde van de ~/.bashrc file
export BAAN_PATH=/home/trein/ezb



