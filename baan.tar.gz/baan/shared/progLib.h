#ifndef PROGLIB_H_
#define PROGLIB_H_

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*PROGLIB_H_*/
