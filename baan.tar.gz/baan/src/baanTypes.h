// baanTypes.h : structures type for the hardware besturing
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_BAANTYPES_H)
#define _BAANTYPES_H

#include "baan.h"
#include "programDefines.h"
#include "baanSemaphore.h"
#include <fltk/Rectangle.h>

// Het aantal stop blokken per wissel; voor een drie weg wissel heb ik er 3 nodig
// Ik zou strikt genomen met 2 stopblokken kunnen volstaan bij een drieweg wissel,
// maar dan is er geen relatie welk stopblok voor welk baan vak gebruikt wordt.
#define AANTAL_BLOKS_PER_WISSEL 3


//#define MAX_AANTAL_AANVRAGEN  30
#define MAX_AANTAL_AANVRAGEN  40

#define NO_OF_TIMERS 20
// AANVRAAG_EVENT wordt gebruikt voor het opzetten van de timer
// als de user een timeout in de ioAanvraag heeft gezet
#define AANVRAAG_EVENT 1
#define AANVRAAG_CANCEL 2

// de minimale lengte van blok om mee telaten doen
// kleiner dan dit kan ik toch niet gebruiken om te stoppen
#define MIN_LENGTE 35

typedef struct
{
  pbaanSemaphore_t semWacht;
  int Aanvraag;			/* Zet deze op 1 voor een aanvraag van: */
  int NieuweRegelaar;		/* een nieuwe regelaar                  */
  int VerwijderRegelaar;	/* het verwijderen van een regelaar     */

  int RegelaarNummer;		/* Betreft welke regelaar */

  /*
   ** De volgende parameters zijn alleen van belang voor een 
   ** regelaar aanvraag
   **/
  int BlokNummer;
  int Lengte;
  int Richting;			/* 0 = vooruit 1 = terug */
  int NeemKopBlokMee;		/* 0 = wordt niet meegenomen (default) 1 = wel */
  int AanvraagAccept;		/* 0 = niet geaccepteerd  1 = geaccepteerd */
} RegelaarAanvraag_t;


// De volgoorde van de items in deze enum mag niet veranderd worden. Ik
// gebruik dat voor de seinen.
typedef enum
{
  SEIN_GROEN,
  SEIN_GEEL,
  SEIN_ROOD,
  // Tja eigenlijk niet in gebruik maar het kan handig
  // zijn om vanuit een gebruiker programma een sein code op te drukken die 
  // niet verdwijnt
  SEIN_VAST_GROEN,
  SEIN_VAST_GEEL,
  SEIN_VAST_ROOD,
} SeinState_t;

typedef enum
{
  GEEN_SEIN,
  ROOD_GROEN_SEIN,
  ROOD_GROEN_GEEL_SEIN
} blokSein_t;


typedef struct
{
  int DetectorCount;		/* counter die aangeeft hoevaak een detect al is geweest */

  // de hardware status
  int hardwareAdres;
  int hardwareState;
  int hardwareReturnWaarde;
  int nulWaarde;		// de waarde van de spanning als er niets in het blokzit (DC waarde)

  // Voor de state waarden zie de baanWT.h
  int State;			// het status van het blok in de database
  int Snelheid;
  int MaxSnelheid;		/* MaxSnelheid geeft de maximum snelheid voor dit blok op */
  int RegelaarNummer;		/* -1 is unused, -2 used of stopblok */

  blokSein_t blokSein;		// geeft aan wat voor een seinpaal er op dit blok staat

  SeinState_t seinState;	// de tijdelijke waarde die voor de hardware gebruikt wordt
  SeinState_t hardwareSeinState;	// de uiteindelijke waarde die voor de hardware gebruikt wordt
  // stop conditie op een blok
  // hier wordt het regelaar nummer in gestopt voor als die moet stoppen
  // default initializatie = -1
  // Door deze constructie kan ik met een functie alle stop settings
  // weghalen door te zoeken naar het regelaar nummer in het stop blok
  int Stop;			/* Trein moet stoppen */
  int Bovenleiding;		/* 1=bovenleiding 0=geen bovenleiding */

  int XCoord;
  int YCoord;

  int blokBelegt;		// voor het beleggen van blokken in user programmaas
  int blokBelegtRegelaar;	// om hem vrij te kunnen geven
} Blok_t;

enum
{
  VOLGENDBLOK,
  VORIGBLOK
};

typedef struct BlokPointer_t
{
  union
  {
    struct
    {
      BlokPointer_t *pVolgendBlok;
      BlokPointer_t *pVorigBlok;
    };
    BlokPointer_t *blokRicht[2];
  };
  Blok_t *pBlok;
  // In BlokIONummer staat de index in de blok of IO array
  // BlokIONummer wordt gebruikt voor opslag van de huidige status
  // van de baan. Ook wordt deze variabele gebruikt om te testen of
  // een blok/IO gebruikt is tijdens het controleren van de database
  int BlokIONummer;		// alleen voor opslag en restore werk -1 voor ongebruikt

  /* Blok types
   ** BAAN_BLOK   0 
   ** WISSEL_BLOK 1
   ** STOP_BLOK   2
   **/
  int BlokType;

  int Lengte;			/* lengte van een blok */
} BlokPointer_t;

/*
** Sorry maar er is geen andere mogelijkheid dan het hier
** tedoen.
**/
#include "regelaar.h"

typedef struct
{
  Regelaar Regel;
  int Gebruikt;
} Regel_t;

/*
** Sorry maar regelaar en workthread hebben deze beiden nodig
** Dus Blok_t en Blok_Pointer_t zijn in baan.h gedeclareed
** omdat regelaar.h en BaanWT.h vanelkaar afhankelijk zijn 
**/


typedef struct
{
  int IONummer;
  int stand;			// inwelke stand moet die of toggle
} IOAanvraag_t;


typedef struct
{
  int GeefVrijAanvraag;
  int BlokNummer;
} GeefVrijAanvraag_t;



/*
** Elke wissel, ontkoppelaar, sein zit hierin
**/
typedef struct
{
  /*
   ** 0 ongebruikt
   ** 1 ontkoppel rail
   ** 2 standaard wissel (recht of gebogen)
   ** 3 kruising zonder aandrijving
   ** 4 Engelse wissel
   ** 5 drieweg wissel
   ** 6 lampje
   **/
  int Type;

  BlokPointer_t StopBlokPointer[AANTAL_BLOKS_PER_WISSEL];
  Blok_t StopBlok[AANTAL_BLOKS_PER_WISSEL];

  int hardwareAdres;		// op welk basis adres zit de IO
  int hardwareBit;		// op welk bit is de IO opgeslagen
  int hardwareReturnWaarde;

  int Tijd;
  int TijdTeller;		/* counter zolang de spoel bekrachtigd word -1 is oneindig */
  int Stand;
    fltk::Rectangle rec;
  union
  {
    struct
    {
      int InactiefX1;
      int InactiefY1;
      int InactiefX2;
      int InactiefY2;
      int ActiefX1;
      int ActiefY1;
      int ActiefX2;
      int ActiefY2;
    } Ontkoppelaar;
    struct
    {
      int UitTijd;
      int aan;
      // de variablen hwAan hwTot hwType worden niet door
      // het programma gebruikt maar ik moet ze wel opslaan
      // om later een blok file te kunnen generen
      int hwAan;
      int hwTot;
      int hwType;
    } Lamp;
    struct
    {
      int Coord1X;
      int Coord1Y;
      int Coord2X;
      int Coord2Y;
      int Coord3X;
      int Coord3Y;
      BlokPointer_t *pBlok1;	/* altijd een baan blok */
      int Coord4X;
      int Coord4Y;
      int Richting;
      int MaxSnelheid12;
      int MaxSnelheid13;
      int MaxSnelheid14;
      int Lengte12;
      int Lengte13;
      int Lengte14;
      int Lengte42;
      int Lengte43;
    } Wissel;
  };
} IOBits_t;

typedef struct
{
  int Index;
  int VorigeStatus;
} HandRegelaar_t;

typedef struct
{
  SeinState_t SeinState;
  int richting;
  int snelheid;
  int returnWaarde;
  int detect;
} Simulatie_t;

typedef enum
{
  HW_BLOK,
  HW_IO
} hardwareBIO_t;

typedef struct
{
  hardwareBIO_t blokIO;
  int adres;			// -1 als het niet in gebruik is
  int data;
  // het nummer in de blok of wisselSpoelArray ook altijd invullen (ivm kortsluit test)!
  int nummer;
  int returnGewenst;
} hardwareArray_t;

typedef struct
{
  int aantal;
  hardwareArray_t array[MAX_MICRO_MEM_ALLOCATION];
} hardwareCom_t;

class ChardwareCom
{
  // PASOP de implementatie is niet reenterend!
  // nieuwItem en krijgItem kunnen wel van
  // twee processen gecalled worden
  // Construction
public:
  ChardwareCom ();		// constructor de ~ChardwareCom descructor is niet nodig
  int nieuwItem (hardwareArray_t * data);	// zet een nieuwItem in de array return 1 dan is die vol
  int krijgItem (hardwareArray_t * data);	// krijg het oudste item uit de array return 1 als leeg
  int aantalItems ();
protected:

private:
  int kop;			// kop wijst altijd naar een lege plek
  int staart;
  int maxLengte;
  hardwareArray_t array[MAX_AANTAL_AANVRAGEN];
};

typedef struct
{
  int event;
  int eventType;
  int regelaar;
  int flag;
  int ticks;
  int tickTime;
} baanTimer_t;

typedef struct
{
  pbaanSemaphore_t semCriticalSection;
  pbaanSemaphore_t semStarted;

  int StopExecution;
  int SleepTime;		// de tijd die we moeten wachten (typical 50 ms)

  // timers voor de gebruiker van het baan API
  int tickTimer;  // 100ms timer
  baanTimer_t timerArray[NO_OF_TIMERS];

  // handregelaar spul (oud)
  int Stop;			// als stop is dan worden de regelaars op nul gezet.
  // als de stop knop wordt ingedruk dan moeten we actie ondernemen.
  // Als die stopknop dan weer wordt ingedrukt mag de stop conditie
  // afgesloten worden.
  int vorigeStopStatus;

  // hetzelfde als de stop maar nu via het grafische interface
  int noodStop;

  int Achteruit;		// het achteruit commando
  int Vooruit;			// het vooruit commando

  // voor het versturen van data waarbij we alleen
  // geinteresseerd zijn in de recieve data van vorige keer
  // Helaas moet dit adres wel een gebruikt adres zijn
  int idleBlokCounter;

  // variablenen voor simulatie
  int Simulatie;
  // het memory van de centrale micro voor debuging
  short centraleMicroMem[2 * MAX_MICRO_MEM];
  // het memory van de controllers zelf
  Simulatie_t SimulatieArray[MAX_NOBLOKS];
  // Einde variabelen voor simulatie


  hardwareCom_t hardwareDetection;	// detection verzend data
  hardwareCom_t hardwareSnelheid;	// snelheid verzend data

  ChardwareCom hardwareHoog;	// hoge prioritijd IO afhandeling
  ChardwareCom hardwareLaag;	// lage prioritijd IO afhandeling

  pbaanSemaphore_t semWorkerThreadStopped;	// einde semaphore


  int AantalBlokken;
  int AantalSpoelen;

  Regel_t RegelArray[MAX_AANTAL_REGELAARS];


  BlokPointer_t BlokPointer[MAX_NOBLOKS];
  Blok_t Blok[MAX_NOBLOKS];
  Blok_t EindBlok;
  BlokPointer_t EindBlokPointer;

  IOBits_t IOBits[MAX_NOBLOKS];

  RegelaarAanvraag_t RegelaarAanvraag;
  GeefVrijAanvraag_t GeefVrijAanvraag;
  HandRegelaar_t HandRegelaar;

  // Voor een progress bar om te zien hoe het met de aanvraag array gesteld is
  int debugAantalItemsX;
  int debugAantalItemsY;

  // voor tijd debugging
  int tdwt;
  int tdaanStuur;
  int tdview;
  int tdglobal;
  int tdMessage;
  int tdDraw;

  // strings die met de view te maken hebben
  int tdOnBlokDisplay;
  int tdOnBlokClear;
  int tdOnTimerVerlopen;
  int tdOnInternalTimerVerlopen;
  int tdOnBlokEvent;
  int tdOnDraw;
  int tdOnMessage;

  int tdProgInternal;
  int tdProgBlok;
  int tdProgIO;
  int tdProgTimer;
  int tdProgMuis;
  int tdProgUserDefined;
} BaanInfo_t;




#endif // !defined(_BAANTYPES_H)
