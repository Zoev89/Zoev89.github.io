#include "baanView.h"
#include "baanDoc.h"
#include <fltk/draw.h>
#include <fltk/ask.h>
#include <fltk/events.h>
#include <fltk/damage.h>
#include "baanTypes.h"
#include "baanWT.h"
#include "globalVars.h"
#include <stdio.h>
#include <string.h>
#include "wissel.h"
#include "blok.h"
#include "td.h"
#include "blokInst.h"
#include "wisselInst.h"

baanView::baanView (int X, int Y, int W, int H, const char *L):
fltk::Widget (X, Y, W, H, L)
{
  baanViewMessage = baanQueueCreate (100, "viewMessage");
  if (baanViewMessage == NULL)
    {
      fltk::message ("Error creating baanViewMessage queue\n");
      exit (1);
    }
}

void
baanView::baanViewBlokXY (int blok, int x, int y)
{
  BlokDisplay (&baanInfo, blok, -1, BLOK_REMOVE, baanBitmap);
  baanInfo.Blok[blok].XCoord = x;
  baanInfo.Blok[blok].YCoord = y;
  BlokDisplay (&baanInfo, blok, -1, BLOK_CLEAR, baanBitmap);
}


int
baanView::handle (int event)
{
  int x, y, i;
  int key;

  static int vorigEvent, vorigKey, vorigX, vorigY;

  key = fltk::event_key ();
  x = fltk::event_x ();
  y = fltk::event_y ();
//  printf ("event %d %x %d %d\n", event, fltk::event_key (),
//        fltk::event_x (), fltk::event_y ());
  baanViewWin->make_current ();
  if (fltk::PUSH == event)
    {
      if (editMode)
        {
          // kijk eerst eens of we een blok selecteren
          if (selectedBlok)
            {
              int reset = selectedBlok;
              selectedBlok = 0;
              BlokDisplay (&baanInfo, reset, -1, BLOK_CLEAR, baanBitmap);
            }
          if (selectedWissel >= 0)
            {
              int reset = selectedWissel;
              selectedWissel = -1;
              selectedWisselPoint = -1;
              selectedWisselX = -1;
              selectedWisselY = -1;
              DisplayWissel (&baanInfo, reset, NULL);
            }

        }
      if (key == fltk::LeftButton)
        {
          baanDocLeftMouseButtonDown (x, y);
        }

      if (key == fltk::RightButton)
        {
          baanDocRightMouseButtonDown (fltk::event_x (), fltk::event_y ());
          if ((vorigEvent == fltk::RELEASE) && (vorigKey == key) &&
              (vorigX = x) && (vorigY == y))
            {
              if (selectedBlok)
                {
                  blokInst blokDlg;
                  char string[10];

                  baanDocSetWisselsDefault ();
                  blokDlg.blok->value (selectedBlok);
                  BlokNaam (string,
                            baanInfo.BlokPointer[selectedBlok].pVolgendBlok);
                  blokDlg.volgendBlok->value (string);
                  blokDlg.lengte->value (baanInfo.
                                         BlokPointer[selectedBlok].Lengte);
                  if (baanInfo.Blok[selectedBlok].MaxSnelheid != 1000)
                    {
                      blokDlg.maxSnelheid->value (baanInfo.Blok
                                                  [selectedBlok].MaxSnelheid);
                    }
                  else
                    {
                      blokDlg.maxSnelheid->value (-1);
                    }
                  blokDlg.bovenleiding->value (baanInfo.
                                               Blok[selectedBlok].Bovenleiding
                                               == 1);


                  switch (baanInfo.Blok[selectedBlok].blokSein)
                    {
                    case GEEN_SEIN:
                      blokDlg.sein->focus_index (0);
                      break;
                    case ROOD_GROEN_SEIN:
                      blokDlg.sein->focus_index (1);
                      break;
                    case ROOD_GROEN_GEEL_SEIN:
                      blokDlg.sein->focus_index (2);
                      break;
                    }
                  if (blokDlg.blokInstWindow->exec ())
                    {
                      if ((blokDlg.blok->ivalue () != selectedBlok)
                          || (strcmp (blokDlg.volgendBlok->value (), string)
                              != 0))
                        {
                          int nieuwBlok = blokDlg.blok->ivalue ();
                          BlokPointer_t *volgendBlok;
                          BlokPointer_t *vorigBlok;
                          volgendBlok =
                            baanInfo.BlokPointer[selectedBlok].pVolgendBlok;
                          if ((nieuwBlok > 0) && (nieuwBlok < MAX_NOBLOKS))
                            {
                              if (nieuwBlok != selectedBlok)
                                {
                                  if (baanInfo.
                                      BlokPointer[nieuwBlok].BlokIONummer !=
                                      -1)
                                    {
                                      fltk::message
                                        ("Het nieuwe blok %d is al bezet wijziging niet overgenomen",
                                         nieuwBlok);
                                      nieuwBlok = selectedBlok;
                                    }
                                }
                              // nieuwBlok wijst naar een correct blok
                              if (strcmp
                                  (blokDlg.volgendBlok->value (),
                                   string) != 0)
                                {
                                  char blokType[2];
                                  float adres;

                                  // volgend blok gewijzigd
                                  if (sscanf
                                      (blokDlg.volgendBlok->value (), "%1s%f",
                                       blokType, &adres) == 2)
                                    {
                                      volgendBlok =
                                        wisselKrijgPointer (&baanInfo,
                                                            blokType[0],
                                                            adres);
                                      if (volgendBlok == NULL)
                                        {
                                          fltk::message
                                            ("Het volgend blok bestaat niet %s",
                                             blokDlg.volgendBlok->value ());
                                          // wijziging ongedaan gemaakt
                                          volgendBlok =
                                            baanInfo.BlokPointer
                                            [selectedBlok].pVolgendBlok;
                                        }
                                    }
                                  else
                                    {
                                      fltk::message
                                        ("Het volgend blok voldoet niet aan de B/W/w %s",
                                         blokDlg.volgendBlok->value ());
                                      volgendBlok =
                                        baanInfo.BlokPointer
                                        [selectedBlok].pVolgendBlok;
                                    }
                                }

                              // Nu zijn volgendBlok en nieuwBlok altijd correcte dingen nu kunnen we gaan wijzigen
                              vorigBlok =
                                baanInfo.BlokPointer[selectedBlok].pVorigBlok;
                              BlokPrint (vorigBlok);
                              BlokDelete (&baanInfo.BlokPointer
                                          [selectedBlok]);
                              baanInfo.BlokPointer[nieuwBlok].pVolgendBlok =
                                volgendBlok;
                              baanInfo.BlokPointer[nieuwBlok].pVorigBlok =
                                vorigBlok;
                              BlokPrint (volgendBlok);
                              BlokPrint (vorigBlok);

                              BlokInsert (&baanInfo.BlokPointer[nieuwBlok]);
                              baanInfo.BlokPointer[nieuwBlok].BlokIONummer =
                                nieuwBlok;
                              baanInfo.Blok[nieuwBlok].XCoord =
                                baanInfo.Blok[selectedBlok].XCoord;
                              baanInfo.Blok[nieuwBlok].YCoord =
                                baanInfo.Blok[selectedBlok].YCoord;
                              if (selectedBlok != nieuwBlok)
                                {
                                  // update de wissels hun pBlok en kruising zijn schaduw blok
                                  for (i = 0; i < baanInfo.AantalSpoelen; i++)
                                    {
                                      WisselVeranderBlok (&baanInfo, i,
                                                          &baanInfo.BlokPointer
                                                          [selectedBlok],
                                                          &baanInfo.BlokPointer
                                                          [nieuwBlok]);
                                    }
                                }

                              selectedBlok = nieuwBlok;
                            }
                          else
                            {
                              fltk::message
                                ("Blok nummer %d niet binnen de range [1..%d]",
                                 nieuwBlok, MAX_NOBLOKS - 1);
                              nieuwBlok = selectedBlok;
                            }

                          baanViewWin->redraw ();

                        }
                      baanInfo.Blok[selectedBlok].blokSein =
                        (blokSein_t) blokDlg.sein->focus_index ();
                      baanInfo.BlokPointer[selectedBlok].Lengte =
                        blokDlg.lengte->ivalue ();
                      if (blokDlg.maxSnelheid->ivalue () > 0)
                        {
                          baanInfo.Blok[selectedBlok].MaxSnelheid =
                            blokDlg.maxSnelheid->ivalue ();
                        }
                      else
                        {
                          baanInfo.Blok[selectedBlok].MaxSnelheid = 1000;
                        }
                      baanInfo.Blok[selectedBlok].Bovenleiding =
                        blokDlg.bovenleiding->value ();



                    }

                }
              if (selectedWissel >= 0)
                {
                  baanDocSetWisselsDefault ();
                  {
                    wisselInst wisselDlg (selectedWissel);
                    if (wisselDlg.win->exec ())
                      {
                        WisselDialoogOk (&wisselDlg, selectedWissel);
                        baanViewWin->redraw ();
                      }
                  }
                }
            }

        }
      return true;
    }
  else if (fltk::DRAG == event)
    {
      if (key == fltk::RightButton)
        {
          if (selectedBlok)
            {
              baanViewBlokXY (selectedBlok, x - selectedOffsetX,
                              y - selectedOffsetY);
            }
          if (selectedWissel > -1)
            {
              // wisselNieuwXY werkt met verschil updates
              WisselNieuwXY (&baanInfo, selectedWissel, selectedOffsetX,
                             selectedOffsetY, x - selectedWisselX,
                             y - selectedWisselY);
              // onthoud het huidige punt 
              selectedWisselX = x;
              selectedWisselY = y;
            }
        }
    }
  else if (fltk::SHORTCUT == event)
    {
      switch (key)
        {
        case fltk::RightKey:
          if (selectedBlok)
            {
              baanViewBlokXY (selectedBlok,
                              baanInfo.Blok[selectedBlok].XCoord + 1,
                              baanInfo.Blok[selectedBlok].YCoord);
            }
          if (selectedWissel > -1)
            {
              WisselNieuwXY (&baanInfo, selectedWissel, selectedOffsetX,
                             selectedOffsetY, 1, 0);
            }
          break;
        case fltk::LeftKey:
          if (selectedBlok)
            {
              baanViewBlokXY (selectedBlok,
                              baanInfo.Blok[selectedBlok].XCoord - 1,
                              baanInfo.Blok[selectedBlok].YCoord);
            }
          if (selectedWissel > -1)
            {
              WisselNieuwXY (&baanInfo, selectedWissel, selectedOffsetX,
                             selectedOffsetY, -1, 0);
            }
          break;
        case fltk::UpKey:
          if (selectedBlok)
            {
              baanViewBlokXY (selectedBlok,
                              baanInfo.Blok[selectedBlok].XCoord,
                              baanInfo.Blok[selectedBlok].YCoord - 1);
            }
          if (selectedWissel > -1)
            {
              WisselNieuwXY (&baanInfo, selectedWissel, selectedOffsetX,
                             selectedOffsetY, 0, -1);
            }
          break;
        case fltk::DownKey:
          if (selectedBlok)
            {
              baanViewBlokXY (selectedBlok,
                              baanInfo.Blok[selectedBlok].XCoord,
                              baanInfo.Blok[selectedBlok].YCoord + 1);
            }
          if (selectedWissel > -1)
            {
              WisselNieuwXY (&baanInfo, selectedWissel, selectedOffsetX,
                             selectedOffsetY, 0, 1);
            }
          break;
        case fltk::DeleteKey:
          if (selectedBlok)
            {
              baanDocSetWisselsDefault ();
              BlokDelete (&baanInfo.BlokPointer[selectedBlok]);
              baanInfo.AantalBlokken -= 1;
              selectedBlok = 0;
              baanViewWin->redraw ();
            }
          if (selectedWissel >= 0)
            {
              baanDocSetWisselsDefault ();
              WisselDelete (selectedWissel);
              selectedWissel = -1;
              selectedWisselPoint = -1;
              baanViewWin->redraw ();
            }
        }
    }
  vorigEvent = event;
  vorigKey = key;
  vorigX = x;
  vorigY = y;

// return true if you used the event
  return Widget::handle (event);
}

int
baanView::loadBitmap (char *filename)
{
  baanBitmap = fltk::xpmFileImage::get (filename, 0);
  if (baanBitmap)
    {
      image (baanBitmap);
      {
        int w, h;
        baanBitmap->measure (w, h);
        resize (0, 0, w, h);
        baanWin->mainWindow->resize (5, 16, w + 16, h + 20);
      }
      return 0;
    }
  return 1;
}

void
baanViewVierkantDisplay (int xy, int lengteHoogte, int color)
{
  fltk::Rectangle rec;
  fltk::setcolor (color);
  rec.x (xy & 0xffff);
  rec.y (xy >> 16);
  rec.w (lengteHoogte & 0xffff);
  rec.h (lengteHoogte >> 16);
//  printf ("rect %d %d %d %d colo %d\n", rec.x (), rec.y (), rec.w (),
//        rec.h (), color);
  fltk::fillrect (rec);
  fltk::setcolor (0);
}


void
baanView::draw ()
{
  int dam, i;

  tdStart (baanInfo.tdDraw);

  dam = damage ();
//  printf("%x\n",dam);
  if (baanInfo.AantalBlokken == 0)
    return;
  if (fltk::DAMAGE_ALL & dam)
    {
      int color;
      draw_label ();            // update de bitmap
      if (baanInfo.Stop)
        color = fltk::RED;
      else
        color = fltk::GREEN;

      baanViewVierkantDisplay (baanInfo.EindBlok.XCoord +
                               (baanInfo.EindBlok.YCoord << 16),
                               RESET_SIZE + (RESET_SIZE << 16), color);


      for (i = 1; i < MAX_NOBLOKS; i++)
        {
          int regelaar, actie = BLOK_CLEAR;
          regelaar = baanInfo.Blok[i].RegelaarNummer;
          if (regelaar != -1)
            {
              if ((baanInfo.Blok[i].State == BLOK_ACHTERUITCHECK) ||
                  (baanInfo.Blok[i].State == BLOK_VOORUITCHECK))
                {
                  actie = BLOK_KOPBLOK;
                }
              else
                {
                  actie = BLOK_BELEG;
                }
            }
          else
            {
              if ((baanInfo.Blok[i].blokBelegt) &&
                  (baanInfo.Blok[i].blokBelegtRegelaar != -1))
                {
                  regelaar = baanInfo.Blok[i].blokBelegtRegelaar;
                  actie = BLOK_RESERVED;
                }
            }
          if (baanInfo.BlokPointer[i].BlokIONummer != -1)
            {
              BlokDisplay (&baanInfo, i, regelaar, actie, baanBitmap);
            }
        }
      for (i = 0; i < baanInfo.AantalSpoelen; i++)
        {
          DisplayWissel (&baanInfo, i, NULL);
        }
    }



  // restore default line style
  fltk::line_style (0);
  tdStop (baanInfo.tdDraw);

}


void
baanView::Update ()
{
  int i;

  baanViewWin->make_current ();
  fltk::push_matrix ();
  {
    int count = baanQueueCount (baanViewMessage);

    tdStart (baanInfo.tdview);
    for (i = 0; i < count; i++)
      {
        int buf[4];
        baanQueueReceive (baanViewMessage, buf);

        switch (buf[0])
          {
          case WM_WISSEL_DISPLAY:
            DisplayWissel (&baanInfo, buf[1], baanBitmap);
            break;
          case WM_BLOK_DISPLAY:
            BlokDisplay (&baanInfo, buf[1], buf[2], buf[3], baanBitmap);
            fltk::line_style (fltk::SOLID, 5);
            break;
          case WM_VIERKANT_DISPLAY:
            baanViewVierkantDisplay (buf[1], buf[2], buf[3]);
            break;
          case WM_BLOK_EVENT:
            int regelaar, event;
            tdValue (baanInfo.tdOnBlokEvent, 1);
            regelaar = buf[1];
            event = buf[2];
            // als event == -1 dan wordt het runnende programma gestopt
            if (baanInfo.RegelArray[regelaar].Regel.programRunning)
              {
                // programma wordt weer actief
                baanDocExecuteProgram (regelaar, BLOK, event);
              }
            else
              {
                if (event == -1)
                  {
                    baanDocStopProgram (regelaar);
                  }
              }
            break;
          case WM_INTERNALTIMER_VERLOPEN:
            regelaar = buf[1];
            event = buf[2];
            tdValue (baanInfo.tdOnInternalTimerVerlopen, event);
            baanDocExecuteProgram (regelaar, INTERNAL, event);
            break;

          case WM_TIMER_VERLOPEN:
            regelaar = buf[1];
            event = buf[2];
            tdValue (baanInfo.tdOnTimerVerlopen, event);
            baanDocExecuteProgram (regelaar, TIMER, event);
            break;

          }
      }
  }

  tdStop (baanInfo.tdview);

  // restore default line style
  fltk::line_style (0);
  fltk::pop_matrix ();

}
