#include <stdio.h>
#include <string.h>
#if defined(_WIN32)
# if !defined(__CYGWIN__)
#  include <direct.h>
# endif
# include <windows.h>
#else
# include <unistd.h>
#endif
#include <fltk/ask.h>
#include <fltk/damage.h>
#include "baanDoc.h"
#include "baanWT.h"
#include "baanMessage.h"
#include "baanThread.h"
#include "globalVars.h"
#include "leesdata.h"
#include "programma.h"
#include "kopRichting.h"
#include "lampInst.h"
#include "td.h"
#include "baanTreinen.h"
#include "blok.h"
#include "nieuwIo.h"
#include "foutStatistiek.h"
#include "errorPrint.h"

int baanDocParseBlkFile (FILE * file);
int BaanCheckBlokNummer (int Nummer, int max, char *Array);
void baanDocIniFile ();
static char iniFileName[MAX_FILENAME];
static char blkFileName[MAX_FILENAME];
static char iniBlkFileName[MAX_FILENAME];       // de orginele filename in de blk file
static char bitmapBlkFileName[MAX_FILENAME];    // de orginele filename in de blk file

static CProgramma globaalProg;
static CProgramma regelProg[MAX_AANTAL_REGELAARS];
static int treinenX, treinenY, treinenWidth, treinenHeight;

void
baanDocOpen (const char *doc)
{
  if (doc)
    {
      FILE *blkFile;


      blkFile = baanDocFileOpen (doc, "rb", blkDir, &blkName);

      if (blkFile)
        {
          strncpy (blkFileName, doc, MAX_FILENAME - 1);
          printf ("dir <%s>\n", blkDir);
          printf ("name <%s>\n", blkName);

          baanWin->mainWindow->label (blkName);
          if (baanDocParseBlkFile (blkFile) == 0)
            {
              printf ("Blk file opened\n");
              // blok file correct dus start het programma
              /*
               ** Begin the worker thread.
               ** First create the semaphores
               ** Then start the worker thread
               **/

              baanInfo.RegelaarAanvraag.semWacht = baanSemaphoreCreate (0);
              baanInfo.semCriticalSection = baanSemaphoreCreate (1);
              baanInfo.semStarted = baanSemaphoreCreate (0);

              if ((baanInfo.RegelaarAanvraag.semWacht == NULL) ||
                  (baanInfo.semCriticalSection == NULL))
                {
                  fltk::message ("Error creating semaphores");
                }
              else
                {
                  if (baanMessageHandlerInit ())
                    {
                      fltk::message ("Error starting messageHandler");
                    }
                  else
                    {
                      // start de treinbaan
                      baanWin->openItem->deactivate ();
                      baanWin->closeItem->activate ();
                      baanWin->mainWindow->redraw ();
                      if (0 == editMode)
                        {
                          baanInfo.semWorkerThreadStopped =
                            baanSemaphoreCreate (0);
                          if (baanInfo.semWorkerThreadStopped)
                            {
                              baanThreadCreate (1, BaanWorkerThreadProc,
                                                &baanInfo);
                              baanWin->trein->activate ();
                              // wacht tot de workthread gestart is
                              baanSemaphoreDown (baanInfo.semStarted);
                              baanDocIniFile ();
#ifndef _WIN32
                              // reset de root excess rights
                              // TODO creer de realtime trhead bij het starten en laat
                              // hem in leven. Dan kunnen we de root excess rights sneller reseten
                              setgid (getgid ());
                              setuid (getuid ());
#endif
                            }
                        }
                    }

                }
            }
          EricFgetsClose (blkFile);
          fclose (blkFile);
        }
      else
        {
          blkFileName[0] = 0;   // reset  filename
          fltk::message ("Error opening this file %s", doc);
        }
    }
}

void
baanDocSetWisselsDefault ()
{
  int i;
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      IOAanvraag_t IOAanvraag;
      IOAanvraag.stand = IOAANVRAAG_DEFAULT;
      IOAanvraag.IONummer = i;
      WisselAanvraag (&baanInfo, &IOAanvraag);
    }
}

void
baanDocSchrijfBlkFile ()
{
  int i;
  char string[200];

  // Eerst de wissels in de default stand zetten
  if (blkFileName[0] != 0)
    {
      FILE *blkFile;
      // er is een blk file
      blkFile = baanDocFileOpen (blkFileName, "wb", blkDir, &blkName);
      if (blkFile)
        {
          int w;

          baanDocSetWisselsDefault ();
          fprintf (blkFile, "# Version\n");
          fprintf (blkFile, "1\n");
          fprintf (blkFile, "# Bitmap filename\n");
          fprintf (blkFile, "%s\n", bitmapBlkFileName);
          fprintf (blkFile, "# ini filename\n");
          fprintf (blkFile, "%s\n", iniBlkFileName);
          fprintf (blkFile, "# global programma naam\n");
          fprintf (blkFile, "Programma = %s\n", globaalProg.programmaNaam);
          fprintf (blkFile, "# aantal blokken en spoelen\n");
          fprintf (blkFile, "%d %d\n", baanInfo.AantalBlokken,
                   baanInfo.AantalSpoelen);
          fprintf (blkFile,
                   "# positie van de regelaars in linker top x y en rechter bodem x y\n");
          fprintf (blkFile, "%d %d %d %d\n", regelaarTopX, regelaarTopY,
                   regelaarBotX, regelaarBotY);
          fprintf (blkFile,
                   "# positie van het treinen venster linker top x y en breedte hoogte\n");
          fprintf (blkFile, "%d %d %d %d\n", treinenX, treinenY, treinenWidth,
                   treinenHeight);
          fprintf (blkFile, "# coordinaten van het debug progress\n");
          fprintf (blkFile, "%d %d\n", baanInfo.debugAantalItemsX,
                   baanInfo.debugAantalItemsY);
          fprintf (blkFile, "# vooruit en terug commando voor deze baan\n");
          fprintf (blkFile, "%d %d\n", baanInfo.Vooruit, baanInfo.Achteruit);

          fprintf (blkFile, "# Nu het aantal blokken\n");
          fprintf (blkFile,
                   "# Nummer Volgend MaxSnelheid Lengte Boven Sein x    y\n");
          for (i = 1; i < MAX_NOBLOKS; i++)
            {
              if (baanInfo.BlokPointer[i].BlokIONummer != -1)
                {
                  // blok gebruikt
                  BlokPointer_t *volgend;
                  int MaxSnelheid;
                  volgend = baanInfo.BlokPointer[i].pVolgendBlok;
                  BlokNaam (string, volgend);
                  MaxSnelheid = baanInfo.Blok[i].MaxSnelheid;
                  if (1000 == MaxSnelheid)
                    {
                      MaxSnelheid = -1;
                    }
                  fprintf (blkFile, "%d %7s %3d %3d %d %d %4d %4d\n", i,
                           string, MaxSnelheid,
                           baanInfo.BlokPointer[i].Lengte,
                           baanInfo.Blok[i].Bovenleiding,
                           baanInfo.Blok[i].blokSein, baanInfo.Blok[i].XCoord,
                           baanInfo.Blok[i].YCoord);
                }
            }
          fprintf (blkFile, "# Nu het aantal ios\n");
          // schrijf de file weg in oplopende volgoorde leest makkelijk
          for (w = 1; w < LAATSTE_ENTRY; w++)
            {
              // Print eerste even wat voor een soort IO het is
              // Dat maakt de blk file makkelijker leesbaar
              switch (w)
                {
                case 1:
                  fprintf (blkFile, "# onkoppelaars\n");
                  break;
                case 2:
                  fprintf (blkFile, "# standaardWissel\n");
                  break;
                case 3:
                  fprintf (blkFile, "# kruising\n");
                  break;
                case 4:
                  fprintf (blkFile, "# engelseWissel\n");
                  break;
                case 5:
                  fprintf (blkFile, "# driewegWissel\n");
                  break;
                case 6:
                  fprintf (blkFile, "# lamp\n");
                  break;
                }
              for (i = 0; i < baanInfo.AantalSpoelen; i++)
                {
                  if (baanInfo.IOBits[i].Type == w)
                    {
                      WisselString (&baanInfo, i, string);
                      fprintf (blkFile, "%s\n", string);
                    }
                }
            }
          fclose (blkFile);


        }
    }
}

void
baanDocClose ()
{
  fltk::unlock ();

  if (baanInfo.StopExecution == 0)
    {
      int i;
      FILE *file;
      // stop de work thread
      baanInfo.StopExecution = 1;
      if (editMode)
        {
          baanDocSchrijfBlkFile ();

        }

      if (baanInfo.semWorkerThreadStopped)
        {
          baanSemaphoreDown (baanInfo.semWorkerThreadStopped);
        }
      // stop de messageHandler
      baanMessageHandlerStop ();
      baanSemaphoreDestroy (baanInfo.semWorkerThreadStopped);
      baanSemaphoreDestroy (baanInfo.RegelaarAanvraag.semWacht);
      baanInfo.RegelaarAanvraag.semWacht = NULL;        // zodat de regelaar er niet meer aankan

      // Nu slaan we de status op van de database
      if (0 == editMode)
        {
          // alleen als we in aansturingsmode zitten
          // slaan we de status op
          file = fopen (iniFileName, "wb");
          if (file != NULL)
            {
              fprintf (file, "#Version\n1\n");
              fprintf (file, "# Aantal spoelen\n");
              fprintf (file, "%d\n", baanInfo.AantalSpoelen);

              fprintf (file, "# Wissel info\n");
              /* Save de current wissel status */
              for (i = 0; i < baanInfo.AantalSpoelen; i++)
                {
                  int Stand;

                  if (WisselStand (&baanInfo, &Stand, i))
                    {
                      /* hier klopt iets niet we verlaten het saven */
                      i = baanInfo.AantalSpoelen;
                    }
                  else
                    {
                      IOBits_t *pWissel;
                      pWissel = &baanInfo.IOBits[i];

                      fprintf (file, "%d %7.2f %d\n",
                               pWissel->Type, WISSEL_ADRES, Stand);
                    }
                }

              fprintf (file, "# gebruikte regelaars\n");
              for (i = 0; i < MAX_AANTAL_REGELAARS; i++)
                {
                  if (baanInfo.RegelArray[i].Gebruikt)
                    {
                      BlokPointer_t *pBlok;
                      int richting, aantalBlokken, tegenRichting;
                      fprintf (file, "%s\n",
                               baanInfo.RegelArray[i].Regel.RegelaarFileName);
                      fprintf (file, "%d %d\n",
                               baanInfo.RegelArray[i].Regel.Richting,
                               baanInfo.RegelArray[i].Regel.Lengte);
                      // bepaal het aantal belegde blokken
                      richting = baanInfo.RegelArray[i].Regel.Richting;
                      tegenRichting = (richting + 1) & 1;
                      aantalBlokken = 1;
                      pBlok =
                        baanInfo.RegelArray[i].Regel.
                        pKopBlok->blokRicht[tegenRichting];
                      while ((pBlok->pBlok->State ==
                              (BLOK_VOORUIT + richting))
                             && (pBlok->pBlok->RegelaarNummer == i))
                        {
                          pBlok = pBlok->blokRicht[tegenRichting];
                          aantalBlokken += 1;
                        }
                      /* save welk blok het kop blok is + wat voor een type blok het is */
                      fprintf (file, "%d %d %d\n",
                               baanInfo.RegelArray[i].Regel.
                               pKopBlok->BlokType,
                               baanInfo.RegelArray[i].Regel.
                               pKopBlok->BlokIONummer, aantalBlokken);
                    }
                }
              fclose (file);
            }

          // De status van de baan is opgeslagen nu de regelaars verwijderen
          for (i = 0; i < MAX_AANTAL_REGELAARS; i++)
            {
              if (baanInfo.RegelArray[i].Gebruikt)
                {
                  // voordat we de regelaar opheffen zullen we eerst
                  // het programma stoppen
                  regelProg[i].unload ();
                  baanInfo.RegelArray[i].Regel.CleanUp ();
                }
            }
        }
      baanInfo.AantalBlokken = 0;
      baanInfo.AantalSpoelen = 0;

      baanDestroyTreinen ();
      ioOverzichtDestroy ();
      foutStatistiekDestroy ();
      baanOverzichtDestroy ();
      baanWin->openItem->activate ();
      baanWin->closeItem->deactivate ();
      baanWin->trein->deactivate ();
      baanWin->mainWindow->redraw ();
      errorPrintClose ();
    }
  fltk::lock ();

}

FILE *
baanDocFileOpen (const char *filename, const char *acces, char *dirName,
                 char **name)
{
  FILE *file;
  file = fopen (filename, acces);
  if (file)
    {
      char *p;
      // the file is there so start openening the rest
      strncpy (dirName, filename, MAX_FILENAME);
      p = strrchr (dirName, '/');
      if (p == NULL)
        {
          p = strrchr (dirName, '\\');
        }
      if (p)
        {
          const char *s;
          // split the full name into dir and name
          p[1] = 0;
          s = strrchr (filename, *p);
          strcpy (&p[2], &s[1]);
          *name = &p[2];
        }
      else
        {
          int len;
          // filename did not have a directory spec
          getcwd (dirName, MAX_FILENAME);
          len = strlen (dirName);
          dirName[len] = dirChar;
          dirName[len + 1] = 0;
          strncpy (&dirName[len + 2], filename, MAX_FILENAME - len - 2);
          *name = &dirName[len + 2];
        }
    }
  return file;
}

void
baanDocCleanUp ()
{
}

// copies the fullname into the output when the
// file can be opened.
// returns 0 on succes
int
baanDocFileName (char *output, char *input, char *dir)
{
  char temp[MAX_FILENAME];
  FILE *file;
  int len;

  // TODO add length error checking! 
  // gebruik geen strncpy want die add nullen aan het einde als source
  // kleiner is dan N

  // the input is a full path or a default name
  file = fopen (input, "rb");
  if (file)
    {
      // succesfull opened
      strcpy (output, input);
      fclose (file);
      return 0;
    }
  // check if we need to prefix it with the dir
  strcpy (temp, dir);
  len = strlen (dir);
  strcpy (&temp[len], input);
  file = fopen (temp, "rb");
  if (file)
    {
      strcpy (output, temp);
      fclose (file);
      return 0;
    }
  return 1;
}

int
baanDocParseBlkFile (FILE * file)
{
  char Array[MAX_FILENAME + 1];
  int i;
  long position;
  int lineCount;
  int version;

  baanDocCleanUp ();

  if (EricFgets (Array, MAX_FILENAME, file) == NULL)
    {
      fltk::message ("Regel %d: EOF Fout in lezen van het versie nummer",
                     EricFgetsGetLineCount (file));
      return 1;
    }
  if (sscanf (Array, "%d", &version) != 1)
    {
      fltk::message ("Regel %d: Kan het versie nummer niet lezen",
                     EricFgetsGetLineCount (file));
      return 1;
    }


  /*
   ** Lees de bitmap filename.
   **/
  if (EricFgets (Array, MAX_FILENAME, file) == NULL)
    {
      fltk::message
        ("Regel %d: Fout in lezen van bitmap filename van blok file",
         EricFgetsGetLineCount (file));
      return 1;
    }
  strcpy (bitmapBlkFileName, Array);  // save de korte naam en niet het gehele path
  if (baanDocFileName (Array, Array, blkDir))
    {
      fltk::message ("Regel %d: bitmap filename %s niet aanwezig",
                     EricFgetsGetLineCount (file), Array);
      return 1;
    }
  if (baanViewWin->loadBitmap (Array))
    {
      fltk::message ("Regel %d: bitmap file kan niet geladen worden",
                     EricFgetsGetLineCount (file));
      return 1;
    }


  /*
   ** Lees de ini filename
   **/
  if (EricFgets (Array, 200, file) == NULL)
    {

      errorPrint ("Regel %d: ini filename kan niet gelezen worden",
                  EricFgetsGetLineCount (file));
      return 1;
    }

  if ((':' == Array[1]) || ('/' == Array[0]) || ('\\' == Array[0]))
    {
      // a full path is specified
      strcpy (iniFileName, Array);
    }
  else
    {
      int len;
      strcpy (iniFileName, blkDir);
      len = strlen (blkDir);
      strcpy (&iniFileName[len], Array);
    }
  strcpy (iniBlkFileName, Array);

  //
  // Lees de global programma naam
  //
  if (EricFgets (globaalProg.programmaNaam, 200, file) == NULL)
    {
      errorPrint ("Regel %d: programma filename kan niet gelezen worden",
                  EricFgetsGetLineCount (file));
      return 1;
    }
  if (globaalProg.InitGlobal (&baanInfo))
    {
      errorPrint
        ("Regel %d: Het global programma %s kan niet geladen worden",
         EricFgetsGetLineCount (file), globaalProg.programmaNaam);
      return 1;
    }

  /*
   ** Lees het aantal blokken + het aantal wissel en 
   ** Ontkoppel spoelen
   **/
  if (EricFgets (Array, 200, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF Kan het aantal blokken en spoelen niet lezen",
         EricFgetsGetLineCount (file));
      return 1;
    }

  if (sscanf
      (Array, "%d%d", &baanInfo.AantalBlokken, &baanInfo.AantalSpoelen) != 2)
    {
      fltk::message ("Regel %d: Kan het aantal blokken en spoelen niet lezen",
                     EricFgetsGetLineCount (file));
      return 1;
    }
  if ((baanInfo.AantalBlokken < HARDWARE_MIN_ADRES) ||
      (baanInfo.AantalBlokken >= MAX_NOBLOKS))
    {
      fltk::message ("Regel %d: Incorrect aantal blokken %d [%d..%d]",
                     EricFgetsGetLineCount (file), baanInfo.AantalBlokken,
                     HARDWARE_MIN_ADRES, MAX_NOBLOKS);
      return 1;
    }
  if ((baanInfo.AantalSpoelen < 0) || (baanInfo.AantalSpoelen >= MAX_NOBLOKS))
    {
      fltk::message ("Regel %d: Incorrect aantal spoelen %d [%d..%d]",
                     EricFgetsGetLineCount (file), baanInfo.AantalBlokken,
                     HARDWARE_MIN_ADRES, MAX_NOBLOKS);
      return 1;
    }

  InitWorkThread (&baanInfo);

  // Lees de default positie van de regelaars
  if (EricFgets (Array, 200, file) == NULL)
    {
      fltk::message ("Regel %d: EOF Kan de regelaar positie niet lezen",
                     EricFgetsGetLineCount (file));
      return 1;
    }
  if (sscanf
      (Array, "%d%d%d%d", &regelaarTopX, &regelaarTopY, &regelaarBotX,
       &regelaarBotY) != 4)
    {
      fltk::message
        ("Regel %d: Verwacht Topx TopY en BottomX BottomY getallen",
         EricFgetsGetLineCount (file));
      return 1;
    }

  // Lees de grote van het lokomotieven venster
  if (EricFgets (Array, 200, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF Grote en plaats van het locomotieven venster niet lezen",
         EricFgetsGetLineCount (file));
      return 1;
    }
  if (sscanf
      (Array, "%d%d%d%d", &treinenX, &treinenY, &treinenWidth,
       &treinenHeight) != 4)
    {
      fltk::message
        ("Regel %d: Verwacht X Y en breedte hoogte van het locomotieven venster",
         EricFgetsGetLineCount (file));
      return 1;
    }

  if (0 == editMode)
    {
      baanCreateTreinen (treinenX, treinenY, treinenWidth, treinenHeight);
    }

  //
  // Lees het x y coordinaat van de progress
  //
  if (EricFgets (Array, 200, file) == NULL)
    {
      fltk::message ("Regel %d: EOF x en y van de progress bars niet lezen",
                     EricFgetsGetLineCount (file));
      return 1;
    }

  if (sscanf
      (Array, "%d%d", &baanInfo.debugAantalItemsX,
       &baanInfo.debugAantalItemsY) != 2)
    {
      fltk::message ("Regel %d: Verwacht X Y van de progress bars",
                     EricFgetsGetLineCount (file));
      return 1;
    }

  //
  // Lees de vooruit achteruit commandos
  //
  if (EricFgets (Array, 200, file) == NULL)
    {
      fltk::message ("Regel %d: EOF Verwacht vooruit achteruit commands",
                     EricFgetsGetLineCount (file));
      return 1;
    }

  if (sscanf (Array, "%d%d", &baanInfo.Vooruit, &baanInfo.Achteruit) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht twee getallen voor vooruit en achteruit commands",
         EricFgetsGetLineCount (file));
      return 1;
    }

  // onthoud de huidige positie!
  position = ftell (file);
  lineCount = EricFgetsGetLineCount (file);

  // scan de blok database om te zien welke blokken er gebruikt worden
  // daarna doen we de wissels. Pas als alle adressen bekend en goed gekeurd zijn
  // gaan we pas het echte initializatie werk doen.
  // In de blokdefinities kunnen ook wissels zitten en daar weten we het adres nog niet
  // van. Vandaar deze eerste scan actie
  for (i = 0; i < baanInfo.AantalBlokken; i++)
    {
      int Nummer;

      if (EricFgets (Array, 200, file) == NULL)
        {
          fltk::message ("Regel %d: End of file tijdens bloken lezen",
                         EricFgetsGetLineCount (file));
          return 1;
        }
      if (sscanf (Array, "%d", &Nummer) != 1)
        {
          fltk::message ("Regel %d: Incorrect blok string at index %d\n%s",
                         EricFgetsGetLineCount (file), i, Array);
          return 1;
        }
      if (BlokIsBlokNummer (Nummer) == 0)
        {
          fltk::message
            ("Regel %d: Blok %d niet binnen de range van 1 tot %d\n%s",
             EricFgetsGetLineCount (file), Nummer, MAX_NOBLOKS, Array);
          return 1;
        }
      // check ook of dit blok ook nieuw is
      if (baanInfo.BlokPointer[Nummer].BlokIONummer != -1)
        {
          fltk::message ("Regel %d: Blok %d bestaat al!\n%s",
                         EricFgetsGetLineCount (file), Nummer, Array);
          return 1;
        }

      baanInfo.BlokPointer[Nummer].BlokIONummer = Nummer;       // geeft aan dat die gebruikt is
    }

  //
  // Initializeer de wissel database met adres en subadres
  // pas als dat gebeurd is kunnen we de wissel gaan inlezen.
  // Het kan namelijk voorkomen dat twee wissel aanelkaar
  // zitten en dat dus een voorwaard referentie naar de andere wissel
  // nog niet gelezen is.
  //
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      int type, x;
      int hardwareAdres, hardwareBit;
      float adres;
      IOBits_t *pWissel;

      if (EricFgets (Array, 200, file) == NULL)
        {
          fltk::message ("Regel %d: End of file ben op %d verwacht %d",
                         EricFgetsGetLineCount (file), i,
                         baanInfo.AantalSpoelen);
          return 1;
        }
      if (sscanf (Array, "%d%f", &type, &adres) != 2)
        {
          fltk::message
            ("Regel %d: Probleem lezen van type adres van wissel %d\n%s",
             EricFgetsGetLineCount (file), i, Array);
          return 1;
        }
      hardwareAdres = (int) (adres + 0.5);
      hardwareBit = (int) ((adres - (float) hardwareAdres) * 100.0 + 0.5);
      if ((hardwareAdres < HARDWARE_MIN_ADRES) ||
          (hardwareAdres > HARDWARE_MAX_ADRES) ||
          (hardwareBit < HARDWARE_IO_LSB_BITNUMMER) ||
          (hardwareBit > HARDWARE_IO_MSB_BITNUMMER))
        {
          fltk::message ("Regel %d: Ongeldig IO adres %d.%d!\n%s",
                         EricFgetsGetLineCount (file), hardwareAdres,
                         hardwareBit, Array);
          return 1;
        }
      // Controlleer of dit adres al gebruikt is als blok
      for (x = 0; x < MAX_NOBLOKS; x++)
        {
          if (baanInfo.BlokPointer[x].BlokIONummer != -1)
            {
              // blok is gebruikt
              if (baanInfo.BlokPointer[x].BlokIONummer == hardwareAdres)
                {
                  fltk::message
                    ("Regel %d: IO adres %d is al een belegd!\n%s",
                     EricFgetsGetLineCount (file), hardwareAdres, Array);
                  return 1;
                }
            }
        }
      for (x = 0; x < i; x++)
        {
          if ((baanInfo.IOBits[x].hardwareAdres == hardwareAdres) &&
              (baanInfo.IOBits[x].hardwareBit == hardwareBit))
            {
              fltk::message
                ("Regel %d IO adres %d.%02d wordt al gebruikt!\n%s",
                 EricFgetsGetLineCount (file), hardwareAdres, hardwareBit,
                 Array);
              return 1;
            }
        }

      pWissel = &baanInfo.IOBits[i];

      pWissel->hardwareAdres = hardwareAdres;
      pWissel->hardwareBit = hardwareBit;
    }

  //
  // terug naar het begin van de blokken
  //
  fseek (file, position, SEEK_SET);
  EricFgetsSetLineCount (file, lineCount);

  /*
   ** Lees nu de blok database
   **/
  for (i = 0; i < baanInfo.AantalBlokken; i++)
    {
      int Nummer, MaxSnelheid, Lengte, Boven, blokSein, x, y;
      char BlokType[2];
      float Volgend;
      BlokPointer_t *pVolgend;

      BlokType[0] = 0;
      BlokType[1] = 0;
      if (EricFgets (Array, 200, file) == NULL)
        {
          fltk::message ("Regel %d: End of file tijdens bloken lezen",
                         EricFgetsGetLineCount (file));
          return 1;
        }
      if (sscanf (Array, "%d%1s%f%d%d%d%d%d%d", &Nummer, BlokType, &Volgend,
                  &MaxSnelheid, &Lengte, &Boven, &blokSein, &x, &y) != 9)
        {
          fltk::message ("Regel %d: Incorrect blok string at index %d\n%s",
                         EricFgetsGetLineCount (file), i, Array);
          return 1;
        }
      if (BlokIsBlokNummer (Nummer) == 0)
        {
          fltk::message
            ("Regel %d: Blok %d niet binnen de range van 1 tot %d\n%s",
             EricFgetsGetLineCount (file), Nummer, MAX_NOBLOKS, Array);
          return 1;
        }
      // Hoef eigenlijk niet te checken of deze al belegd is of niet want het kan alleen dezelfde
      // zijn die we eerder gezien hebben. Maar je weet maar nooit
      // met programmeer fouten....
      if (baanInfo.BlokPointer[Nummer].BlokIONummer != Nummer)
        {
          fltk::message
            ("Regel %d: Blok %d is incorrect geinitializeerd bug in baan?\n%s",
             EricFgetsGetLineCount (file), Nummer, Array);
          return 1;
        }

      pVolgend = wisselKrijgPointer (&baanInfo, BlokType[0], Volgend);


      if (NULL == pVolgend)
        {
          fltk::message
            ("Regel %d: Volgend blok %s%g niet gevonden in de database\n%s",
             EricFgetsGetLineCount (file), Array);
          return 1;
        }
      // test of de pVolgendBlok NULL is
      if (&baanInfo.EindBlokPointer !=
          baanInfo.BlokPointer[Nummer].pVolgendBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Blok %d is het volgend blok al belegd met blok %d\n%s",
             EricFgetsGetLineCount (file), Nummer,
             baanInfo.BlokPointer[Nummer].pVolgendBlok->BlokIONummer, Array);
          return 1;
        }


      if (Volgend == -1)
        baanInfo.BlokPointer[Nummer].pVolgendBlok = &baanInfo.EindBlokPointer;
      else
        {
          // eerst de heenweg
          baanInfo.BlokPointer[Nummer].pVolgendBlok = pVolgend;
          // nu de terug weg
          // test of de pVorigBlok van het  pVolgendBlok NULL is
          if (&baanInfo.EindBlokPointer != pVolgend->pVorigBlok)
            {
              // we hebben een probleem
              fltk::message
                ("Regel %d: Van Blok %d is het volgend blok zijn TERUG weg al belegd met blok %d\n%s",
                 EricFgetsGetLineCount (file), Nummer,
                 pVolgend->pVorigBlok->BlokIONummer, Array);
              return 1;
            }

          pVolgend->pVorigBlok = &baanInfo.BlokPointer[Nummer];
        }


      baanInfo.BlokPointer[Nummer].Lengte = Lengte;

      if (MaxSnelheid >= 0)
        baanInfo.Blok[Nummer].MaxSnelheid = MaxSnelheid;
      baanInfo.Blok[Nummer].Bovenleiding = Boven;
      baanInfo.Blok[Nummer].blokSein = (blokSein_t) blokSein;
      baanInfo.Blok[Nummer].XCoord = x;
      baanInfo.Blok[Nummer].YCoord = y;
    }





  /*
   ** Lees nu de wissel database
   **/
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      int err;

      if (EricFgets (Array, 200, file) == NULL)
        {
          fltk::message ("Regel %d End of file ben op %d verwacht %d",
                         EricFgetsGetLineCount (file), i,
                         baanInfo.AantalSpoelen);
          return 1;
        }
      if (err = InitWissel (&baanInfo, Array, i))
        {
          switch (err)
            {
            case WISSEL_ERR_NIET_ALLES_AANWEZIG:
              fltk::message
                ("Regel %d Niet alle parameters aanwezig van wissel %d.%02d\n%s",
                 EricFgetsGetLineCount (file),
                 baanInfo.IOBits[i].hardwareAdres,
                 baanInfo.IOBits[i].hardwareBit, Array);
              break;
            case WISSEL_ERR_INVALID_ADRES:
              fltk::message
                ("Regel %d: Een van de adressen is incorrect van wissel %d.%02d\n%s"
                 "\ncheck ook aantal spoelen in blk file",
                 EricFgetsGetLineCount (file),
                 baanInfo.IOBits[i].hardwareAdres,
                 baanInfo.IOBits[i].hardwareBit, Array);
              break;
            case WISSEL_ERR_INVALID_TYPE:
              fltk::message ("Regel %d: Onbekend IO type\n%s",
                             EricFgetsGetLineCount (file), Array);
              break;
            case WISSEL_ERR_MESSAGE_AL_GEGEVEN:
              break;
            default:
              fltk::message
                ("Regel %d: Onbekende fout bij wissel %d.%02d\n%s",
                 EricFgetsGetLineCount (file),
                 baanInfo.IOBits[i].hardwareAdres,
                 baanInfo.IOBits[i].hardwareBit, Array);
              break;
            }
          if (editMode == 0)
            {
              // voor normale excutie laat ik dit niet toe maar in editmode wel
              return 1;
            }
        }
    }

  i = baanDocCheckDatabase ();
  if (editMode)
    {
      // ik laat fouten toe in editmode
      i = 0;
    }
  return i;

}

int
baanDocCheckDatabase ()
{
  int i;

  // check de consistency van de database
  // Note ook al komt het programma door deze check heen wil het zeker nog
  // niet zeggen dat de database goed is! Het programma kan namelijk
  // niet weten wat je bedoelt hebt het kan alleen controleren
  // of alles een valid aansluiting heeft.
  //
  // Check1
  //     kijk of je het volgende/vorige blok wel geinitalizeerd is
  // Check2
  //     kijk of je het volgende/vorige blok naar jouw terug wijst
  for (i = 0; i < MAX_NOBLOKS; i++)
    {
      if (baanInfo.BlokPointer[i].BlokIONummer != -1)
        {
          // blok gebruikt
          if (baanInfo.BlokPointer[i].pVolgendBlok !=
              &baanInfo.EindBlokPointer)
            {
              if (baanInfo.BlokPointer[i].pVolgendBlok->pVorigBlok == NULL)
                {
                  fltk::message
                    ("Blok %d volgend blok is niet in de database", i);
                  return 1;
                }
              if (baanInfo.BlokPointer[i].pVolgendBlok->pVorigBlok !=
                  &baanInfo.BlokPointer[i])
                {
                  fltk::message
                    ("Blok %d volgend blok wijst niet terug naar dit blok (%d)",
                     i,
                     baanInfo.BlokPointer[i].pVolgendBlok->
                     pVorigBlok->BlokIONummer);
                  return 1;
                }
            }
          // Nu dezelfede check in omgekeerde richting
          if (baanInfo.BlokPointer[i].pVorigBlok != &baanInfo.EindBlokPointer)
            {
              if (baanInfo.BlokPointer[i].pVorigBlok->pVolgendBlok == NULL)
                {
                  fltk::message ("Blok %d vorig blok is niet in de database",
                                 i);
                  return 1;
                }
              if (baanInfo.BlokPointer[i].pVorigBlok->pVolgendBlok !=
                  &baanInfo.BlokPointer[i])
                {
                  fltk::message
                    ("Blok %d vorig blok wijst niet terug naar dit blok(%d)",
                     i,
                     baanInfo.BlokPointer[i].pVorigBlok->
                     pVolgendBlok->BlokIONummer);
                  return 1;
                }
            }
        }
    }

  // check nu of alle wissel goed zijn aangesloten
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      if (CheckWissel (&baanInfo, i))
        {
          return 1;
        }
    }
  return 0;

}


void
baanDocLeftMouseButtonDown (int x, int y)
{
  int i;

  // De linker muis knop is ingedrukt
  // Eerst kijken of het de noodknop is
  if ((x >= baanInfo.EindBlok.XCoord) &&
      (x <= baanInfo.EindBlok.XCoord + RESET_SIZE) &&
      (y >= baanInfo.EindBlok.YCoord) &&
      (y <= baanInfo.EindBlok.YCoord + RESET_SIZE))
    {
      baanInfo.noodStop = 1;
    }

  // Controlle of een spoel zich aangesproken voelt
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      if (baanInfo.IOBits[i].Type)
        {
          if ((x >= baanInfo.IOBits[i].rec.x ()) &&
              (x <= baanInfo.IOBits[i].rec.r ()) &&
              (y >= baanInfo.IOBits[i].rec.y ()) &&
              (y <= baanInfo.IOBits[i].rec.b ()))
            {
              IOAanvraag_t IOAanvraag;

              // Het gegeven punt ligt in deze wissel dus roep 
              // de workthread aan met een wissel request
              IOAanvraag.stand = IOAANVRAAG_TOGGLE;
              IOAanvraag.IONummer = i;
              WisselAanvraag (&baanInfo, &IOAanvraag);

              i = baanInfo.AantalSpoelen;
            }
        }
    }

  /* Hierna gaan we de blokken testen of er een lengte aanvraag is */
  for (i = 0; i < MAX_NOBLOKS; i++)
    {
      if (baanInfo.BlokPointer[i].BlokIONummer != -1)
        {
          // blok gebruikt
          if ((baanInfo.Blok[i].State == BLOK_VOORUIT) ||
              (baanInfo.Blok[i].State == BLOK_ACHTERUIT))
            {
              if ((x >= baanInfo.Blok[i].XCoord) &&
                  (x <= baanInfo.Blok[i].XCoord + REGELBITMAP_X) &&
                  (y >= baanInfo.Blok[i].YCoord) &&
                  (y <= baanInfo.Blok[i].YCoord + REGELBITMAP_Y))
                {
                  /*
                   ** Het gegeven punt ligt in deze wissel dus roep 
                   ** de workthread aan met een wissel request
                   **/
                  baanInfo.GeefVrijAanvraag.BlokNummer = i;
                  baanInfo.GeefVrijAanvraag.GeefVrijAanvraag = 1;
                  i = MAX_NOBLOKS;
                }
            }
        }
    }
  // test voor muis events in het globale programma
  globaalProg.checkMuisEvents (x, y);

  // test voor muis events voor de regelaars
  for (i = 0; i < MAX_AANTAL_REGELAARS; i++)
    {
      if ((baanInfo.RegelArray[i].Gebruikt) &&
          (baanInfo.RegelArray[i].Regel.programRunning))
        {
          regelProg[i].checkMuisEvents (x, y);
        }
    }

  /* Geef de input focus aan de active regelaar */
// TODO port this
//      if (baanInfo.RegelArray[m_BaanInfo.HandRegelaar.Index].Gebruikt)
//      {
//              baanInfo.RegelArray[m_BaanInfo.HandRegelaar.Index].Regel.SetForegroundWindow();
//      }

}

void
baanDocRightMouseButtonDown (int x, int y)
{
  int i;
  // De rechter muis knop is ingedrukt check of we
  // een lamp dialoog kunnen oppoppen
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      if ((baanInfo.IOBits[i].Type == LAMP) || (editMode))
        {

          int w, h;
          w = baanInfo.IOBits[i].rec.w ();
          h = baanInfo.IOBits[i].rec.h ();
          if (editMode)
            {
              // in edit mode wil ook de lampen die niet
              // onder user control zitten kunnen instellen
              w = abs (w);
              h = abs (h);
            }
          if ((x >= baanInfo.IOBits[i].rec.x ()) &&
              (x <= (baanInfo.IOBits[i].rec.x () + w)) &&
              (y >= baanInfo.IOBits[i].rec.y ()) &&
              (y <= (baanInfo.IOBits[i].rec.y () + h)))
            {
              if (editMode)
                {
                  selectedWissel = i;
                  selectedOffsetX = x;
                  selectedOffsetY = y;
                  selectedWisselX = x;
                  selectedWisselY = y;
                  DisplayWissel (&baanInfo, i, NULL);

                }
              else
                {
                  // Het gegeven punt is van deze lamp
                  // Dus popup de instellingen van de lamp

                  lampInst Instellingen;

                  Instellingen.aanTijd->value (baanInfo.IOBits[i].Tijd);
                  Instellingen.uitTijd->value (baanInfo.IOBits[i].
                                               Lamp.UitTijd);
                  if (Instellingen.lampInstWindow->exec ())
                    {
                      baanInfo.IOBits[i].Tijd =
                        Instellingen.aanTijd->ivalue ();
                      if (baanInfo.IOBits[i].Tijd <= 0)
                        {
                          // Onzinnige instelling dus zet hem maar op het minimum
                          baanInfo.IOBits[i].Tijd = 1;
                        }
                      baanInfo.IOBits[i].Lamp.UitTijd =
                        Instellingen.uitTijd->ivalue ();
                      if (baanInfo.IOBits[i].Lamp.UitTijd < 0)
                        baanInfo.IOBits[i].Lamp.UitTijd = 0;
                    }
                }
              i = baanInfo.AantalSpoelen;
            }
        }
    }
  /* Hierna gaan we de blokken testen of een regelaar een show nodig heeft */
  for (i = 0; i < MAX_NOBLOKS; i++)
    {
      if (baanInfo.BlokPointer[i].BlokIONummer != -1)
        {
          // blok gebruikt
          if ((baanInfo.Blok[i].RegelaarNummer != -1) || (editMode))
            {
              if ((x >= baanInfo.Blok[i].XCoord) &&
                  (x <= baanInfo.Blok[i].XCoord + REGELBITMAP_X) &&
                  (y >= baanInfo.Blok[i].YCoord) &&
                  (y <= baanInfo.Blok[i].YCoord + REGELBITMAP_Y))
                {
                  /*
                   ** Het gegeven punt ligt in dit blok dus roep
                   ** show aan
                   **/
                  if (editMode)
                    {
                      selectedBlok = i;
                      selectedOffsetX = x - baanInfo.Blok[i].XCoord;
                      selectedOffsetY = y - baanInfo.Blok[i].YCoord;
                      BlokDisplay (&baanInfo, i, -1, BLOK_CLEAR,
                                   baanViewWin->baanBitmap);
                    }
                  else
                    {

                      baanDocPlaatsRegelaar (baanInfo.Blok[i].RegelaarNummer);
                      baanInfo.RegelArray[baanInfo.Blok[i].
                                          RegelaarNummer].Regel.view.
                        regelaarWindow->show ();
                    }

                  i = MAX_NOBLOKS;
                }
            }

          /* Geef de input focus aan de active regelaar */
// TODO port this
//      if (baanInfo.RegelArray[m_BaanInfo.HandRegelaar.Index].Gebruikt)
//      {
//              baanInfo.RegelArray[m_BaanInfo.HandRegelaar.Index].Regel.SetForegroundWindow();//      }
        }
    }
}

int
baanDocInitRegelaar (int RegelaarNummer, int show)
{
  char BitmapFileName[MAX_FILENAME];
  FILE *file;
  float Alfa;
  float Snelheid1, Afstand1, Snelheid2, Afstand2;
  int TopSnelheid;
  char *punt;
  char *streep1;
  char *streep2;
  int version;
  // haal eerst het blkDir deel van de naam af als dat bestaat
  if (strncmp(baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName, blkDir,strlen(blkDir)) == 0)
  {
      strcpy(baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName,&baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName[strlen(blkDir)]);
  }
  if (baanDocFileName (BitmapFileName, baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName, blkDir))
  {
      return 1;
  }
  file =
    fopen (BitmapFileName, "rb");
  if (file == NULL)
    {
      return 1;
    }
  // herleid de locNaam van de filenaam
  punt =
    strrchr (baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName, '.');

  // zoek naar de laatste directory /
  // daar ik unix en dos style doorelkaar heb zoek ik naar beiden

  streep1 =
    strrchr (baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName,
             '/') + 1;
  streep2 =
    strrchr (baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName,
             '\\') + 1;
  if (streep1 > streep2)
    {
      strncpy (baanInfo.RegelArray[RegelaarNummer].Regel.locNaam, streep1,
               punt - streep1);
      baanInfo.RegelArray[RegelaarNummer].Regel.locNaam[punt - streep1] = 0;
    }
  else
    {
      if (streep1 < streep2)
        {
          strncpy (baanInfo.RegelArray[RegelaarNummer].Regel.locNaam, streep2,
                   punt - streep2);
          baanInfo.RegelArray[RegelaarNummer].Regel.locNaam[punt - streep2] =
            0;
        }
      else
        {
          // de \ en de / kwamen niet voor dus we hebben temaken met een kale locnaam
          strncpy (baanInfo.RegelArray[RegelaarNummer].Regel.locNaam,
                   baanInfo.RegelArray[RegelaarNummer].Regel.RegelaarFileName,
                   punt -
                   baanInfo.RegelArray[RegelaarNummer].
                   Regel.RegelaarFileName);
          baanInfo.RegelArray[RegelaarNummer].Regel.locNaam[punt -
                                                            baanInfo.RegelArray
                                                            [RegelaarNummer].Regel.RegelaarFileName]
            = 0;

        }
    }


  /* Lees de bitmap in */
  sprintf (BitmapFileName, "%s.xpm",
           baanInfo.RegelArray[RegelaarNummer].Regel.locNaam);
  if (baanDocFileName (BitmapFileName, BitmapFileName, blkDir))
    {
      fclose (file);
      return 1;
    }


  baanInfo.RegelArray[RegelaarNummer].Regel.bitmap =
    fltk::xpmFileImage::get (BitmapFileName, 0);

  // Lees de version van de loc file
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van het versie nummer",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d", &version) != 1)
    {
      fltk::message ("Regel %d: Verwacht een getal als versie nummer",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }

  /*
   ** Lees of het een eloc is
   **/
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van het eloc bit",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d",
              &baanInfo.RegelArray[RegelaarNummer].Regel.ELoc) != 1)
    {
      fltk::message ("Regel %d: Verwacht een getal 0 of 1 als eloc",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }


  /*
   ** Lees de minimum en maximum snelheid
   **/
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF bij het lezen van minimum en maximum snelheid",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d%d",
              &baanInfo.RegelArray[RegelaarNummer].Regel.MinSnelheid,
              &baanInfo.RegelArray[RegelaarNummer].Regel.MaxSnelheid) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht twee getallen minimum en maximum snelheid",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }

  /*
   ** Lees de top snelheid in km/h
   **/
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen de topsnelheid",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d", &TopSnelheid) != 1)
    {
      fltk::message ("Regel %d: Verwacht een getal voor de topsnelheid",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  baanInfo.RegelArray[RegelaarNummer].Regel.TopSnelheidKmh = TopSnelheid;
  baanInfo.RegelArray[RegelaarNummer].Regel.TopSnelheid =
    (int) (63.0 / (float) TopSnelheid * 16384 + 0.5);


  /*
   ** Lees de alfa an clip voor versnel en vertraag
   **/
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF bij het lezen van alfa en clip voor vertragen",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%g%d",
              &Alfa,
              &baanInfo.RegelArray[RegelaarNummer].Regel.NormaalClip) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht 2 getallen alfa en clip voor vertragen",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  baanInfo.RegelArray[RegelaarNummer].Regel.fNormaalAlfa = Alfa;
  baanInfo.RegelArray[RegelaarNummer].Regel.NormaalAlfa =
    (int) (Alfa * 32768);
  baanInfo.RegelArray[RegelaarNummer].Regel.NormaalClip <<= SNELHEID_SHIFT;

  /*
   ** Lees de alfa an clip voor stoppen
   **/
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF bij het lezen van alfa en clip voor stoppen",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%g%d",
              &Alfa,
              &baanInfo.RegelArray[RegelaarNummer].Regel.StopClip) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht 2 getallen alfa en clip voor stoppen",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  baanInfo.RegelArray[RegelaarNummer].Regel.fStopAlfa = Alfa;
  baanInfo.RegelArray[RegelaarNummer].Regel.StopAlfa = (int) (Alfa * 32768);
  baanInfo.RegelArray[RegelaarNummer].Regel.StopClip <<= SNELHEID_SHIFT;


  /* Lees de remweg tabel */
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF bij het lezen van remweg snelheid1 en afstand1",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%g%g", &Snelheid1, &Afstand1) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht 2 getallen voor remweg snelheid1 en afstand1",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message
        ("Regel %d: EOF bij het lezen van remweg snelheid2 en afstand2",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%g%g", &Snelheid2, &Afstand2) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht 2 getallen voor remweg snelheid2 en afstand2",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  baanInfo.RegelArray[RegelaarNummer].Regel.InitRemWeg (Snelheid1, Afstand1,
                                                        Snelheid2, Afstand2);

  baanInfo.RegelArray[RegelaarNummer].Regel.view.properties->
    image (baanInfo.RegelArray[RegelaarNummer].Regel.bitmap);

  baanInfo.RegelArray[RegelaarNummer].Regel.OnInitDialog (RegelaarNummer);
  baanInfo.RegelArray[RegelaarNummer].Regel.view.
    regelaarWindow->set_non_modal ();
  baanDocPlaatsRegelaar (RegelaarNummer);

  if (show)
    {
      baanInfo.RegelArray[RegelaarNummer].Regel.view.show ();
    }


  // lees het programma 
  if (EricFgets (regelProg[RegelaarNummer].programmaNaam, 200, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van het programma naam",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
//  baanInfo.RegelArray[RegelaarNummer].Regel.pView = m_BaanInfo.pView;
  regelProg[RegelaarNummer].Init (&baanInfo, globaalProg.GetGlobalArray ());
  regelProg[RegelaarNummer].executeProgram (INIT, RegelaarNummer);

  // lees de langzaam en rijden variabelen
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van langzaam en rijden",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d%d",
              &baanInfo.RegelArray[RegelaarNummer].Regel.Langzaam,
              &baanInfo.RegelArray[RegelaarNummer].Regel.Rijden) != 2)
    {
      fltk::message
        ("Regel %d: Verwacht twee getallen voor langzaam en rijden",
         EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  // lees het Loc type in
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van het loctype naam",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  strncpy (baanInfo.RegelArray[RegelaarNummer].Regel.locSoort, BitmapFileName,
           LOCSOORT_SIZE);

  // lees de laatsteWagonCheck
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen van het laatsteWagon bit",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d",
              &baanInfo.RegelArray[RegelaarNummer].Regel.laatsteWagonCheck) !=
      1)
    {
      fltk::message ("Regel %d: Verwacht 0 of 1 voor het laatsteWagon bit",
                     EricFgetsGetLineCount (file));
      baanInfo.RegelArray[RegelaarNummer].Regel.laatsteWagonCheck = 0;
    }

  if (version == 1)
    {
      float gainFactor;
      float difMul;
      float alpha;

      // Lees de gainFactor difMul alpha plusMinus
      // van de lastafhankelijke regeling
      if (EricFgets (BitmapFileName, 256, file) == NULL)
        {
          fltk::message
            ("Regel %d: EOF bij het lezen gainFactor difMul alpha plusMinus lastafhankelijke regeling",
             EricFgetsGetLineCount (file));
          EricFgetsClose (file);
          fclose (file);
          return 1;
        }
      if (sscanf (BitmapFileName, "%f %f %f %d\n",
                  &gainFactor,
                  &difMul,
                  &alpha,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.plusMinus) != 4)
        {
          // TODO disable de PID snelheid regeling
        }
      baanInfo.RegelArray[RegelaarNummer].Regel.lastGain1 = gainFactor;
      baanInfo.RegelArray[RegelaarNummer].Regel.lastGain2 = gainFactor;
      baanInfo.RegelArray[RegelaarNummer].Regel.lastStand1 = 0;
      baanInfo.RegelArray[RegelaarNummer].Regel.lastStand2 = 1;

    }
  else
    {
      // Version 2 of the loc files
      if (EricFgets (BitmapFileName, 256, file) == NULL)
        {
          fltk::message
            ("Regel %d: EOF bij het lezen lastRegelKeuze lastGain1 lastGain2 lastStand1 en lastStand2 lastafhankelijke regeling",
             EricFgetsGetLineCount (file));
          EricFgetsClose (file);
          fclose (file);
          return 1;
        }
      if (sscanf (BitmapFileName, "%d %f %f %d %d\n",
                  &baanInfo.RegelArray[RegelaarNummer].Regel.lastRegelKeuze,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.lastGain1,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.lastGain2,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.lastStand1,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.lastStand2) != 5)
        {
          // TODO disable de PID snelheid regeling
        }

      if (EricFgets (BitmapFileName, 256, file) == NULL)
        {
          fltk::message
            ("Regel %d: EOF bij het lezen Lowpass PlusMinus Helling en Dodetijd van de lastafhankelijke regeling",
             EricFgetsGetLineCount (file));
          EricFgetsClose (file);
          fclose (file);
          return 1;
        }
      if (sscanf (BitmapFileName, "%f %d %f %f\n",
                  &baanInfo.RegelArray[RegelaarNummer].Regel.k_lpf,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.plusMinus,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.helling,
                  &baanInfo.RegelArray[RegelaarNummer].Regel.dodeTijd) != 4)
        {
          // TODO disable de PID snelheid regeling
        }
    }

  // Lees de totalen uit 
  if (EricFgets (BitmapFileName, 256, file) == NULL)
    {
      fltk::message ("Regel %d: EOF bij het lezen de totalen",
                     EricFgetsGetLineCount (file));
      EricFgetsClose (file);
      fclose (file);
      return 1;
    }
  if (sscanf (BitmapFileName, "%d%d",
              &baanInfo.RegelArray[RegelaarNummer].Regel.TotaalAfstand,
              &baanInfo.RegelArray[RegelaarNummer].Regel.TotaalTicken) != 2)
    {
      baanInfo.RegelArray[RegelaarNummer].Regel.TotaalAfstand = 0;
      baanInfo.RegelArray[RegelaarNummer].Regel.TotaalTicken = 0;
    }

  EricFgetsClose (file);
  fclose (file);
  baanViewWin->redraw (fltk::DAMAGE_ALL);
  baanInfo.RegelArray[RegelaarNummer].Gebruikt = 1;

  baanAddTrein (baanInfo.RegelArray[RegelaarNummer].Regel.locSoort,
                baanInfo.RegelArray[RegelaarNummer].Regel.locNaam,
                RegelaarNummer,
                baanInfo.RegelArray[RegelaarNummer].Regel.bitmap);


  tdCreate (&baanInfo.RegelArray[RegelaarNummer].Regel.td);
  tdName (baanInfo.RegelArray[RegelaarNummer].Regel.td,
          baanInfo.RegelArray[RegelaarNummer].Regel.locNaam);
  return 0;

}

void
baanDocPlaatsRegelaar (int RegelaarNummer)
{
  /* regel de plaatsing van het window van de regelaar */
  int breedte, hoogte, aantalX;
  int moduloX, moduloY;

  breedte =
    baanInfo.RegelArray[RegelaarNummer].Regel.view.regelaarWindow->w () + 5;
  hoogte =
    baanInfo.RegelArray[RegelaarNummer].Regel.view.regelaarWindow->h () + 5;

  // reken uit waar de regelaar binnen het gewenste venster past
  aantalX = (regelaarBotX - regelaarTopX) / breedte + 1;
  moduloX = RegelaarNummer % aantalX;
  moduloY =
    (RegelaarNummer / aantalX) % ((regelaarBotY - regelaarTopY) / hoogte + 1);

  baanInfo.RegelArray[RegelaarNummer].Regel.view.
    regelaarWindow->position (moduloX * breedte + baanWin->mainWindow->x () +
                              baanWin->view->x () + regelaarTopX,
                              moduloY * hoogte + baanWin->mainWindow->y () +
                              baanWin->view->y () + regelaarTopY);

}


void
baanDocRegelaarOpen (const char *filename)
{
  int i;
  for (i = 0; i < MAX_AANTAL_REGELAARS; i++)
    {
      if (baanInfo.RegelArray[i].Gebruikt == 0)
        {
          kopRichting kopDlg;
          int TreinAccept;

          TreinAccept = 0;
          do
            {
              bool ret;
              int blok;

              ret = kopDlg.exec ();
              if (0 == ret)
                {
                  return;
                }

              blok = kopDlg.kopBlok->ivalue ();
              // controller of het gegeven kopblok ook wel bestaat
              if ((blok < 0) || (blok >= MAX_NOBLOKS) ||
                  (baanInfo.BlokPointer[blok].BlokIONummer == -1))
                {
                  kopDlg.errorText->label ("Sorry geen bestaand blok");
                }
              else
                {
                  baanInfo.RegelaarAanvraag.Lengte = kopDlg.lengte->ivalue ();
                  baanInfo.RegelaarAanvraag.BlokNummer = blok;
                  baanInfo.RegelaarAanvraag.Richting =
                    (int) kopDlg.vooruitTerug->value ();
                  baanInfo.RegelaarAanvraag.NieuweRegelaar = 1;
                  baanInfo.RegelaarAanvraag.RegelaarNummer = i;
                  baanInfo.RegelaarAanvraag.NeemKopBlokMee =
                    kopDlg.kopBlokMee->value ();
                  baanInfo.RegelaarAanvraag.Aanvraag = 1;

                  baanSemaphoreDown (baanInfo.RegelaarAanvraag.semWacht);

                  TreinAccept = baanInfo.RegelaarAanvraag.AanvraagAccept;
                  if (TreinAccept == 0)
                    {
                      kopDlg.errorText->label ("Niet alle blokken vrij!");
                    }
                  else
                    {
                      baanInfo.RegelArray[i].Regel.Richting =
                        (int) kopDlg.vooruitTerug->value ();
                      baanInfo.RegelArray[i].Regel.pKopBlok =
                        &baanInfo.BlokPointer[blok];
                      baanInfo.RegelArray[i].Regel.Lengte =
                        kopDlg.lengte->ivalue ();
                    }
                }
            }
          while (TreinAccept == 0);

          baanInfo.RegelArray[i].Regel.m_pGebruikt =
            &(baanInfo.RegelArray[i].Gebruikt);
          baanInfo.RegelArray[i].Regel.m_pRegelAanvraag =
            &(baanInfo.RegelaarAanvraag);

          sprintf (baanInfo.RegelArray[i].Regel.RegelaarFileName,
                   "%s", filename);

          baanDocInitRegelaar (i, 1);

          /* break this loop */
          i = MAX_AANTAL_REGELAARS;
        }
    }
}


void
baanDocHerlaadProgramma (int regelaar)
{
  if (baanInfo.RegelArray[regelaar].Gebruikt)
    {
      if (baanInfo.RegelArray[regelaar].Regel.herlaadProgramma)
        {
          // laad het programma opnieuw
          // CLAIMS worden door de unload verwijderd
          regelProg[regelaar].unload ();
          if (baanInfo.RegelArray[regelaar].Regel.programmaNaam[0] != 0)
            {
              // we moeten dus ook het programma naam veranderen
              strcpy (regelProg[regelaar].programmaNaam,
                      baanInfo.RegelArray[regelaar].Regel.programmaNaam);
            }
          regelProg[regelaar].Init (&baanInfo, globaalProg.GetGlobalArray ());
          regelProg[regelaar].executeProgram (INIT, regelaar);
          baanInfo.RegelArray[regelaar].Regel.herlaadProgramma = 0;
        }
    }
}


void
baanDocExecuteProgram (int regelaar, int eventType, int event)
{

  if (regelaar == -1)
    {
      // de globale regelaar
      tdStart (baanInfo.tdglobal);
      globaalProg.executeProgram (eventType, event);
      tdStop (baanInfo.tdglobal);
    }
  else
    {
      if (baanInfo.RegelArray[regelaar].Regel.programRunning)
        {
          tdStart (baanInfo.RegelArray[regelaar].Regel.td);
          regelProg[regelaar].executeProgram (eventType, event);
          tdStop (baanInfo.RegelArray[regelaar].Regel.td);
        }
    }
}

void
baanDocStopProgram (int regelaar)
{
  // programma wordt gestopt dus hef claims op
  // als we weer gestart dan zou je dezelfde claim
  // nogmaals kunnen doen
  regelProg[regelaar].verwijderAanvragen ();
  // Voor het geval dat de trein voor een stop staat met een
  baanInfo.RegelArray[regelaar].Regel.zetGewensteSnelheid (1);
  regelProg[regelaar].blokStop (1, VERWIJDER_ALLE_STOPS);

}


void
baanDocIniFile ()
{

  FILE *file;

  globaalProg.executeProgram (INIT, -1);

  // Hardware is in de lucht of simulatie
  // lees de ini file binnen en  restore de oude situtatie
  file = fopen (iniFileName, "rb");
  if (file != NULL)
    {
      int spoelen;
      int i;
      int version;

      char Array[MAX_FILENAME + 1];

      if (EricFgets (Array, MAX_FILENAME, file) == NULL)
        {
          errorPrint ("Regel %d: EOF Fout in lezen van het versie nummer",
                      EricFgetsGetLineCount (file));
          return;
        }

      sscanf (Array, "%d", &version);


      if (EricFgets (Array, MAX_FILENAME, file) == NULL)
        {
          errorPrint
            ("Regel %d: EOF Fout in lezen aantal blokken en spoelen",
             EricFgetsGetLineCount (file));
          return;
        }


      sscanf (Array, "%d", &spoelen);
      if (baanInfo.AantalSpoelen != spoelen)
        {
          errorPrint
            ("Warning: Aantal spoelen verschillend\nIniFile wordt toch geladen");
        }

      /* het aantal blokken en spoelen is het zelfde met de vorige run */
      for (i = 0; i < spoelen; i++)
        {
          int Stand, VorigeStand;
          int type, wisselNummer;
          float adres;

          if (EricFgets (Array, MAX_FILENAME, file) == NULL)
            {
              errorPrint
                ("Regel %d: EOF Fout in lezen van het versie nummer",
                 EricFgetsGetLineCount (file));
              return;
            }
          sscanf (Array, "%d%f%d\n", &type, &adres, &VorigeStand);
          wisselNummer = ZoekWisselNummer (baanInfo.IOBits, adres, spoelen);
          // check of dit nog steeds een zelfde type wissel is
          if ((wisselNummer < 0)
              || (baanInfo.IOBits[wisselNummer].Type != type))
            {
              continue;         // deze wissel is niet meer dezelfde wissel niet gebruiken dus
            }

          if (WisselStand (&baanInfo, &Stand, wisselNummer))
            {
              /* hier klopt iets niet we verlaten het saven */
              i = baanInfo.AantalSpoelen;
            }
          else
            {
              if (Stand != 0)
                {
                  IOAanvraag_t IOAanvraag;
                  if (VorigeStand != Stand)
                    {
                      IOAanvraag.stand = VorigeStand;
                    }
                  else
                    {
                      IOAanvraag.stand = IOAANVRAAG_REFRESH;
                    }
                  IOAanvraag.IONummer = wisselNummer;
                  WisselAanvraag (&baanInfo, &IOAanvraag);

                  ericSleep (20);       // 20ms max 5 wissels per cycle
                }
            }
        }
      // wacht zo lang totdat we op zijn minst een cycle
      // gedaan hebben in de work threat
      // Hte komt namelijk voor dat de worktreat wordt
      // onderbroken en deze procedure verder kan
      // Dit heeft tot gevolg dat de regelaar geinitializeerd
      // worden terwijl de wissels nog niet gezet zijn
      ericSleep (200);

      /*
       ** Initializeer de regelaars en de blokken 
       **/

      for (i = 0; i < MAX_AANTAL_REGELAARS; i++)
        {

          baanInfo.RegelArray[i].Regel.m_pGebruikt =
            &(baanInfo.RegelArray[i].Gebruikt);
          baanInfo.RegelArray[i].Regel.m_pRegelAanvraag =
            &(baanInfo.RegelaarAanvraag);
          // ik probeer een string te lezen als dit niet lukt 
          // stoppen we
          if (EricFgets
              (baanInfo.RegelArray[i].Regel.RegelaarFileName, 256,
               file) != NULL)
            {
              if (EricFgets (Array, MAX_FILENAME, file) == NULL)
                {
                  errorPrint
                    ("Regel %d: EOF Fout in lezen richting en Lengte regelaar %d",
                     EricFgetsGetLineCount (file), i);
                  return;
                }

              if (sscanf (Array, "%d%d",
                          &baanInfo.RegelArray[i].Regel.Richting,
                          &baanInfo.RegelArray[i].Regel.Lengte) == 2)
                {
                  int BlokType, BlokNummer, aantalBlokken;
                  int richting, tegenRichting;
                  BlokPointer_t *pBlok;
                  if (EricFgets (Array, MAX_FILENAME, file) == NULL)
                    {
                      errorPrint
                        ("Regel %d: EOF Fout in het lezen van BlokType BlokNummer aantalBlokken regelaar %d",
                         EricFgetsGetLineCount (file), i);
                      return;
                    }

                  if (sscanf
                      (Array, "%d%d%d", &BlokType, &BlokNummer,
                       &aantalBlokken) == 3)
                    {
                      if (BlokType == WISSEL_BLOK)
                        {
                          // Voor een kruising kan je op een WISSEL_BLOK staan
                          baanInfo.RegelArray[i].Regel.pKopBlok =
                            &baanInfo.IOBits[BlokNummer].StopBlokPointer[0];
                        }
                      else
                        {
                          baanInfo.RegelArray[i].Regel.pKopBlok =
                            &baanInfo.BlokPointer[BlokNummer];
                        }
                      if (baanDocInitRegelaar (i, 0) == 0)
                        {
                          baanInfo.RegelArray[i].Gebruikt = 1;
                        }
                      if (baanInfo.RegelArray[i].Gebruikt)
                        {
                          // beleg de blokken
                          pBlok = baanInfo.RegelArray[i].Regel.pKopBlok;
                          richting = baanInfo.RegelArray[i].Regel.Richting,
                            tegenRichting = (richting + 1) & 1;
                          do
                            {
                              pBlok->pBlok->State = BLOK_VOORUIT + richting;
                              pBlok->pBlok->RegelaarNummer = i;
                              pBlok = pBlok->blokRicht[tegenRichting];
                              aantalBlokken -= 1;
                              if ((NULL == pBlok)
                                  || (pBlok->pBlok->State != BLOK_VRIJ))
                                {
                                  // stop ermee want we wijzen naar een eindblok
                                  aantalBlokken = 0;
                                }
                            }
                          while (aantalBlokken > 0);

                        }
                    }
                }
            }
          else
            {
              // EOF dus eruit
              i = MAX_AANTAL_REGELAARS;
            }
        }

      EricFgetsClose (file);
      fclose (file);
    }                           // if (file != NULL)
}

void
baanDocAddBlokOk (fltk::Button * o, void *v)
{
  fltk::Window * w;

  w = (fltk::Window *) (o->parent ()->user_data ());
  w->set ();
  w->hide ();
}

void
baanDocAddBlokCancel (fltk::Button * o, void *v)
{
  fltk::Window * w;

  w = (fltk::Window *) (o->parent ()->user_data ());
  w->clear ();
  w->hide ();
}



void
baanDocAddBlok ()
{
  int nieuwBlok;
  fltk::Window * addBlok;
  fltk::IntInput * blok;
  baanDocSetWisselsDefault ();


  {
    fltk::Window * o = addBlok = new fltk::Window (200, 100, "add blok");
    addBlok = o;
    o->user_data ((void *) (addBlok));
    o->begin ();
    {
      fltk::IntInput * o = blok =
        new fltk::IntInput (140, 10, 50, 25, "Geef een vrij blok nummer:");
      o->type (2);
    }
    {
      fltk::ReturnButton * o = new fltk::ReturnButton (20, 60, 65, 25, "OK");
      o->shortcut (0xff0d);
      o->callback ((fltk::Callback *) baanDocAddBlokOk);
    }
    {
      fltk::Button * o = new fltk::Button (115, 60, 65, 25, "Cancel");
      o->callback ((fltk::Callback *) baanDocAddBlokCancel);
    }
  }

  if (nieuwBlok = BlokVindVrijBlok ())
    {
      blok->value (nieuwBlok);
      if (addBlok->exec ())
        {
          // ok add het blok
          nieuwBlok = blok->ivalue ();
          if (BlokIsVrij (nieuwBlok))
            {
              baanInfo.BlokPointer[nieuwBlok].Lengte = 0;
              baanInfo.BlokPointer[nieuwBlok].BlokIONummer = nieuwBlok;
              baanInfo.Blok[nieuwBlok].XCoord = 10;
              baanInfo.Blok[nieuwBlok].YCoord = 10;
              baanInfo.AantalBlokken += 1;
              selectedBlok = nieuwBlok;
              selectedWissel = -1;
              selectedWisselPoint = -1;
              baanViewWin->redraw ();

            }
          else
            {
              fltk::message ("Blok %d is niet vrij", nieuwBlok);
            }
        }

    }
  else
    {
      fltk::message ("Alle blokken bezet vergroot MAX_NOBLOKS");
    }
  delete addBlok;
}


void
baanDocNieuwIo ()
{
  nieuwIo nieuwIoDlg;
  baanDocSetWisselsDefault ();

  if (nieuwIoDlg.window->exec ())
    {
      int kopBlok;
      float adres;
      int type;

      kopBlok = nieuwIoDlg.blok->ivalue ();
      if (BlokIsBlokNummer (kopBlok) == 0)
        {
          kopBlok = 0;
        }
      if (BlokIsVrij (kopBlok))
        {
          kopBlok = 0;
        }
      adres = (float) nieuwIoDlg.adres->fvalue ();
      type = nieuwIoDlg.type->focus_index () + 1;
      WisselNieuw (adres, type, kopBlok);
      baanViewWin->redraw ();


    }
}
