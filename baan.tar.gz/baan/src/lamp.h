#if !defined(_LAMP_H_)
#define _LAMP_H_


int InitLamp (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayLamp (BaanInfo_t * pInfo, int WisselNummer);
int LampAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand);
void TestSpoelLamp (BaanInfo_t * pInfo, int WisselNummer);
void LampString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void LampNieuwXY (BaanInfo_t * pInfo, int WisselNummer,int selectionX, int selectionY, int deltaX, int deltaY);
void LampInitDialoog(class wisselInst *dialoog, int WisselNummer);
void LampDialoogOk(class wisselInst *dialoog, int WisselNummer);

#endif // !defined(_LAMP_H_)
