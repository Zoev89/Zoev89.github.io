#include "baanThread.h"
#include <stdio.h>
#include <pthread.h>

struct _baanThread_t
{
  pthread_t tid;
};


pbaanThread_t
baanThreadCreate (int timeCritical, void *(*start_routine) (void *),
                  void *arg)
{
  pbaanThread_t thread = new _baanThread_t;
  if (thread == NULL)
    return NULL;

  if (timeCritical)
    {
      pthread_attr_t attr;
      int policy;

      // use ps -acL to check if the threat gets there at high priority
      pthread_attr_init (&attr);
      pthread_attr_setscope (&attr, PTHREAD_SCOPE_SYSTEM);
      policy = SCHED_FIFO;
      pthread_attr_setschedpolicy (&attr, policy);
      pthread_create (&thread->tid, &attr, start_routine, arg);
    }
  else
    {
      pthread_create (&thread->tid, NULL, start_routine, arg);
    }
  return thread;
}

void
baanThreadDestroy (pbaanThread_t thread)
{
  delete thread;
}
