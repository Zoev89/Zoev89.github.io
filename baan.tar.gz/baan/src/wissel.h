#if !defined(_WISSEL_H_)
#define _WISSEL_H_

// zie de C file voor de beschrijving
#define WISSEL_ERR_INVALID_ADRES 1
#define WISSEL_ERR_NIET_ALLES_AANWEZIG 2
#define WISSEL_ERR_INVALID_TYPE 3
#define WISSEL_ERR_MESSAGE_AL_GEGEVEN 4

#define WISSEL_ADRES (pWissel->hardwareAdres + (float)(pWissel->hardwareBit)/100.0f)
#define SQR(x) ((x)*(x))
#include "baanTypes.h"
#include <fltk/Image.h>
#include "wisselInst.h"

int InitWissel (BaanInfo_t * pInfo, char *Input);
int CheckWissel (BaanInfo_t * pInfo, int WisselNummer);
int WisselAanvraag (BaanInfo_t * pInfo, IOAanvraag_t * aanvraag);
void DisplayWissel (BaanInfo_t * pInfo, int WisselNummer,fltk::Image * bitmap);
void VeranderDeLichtStatus (BaanInfo_t * pInfo);
void TestIOTimers (BaanInfo_t * pInfo);
int WisselStand (BaanInfo_t * pInfo, int *Stand, int WisselNummer);
int ZoekWisselNummer (IOBits_t * pWissel, float adres, int aantalWissels);
BlokPointer_t *wisselKrijgPointer (BaanInfo_t * pInfo, int BlokType,
				   float adres);
void
WisselString (BaanInfo_t * pInfo, int WisselNummer, char * string);
void 
WisselNieuwXY(BaanInfo_t * pInfo, int WisselNummer,int selectionX, int selectionY, int deltaX, int deltaY);
void WisselVeranderBlok (BaanInfo_t *pInfo, int WisselNummer, BlokPointer_t *oudBlok,  BlokPointer_t *nieuwBlok);
void WisselInitDialoog(class wisselInst *dialoog, int WisselNummer);
void WisselDialoogOk(class wisselInst *dialoog, int WisselNummer);
void WisselNieuw(float adres, int type, int kopBlok);
void WisselDelete(int WisselNummer);

#endif // !defined(_BAANWT_H_)
