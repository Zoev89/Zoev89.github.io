#include "blok.h"
#include "td.h"
#include "globalVars.h"

#include "fltk/draw.h"
#include <fltk/ask.h>

static int lastVrij = 1;        // wordt gebruikt om de gebruiker niet steeds hetzelfde blok te geven voor BlokVindVrijBlok


char *
BlokNaam (char *string, BlokPointer_t * blok)
{
  if ((blok < &baanInfo.BlokPointer[MAX_NOBLOKS]) &&
      (blok > &baanInfo.BlokPointer[0]))
    {
      sprintf (string, "B%d", blok->BlokIONummer);
    }
  else
    {
      if (blok == &baanInfo.EindBlokPointer)
        {
          sprintf (string, "B-1");
        }
      else
        {
          if (((char *) blok < (char *) (&baanInfo.IOBits[MAX_NOBLOKS])) &&
              ((char *) blok > (char *) (&baanInfo.IOBits[0])))
            {
              int index;

              index =
                ((char *) blok -
                 (char *) (&baanInfo.IOBits[0])) /
                sizeof (baanInfo.IOBits[0]);
              if (blok == &(baanInfo.IOBits[index].StopBlokPointer[0]))
                {
                  sprintf (string, "W%d.%02d",
                           baanInfo.IOBits[index].hardwareAdres,
                           baanInfo.IOBits[index].hardwareBit);
                }
              else
                {
                  sprintf (string, "w%d.%02d",
                           baanInfo.IOBits[index].hardwareAdres,
                           baanInfo.IOBits[index].hardwareBit);
                }


            }
          else
            {
              sprintf (string, "XXXX");
              return NULL;
            }
          // wijst naar een wissel
        }
    }
  return string;
}


void
BlokDisplay (BaanInfo_t * pInfo, int blokNummer, int regelaar, int actie,
             fltk::Image * bitmap)
{
  Blok_t *pBlok;
  fltk::Image * regelBitmap;
  fltk::Rectangle rec;
  char string[20];

  tdStart (pInfo->tdview);

  pBlok = &pInfo->Blok[blokNummer];
  tdValue (pInfo->tdOnBlokDisplay, (pBlok - pInfo->Blok));


  rec.x (pBlok->XCoord);
  rec.y (pBlok->YCoord);
  if (regelaar != -1)
    {
      regelBitmap = pInfo->RegelArray[regelaar].Regel.bitmap;
      rec.w (regelBitmap->w ());
      rec.h (regelBitmap->h ());
    }
  else
    {
      regelBitmap = NULL;
      rec.w (REGELBITMAP_X);
      rec.h (REGELBITMAP_Y);
    }


  switch (actie)
    {
    case BLOK_REMOVE:
      bitmap->draw (rec, rec);
      break;

    case BLOK_CLEAR:
      if (editMode)
        {
          if (blokNummer == selectedBlok)
            {
              fltk::setcolor (fltk::RED);
            }
          else
            {
              fltk::setcolor (fltk::GREEN);
            }
          fltk::fillrect (rec);
        }
      else
        {
          bitmap->draw (rec, rec);
        }
      fltk::setfont (fltk::TIMES, (float) (11 - editMode));
      fltk::setcolor (0);
      sprintf (string, "%4d", pInfo->BlokPointer[blokNummer].BlokIONummer);
      fltk::drawtext (string, (float) (pInfo->Blok[blokNummer].XCoord + 8), (float) (baanInfo.Blok[blokNummer].YCoord + 14 - 4 * editMode));    // grr deze functie neem the linker onderhoek
      if (editMode)
        {
          BlokPointer_t *volgend;
          volgend = pInfo->BlokPointer[blokNummer].pVolgendBlok;
          BlokNaam (string, volgend);
          fltk::drawtext (string, (float) (pInfo->Blok[blokNummer].XCoord + 1), (float) (pInfo->Blok[blokNummer].YCoord + 18)); // grr deze functie neem the linker onderhoek
        }

      break;
    case BLOK_BELEG:
      regelBitmap->draw (rec.x (), rec.y ());
      break;
    case BLOK_KOPBLOK:
      regelBitmap->draw (rec.x (), rec.y ());
      rec.w (rec.w () / 2);
      bitmap->draw (rec, rec);
      break;
    case BLOK_KORTSLUIT:
      regelBitmap->draw (rec.x (), rec.y ());
      fltk::line_style (fltk::SOLID, 5);
      fltk::setcolor ((fltk::Color) (fltk::RED));
      fltk::drawline (rec.x () + 1,
                      rec.y () + 1,
                      rec.x () + rec.w () - 2, rec.y () + rec.h () - 2);
      fltk::line_style (0);
      break;
    case BLOK_RESERVED:        // gebruik pBlok->blokBelegtRegelaar als regelaar in de functiecall
      regelBitmap->draw (rec.x (), rec.y ());
      rec.w (rec.w () - 10);
      rec.h (rec.h () - 10);
      regelBitmap->draw (rec, rec);
      break;
    }
  tdStop (pInfo->tdview);

}

// newBlok zijn pVolgendBlok en pVorigBlok moeten
// al correct zijn!
//
// start
//               -----
//               |  -|-------|
//               |---|       |
//       |-------|-  |       |
//       |       -----       |
//                           
//     -----     -----     -----
//     |  -|---->|  -|---->|   |
//     |---|     |---|     |---|
//     |   |<----|-  |<----|-  |
//     -----     -----     -----
//
// stap 1 verwijderen oude referenties b.v. pvolgend
//
//               -----
//               |  -|-------|
//               |---|       |
//       |-------|-  |       |
//       |       -----       |
//                           
//     -----     -----     -----
//     |  -|---->| 0 |     |   |
//     |---|     |---|     |---|
//     |   |<----|-  |<----|-  |
//     -----     -----     -----
//
// stap 1 pvorig
//               -----
//               |  -|-------|
//               |---|       |
//       |-------|-  |       |
//       |       -----       |
//                           
//     -----     -----     -----
//     |  -|---->| 0 |     |   |
//     |---|     |---|     |---|
//     |   |     | 0 |<----|-  |
//     -----     -----     -----
//
// stap 2 aanbrengen pointers
//
//               -----
//           |-->|  -|-------|
//           |   |---|       |
//       |---+---|-  |<--|   |
//       |   |   -----   |   |
//           |           |   
//     ----- |   -----   | -----
//     |  -|--   | 0 |   | |   |
//     |---|     |---|   | |---|
//     |   |     | 0 |   --|-  |
//     -----     -----     -----
//

void
BlokInsert (BlokPointer_t * newBlok)
{
  int richting, tegenRichting;

  for (richting = 0; richting < 2; richting++)
    {
      tegenRichting = (richting + 1) & 1;
      // stap 1
      if ((newBlok->blokRicht[richting] != &baanInfo.EindBlokPointer) &&
          (newBlok->blokRicht[richting] != NULL))
        {
          BlokPointer_t *temp;
          //  het nieuwe volgende blok
          temp = newBlok->blokRicht[richting];
          // van dit blok kijken of de pVorigBlok gezet is
          if ((temp->blokRicht[tegenRichting] != &baanInfo.EindBlokPointer) &&
              (temp->blokRicht[tegenRichting] != NULL))
            {
              // nu de volgend van die pvorig null maken
              temp->blokRicht[tegenRichting]->blokRicht[richting] =
                &baanInfo.EindBlokPointer;
            }
          // stap 2 nu de aansluiting maken
          temp->blokRicht[tegenRichting] = newBlok;
        }
    }
}

//
// BlokDelete
// Deze routine werkt alleen voor blokken niet voor 
// wissels (stopblokken)
//
// Van
//     -----     -----     -----
//     |  -|---->|  -|---->|   |
//     |---|     |---|     |---|
//     |   |<----|-  |<----|-  |
//     -----     -----     -----
//
// Naar
//     -----               -----
//     |  -|-------------->|   |
//     |---|               |---|
//     |   |<--------------|-  |
//     -----               -----
//               -----
//               | 0 | 
//               |---| 
//               | 0 | 
//               ----- 

void
BlokDelete (BlokPointer_t * delBlok)
{
  int richting, tegenRichting;

  if ((delBlok > &baanInfo.BlokPointer[0]) &&
      (delBlok < &baanInfo.BlokPointer[MAX_NOBLOKS]))
    {
      for (richting = 0; richting < 2; richting++)
        {
          tegenRichting = (richting + 1) & 1;

          if (delBlok->blokRicht[richting] != &baanInfo.EindBlokPointer)
            {
              BlokPointer_t *temp;

              //  het nieuwe volgende blok
              temp = delBlok->blokRicht[richting];
              // van dit blok kijken of de pVorigBlok gezet is
              temp->blokRicht[tegenRichting] = &baanInfo.EindBlokPointer;
            }
        }
      // markeer ongebruikt
      delBlok->BlokIONummer = -1;
      delBlok->pVolgendBlok = &baanInfo.EindBlokPointer;
      delBlok->pVorigBlok = &baanInfo.EindBlokPointer;
    }
  else
    {
      fltk::message
        ("blok %x niet deleted want het is geen baan blok maar iets van een wissel",
         delBlok);
    }
}

void
BlokEndPointDelete (BlokPointer_t * delBlok, int richting)
{
  BlokPointer_t *blok;
  int tegenRichting;

  tegenRichting = (richting + 1) & 1;

  blok = delBlok->blokRicht[richting];
  blok->blokRicht[tegenRichting] = &baanInfo.EindBlokPointer;
  delBlok->blokRicht[richting] = &baanInfo.EindBlokPointer;
}

void
BlokEndPointInsert (BlokPointer_t * insBlok, int richting)
{
  BlokPointer_t *blok;
  int tegenRichting;

  tegenRichting = (richting + 1) & 1;

  blok = insBlok->blokRicht[richting];
  if ((blok->blokRicht[tegenRichting] == &baanInfo.EindBlokPointer) ||
      (blok->blokRicht[tegenRichting] == NULL))
    {
    }
  else
    {
      // het blok waar we naartoe wijzen wijst naar een ander blok die maken we maar null
      BlokEndPointDelete (blok->blokRicht[tegenRichting], tegenRichting);
    }
  blok->blokRicht[tegenRichting] = insBlok;
  insBlok->blokRicht[richting] = blok;  // voor het geval dat blok nog naar onsezelf terug wees
}

void
BlokPrint (BlokPointer_t * blok)
{
  char string[10];
  BlokNaam (string, blok);
  printf ("%s\n", string);
}



int
BlokIsBlokNummer (int blokNummer)
{
  if ((blokNummer < 1) || (blokNummer >= MAX_NOBLOKS))
    {
      return 0;
    }
  return 1;
}


int
BlokIsVrij (int blokNummer)
{
  int ret;
  if (BlokIsBlokNummer (blokNummer) == 0)
    {
      // blok niet goed
      return 0;
    }
  if (baanInfo.BlokPointer[blokNummer].BlokIONummer != -1)
    {
      ret = 0;
    }
  else
    {
      lastVrij = blokNummer;
      ret = 1;
    }
  return ret;
}

int
BlokVindVrijBlok ()
{
  int retBlok;

  if (BlokIsBlokNummer (lastVrij) == 0)
    {
      // lastVrij is niet goed herstel dit
      lastVrij = 1;
    }

  // eerste vanaf het eerste blok
  for (retBlok = lastVrij; retBlok < MAX_NOBLOKS; retBlok++)
    {
      if (baanInfo.BlokPointer[retBlok].BlokIONummer == -1)
        {
          // vrij blok gevonden
          lastVrij = retBlok;
          return retBlok;
        }
    }
  for (retBlok = 1; retBlok < lastVrij; retBlok++)
    {
      if (baanInfo.BlokPointer[retBlok].BlokIONummer == -1)
        {
          // vrij blok gevonden
          lastVrij = retBlok;
          return retBlok;
        }
    }
  // geen vrij blok meer
  return 0;
}
