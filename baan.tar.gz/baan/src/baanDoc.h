#ifndef _baanDoc_h_
#define _baanDov_h_
#include <stdio.h>

int baanDocFileName (char *output, char *input, char *dir);

void baanDocOpen(const char *doc);
void baanDocClose();
FILE *baanDocFileOpen(const char *filename,const char *acces, char *dirName,char **name);
void baanDocLeftMouseButtonDown(int x,int y);
void baanDocRightMouseButtonDown(int x,int y);
void baanDocRegelaarOpen(const char *filename);
void baanDocHerlaadProgramma(int regelaar);
void baanDocExecuteProgram (int regelaar, int eventType, int event);
void baanDocStopProgram(int regelaar);
void baanDocPlaatsRegelaar(int RegelaarNummer);
void baanDocSetWisselsDefault();
void baanDocAddBlok();
void baanDocNieuwIo();
int baanDocCheckDatabase();
void baanDocSchrijfBlkFile ();




#endif // _baanDoc_h_

