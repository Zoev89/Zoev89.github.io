//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by baan.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BAANTYPE                    129
#define IDD_REGELAAR                    130
#define IDD_REG_KOP_RICHTING            131
#define IDD_REGELINST                   132
#define IDB_BITMAP1                     133
#define IDD_LAMP_INST                   134
#define IDC_CURSOR1                     135
#define IDC_CURSOR2                     136
#define IDC_CURSOR3                     140
#define IDC_CURSOR4                     141
#define IDC_Regel_Snelheid              1000
#define IDC_Regel_Properties            1001
#define IDC_VOORUIT_TERUG               1002
#define IDC_REG_KOP_RICHTING_SLIDER     1005
#define IDC_REG_KOP_RICHTING_TEXT       1006
#define IDC_KOP_RICHTING_KOP            1007
#define IDC_KOP_RICHTING_LENGTE         1008
#define IDC_REGEL_IGNORESTOP            1009
#define IDC_REGELINST_MIN               1013
#define IDC_REGELINST_MAX               1014
#define IDC_REGELINST_TOTAALAFSTAND     1016
#define IDC_REGELINST_TOTAALTIJD        1017
#define IDC_KOP_RICHTING_NEEM_MEE       1018
#define IDC_REGELINST_LENGTE            1019
#define IDC_REGELINST_TOP               1020
#define IDC_REGELINST_ALPHA_RIJDEN      1021
#define IDC_REGELINST_CLIP_RIJDEN       1022
#define IDC_REGELINST_ALPHA_STOPPEN     1023
#define IDC_REGELINST_CLIP_STOPPEN      1024
#define IDC_REGELINST_ELOC              1027
#define IDC_LAMP_AANTIJD                1028
#define IDC_REGELINST_STAND1            1029
#define IDC_LAMP_UITTIJD                1029
#define IDC_REGELINST_AFSTAND1          1030
#define IDC_REGELINST_STAND2            1031
#define IDC_REGELINST_AFSTAND2          1032
#define IDC_REGELINST_GAIN              1033
#define IDC_REGELINST_ALPHA_REGEL       1034
#define IDC_REGELINST_PL                1035
#define IDC_REGELINST_DIF_MUL           1036
#define IDC_REGELINST_ERRORS            1037
#define IDC_REGELINST_LAATSTE_WAGON     1038
#define IDC_REG_RUN_PROGRAM             1042
#define IDC_REGELINST_RELOAD            1043
#define IDC_REGELINST_PROGRAMMA         1044
#define IDC_REGELINST_LANGZAAM          1045
#define IDC_REGELINST_RIJDEN            1046
#define ID_TREIN_NIEUW                  32772
#define ID_BAAN_FOUTSTATISTIEK          32774
#define ID_BAAN_TDDUMP                  32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
