#ifndef _BAANTHREAD_H_
#define _BAANTHREAD_H_

typedef struct _baanThread_t *pbaanThread_t;

pbaanThread_t baanThreadCreate(int priorty, void *(*start_routine) (void *)  , void *arg);
void baanThreadDestroy(pbaanThread_t thread);

#endif // _BAANTHREAD_H_

