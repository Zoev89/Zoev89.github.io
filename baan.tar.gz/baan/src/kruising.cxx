// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "kruising.h"
#include "leesdata.h"
#include "blok.h"
#include "globalVars.h"
#include <time.h>
#include <stdio.h>
#include <fltk/ask.h>
#include <fltk/draw.h>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static void
KruisingUpdateRec (IOBits_t * pWissel)
{
  int i;

  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X < i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X < i)
    i = pWissel->Wissel.Coord3X;
  if (pWissel->Wissel.Coord4X < i)
    i = pWissel->Wissel.Coord4X;
  pWissel->rec.x (i - 2);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y < i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y < i)
    i = pWissel->Wissel.Coord3Y;
  if (pWissel->Wissel.Coord4Y < i)
    i = pWissel->Wissel.Coord4Y;
  pWissel->rec.y (i - 2);
  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X > i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X > i)
    i = pWissel->Wissel.Coord3X;
  if (pWissel->Wissel.Coord4X > i)
    i = pWissel->Wissel.Coord4X;
  pWissel->rec.w (i - pWissel->rec.x () + 2);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y > i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y > i)
    i = pWissel->Wissel.Coord3Y;
  if (pWissel->Wissel.Coord4Y > i)
    i = pWissel->Wissel.Coord4Y;
  pWissel->rec.h (i - pWissel->rec.y () + 2);
}


int
InitKruising (BaanInfo_t * pInfo, int WisselNummer, char *Input)
{
  IOBits_t *pWissel;
  float floatAdres;
  int Blok1;
  char Blok2Type[2];
  float adres2;
  BlokPointer_t *pBlok2;

  /* Lees alle velden in */

  // NOOIT GETEST DUS KUNNNEN FOUTEN HEBBEN
  pWissel = &pInfo->IOBits[WisselNummer];
  if (sscanf (Input, "%d%f%d%d%d%d%d%d%d%d%d%1s%f",
              &pWissel->Type,
              &floatAdres,
              &pWissel->Wissel.Coord1X,
              &pWissel->Wissel.Coord1Y,
              &pWissel->Wissel.Coord2X,
              &pWissel->Wissel.Coord2Y,
              &pWissel->Wissel.Coord3X,
              &pWissel->Wissel.Coord3Y,
              &pWissel->Wissel.Coord4X,
              &pWissel->Wissel.Coord4Y, &Blok1, Blok2Type, &adres2) != 13)
    return WISSEL_ERR_NIET_ALLES_AANWEZIG;

  if ((Blok1 < HARDWARE_MIN_ADRES) || (Blok1 >= MAX_NOBLOKS))
    {
      return WISSEL_ERR_INVALID_ADRES;
    }
  if (pInfo->BlokPointer[Blok1].BlokIONummer == -1)
    {
      return WISSEL_ERR_INVALID_ADRES;
    }
  pWissel->Wissel.pBlok1 = &pInfo->BlokPointer[Blok1];

  pBlok2 = wisselKrijgPointer (pInfo, Blok2Type[0], adres2);
  if (pBlok2 == NULL)
    return WISSEL_ERR_INVALID_ADRES;

  pWissel->Stand = 0;           /* We hebben geen stand */


  /* Nu het spoel blok ook naar de baan laten wijzen */
  pWissel->StopBlokPointer[0].pBlok = pWissel->Wissel.pBlok1->pBlok;
  pWissel->StopBlokPointer[0].BlokIONummer = WisselNummer;


  if (&pInfo->EindBlokPointer != pWissel->StopBlokPointer[0].pVolgendBlok)
    {
      // we hebben een probleem
      fltk::message
        ("Regel %d: Van Wissel %d.%02d aansluiting 24 is al aangesloten met blok %d\n%s\nRichting misschien fout of aansluiting 24 met 13 verwisseld?",
         EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
         pWissel->hardwareBit,
         pWissel->StopBlokPointer[0].pVolgendBlok->BlokIONummer, Input);
      return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
    }

  if (&pInfo->EindBlokPointer != pBlok2->pVorigBlok)
    {
      // we hebben een probleem
      fltk::message
        ("Regel %d: Van Wissel %d.%02d aansluiting 2 is het volgend blok zijn TERUG weg al belegd met blok %d\n%s",
         EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
         pWissel->hardwareBit, pBlok2->pVorigBlok->BlokIONummer, Input);
      return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
    }

  if (pWissel->Wissel.pBlok1->pVolgendBlok == &pInfo->EindBlokPointer)
    {
      // we hebben een probleem
      fltk::message
        ("Regel %d: Van Wissel %d.%02d aansluiting 3 is nog niet aangesloten dit had in de blok sectie al gedaan moeten zijn\n%s",
         EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
         pWissel->hardwareBit, Input);
      return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
    }




  // Vul de blok2 in
  pWissel->StopBlokPointer[0].pVolgendBlok = pBlok2;
  pBlok2->pVorigBlok = &pWissel->StopBlokPointer[0];
  KruisingUpdateRec (pWissel);

  return 0;
}


void
DisplayKruising (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];

  fltk::line_style (fltk::SOLID, 3);

  if (WisselNummer == selectedWissel)
    {
      fltk::setcolor ((fltk::Color) (fltk::RED));
    }
  else
    {
      fltk::setcolor ((fltk::Color) (fltk::BLACK));
    }

  fltk::drawline (pWissel->Wissel.Coord1X,
                  pWissel->Wissel.Coord1Y,
                  pWissel->Wissel.Coord3X, pWissel->Wissel.Coord3Y);
  fltk::drawline (pWissel->Wissel.Coord2X,
                  pWissel->Wissel.Coord2Y,
                  pWissel->Wissel.Coord4X, pWissel->Wissel.Coord4Y);

}

void
KruisingString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  IOBits_t *pWissel;
  char sString[20];
  char bString[20];


  pWissel = &pInfo->IOBits[WisselNummer];

  BlokNaam (sString, pWissel->StopBlokPointer[0].pVolgendBlok);
  BlokNaam (bString, pWissel->Wissel.pBlok1);


  sprintf (string, "%d %7.2f %4d %4d %4d %4d %4d %4d %4d %4d %8s %8s",
           pWissel->Type,
           WISSEL_ADRES,
           pWissel->Wissel.Coord1X,
           pWissel->Wissel.Coord1Y,
           pWissel->Wissel.Coord2X,
           pWissel->Wissel.Coord2Y,
           pWissel->Wissel.Coord3X,
           pWissel->Wissel.Coord3Y,
           pWissel->Wissel.Coord4X,
           pWissel->Wissel.Coord4Y, &bString[1], sString);

}


void
KruisingWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
                       int selectionY, int deltaX, int deltaY)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (selectedWisselPoint == -1)
    {
      int afstand1, afstand2, x, y;

      selectedWisselPoint = 1;
      afstand1 = SQR (pWissel->Wissel.Coord1X - selectionX) +
        SQR (pWissel->Wissel.Coord1Y - selectionY);
      x = pWissel->Wissel.Coord2X;
      y = pWissel->Wissel.Coord2Y;
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand2 < afstand1)
        {
          selectedWisselPoint = 2;
          afstand1 = afstand2;
        }
      x = pWissel->Wissel.Coord3X;
      y = pWissel->Wissel.Coord3Y;
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand2 < afstand1)
        {
          selectedWisselPoint = 3;
          afstand1 = afstand2;
        }
      x = pWissel->Wissel.Coord4X;
      y = pWissel->Wissel.Coord4Y;
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand2 < afstand1)
        {
          selectedWisselPoint = 4;
          afstand1 = afstand2;
        }
      x = pWissel->rec.center_x ();
      y = pWissel->rec.center_y ();
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand2 < afstand1)
        {
          selectedWisselPoint = 5;
          afstand1 = afstand2;
        }

    }

  pWissel = &pInfo->IOBits[WisselNummer];
  switch (selectedWisselPoint)
    {
    case 1:
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      break;
    case 2:
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      break;
    case 3:
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      break;
    case 4:
      pWissel->Wissel.Coord4X += deltaX;
      pWissel->Wissel.Coord4Y += deltaY;
      break;
    case 5:                    // centrum alle punten
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      pWissel->Wissel.Coord4X += deltaX;
      pWissel->Wissel.Coord4Y += deltaY;
      break;
    }
  baanViewWin->baanBitmap->draw (pWissel->rec, pWissel->rec);
  KruisingUpdateRec (pWissel);

  DisplayWissel (pInfo, WisselNummer, NULL);
}

void
KruisingWisselInitDialoog (class wisselInst * dialoog, int WisselNummer)
{
  int y;
  IOBits_t *pWissel;
  char string[20];

  pWissel = &baanInfo.IOBits[WisselNummer];
  y = 25;
  {
    fltk::Widget * o = dialoog->uitleg =
      new fltk::Widget (5, y += 25, 1, 200,
                        " 1 en 3 aansluiten via de blokken\n"
                        " 4 vanuit een blok of een wissel (Wxxxx.yy)\n"
                        " 2 via de initializatie aangeven\n"
                        "\n"
                        " Je kunt wel rechts om of links om tellen\n"
                        "            ===>rijrichting\n"
                        " -1-              -2-      -4-               -3-\n"
                        "    ---        ---             ---        ---\n"
                        "       ---  ---                   ---  ---\n"
                        "          ==                         ==\n"
                        "       ---  ---                   ---  ---\n"
                        "    ---        ---             ---        ---\n"
                        " -4-              -3-       -1-              -2-\n");
    o->labelfont (fltk::COURIER);
    o->align (fltk::ALIGN_RIGHT);
    o->box (fltk::NO_BOX);
  }

  {
    fltk::Input * o = dialoog->aansluiting2 =
      new fltk::Input (130, y += 200, 65, 25, "Aansluiting2:");
    o->tooltip ("Gebruik de B/W/w notatie");
  }

  BlokNaam (string, pWissel->StopBlokPointer[0].blokRicht[0]);
  dialoog->aansluiting2->value (string);

}

void
KruisingWisselDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;
  BlokPointer_t *wisselBlok;
  char blokType[2];
  float adres;

  pWissel = &baanInfo.IOBits[WisselNummer];



  // volgend blok gewijzigd
  if (sscanf
      (dialoog->aansluiting2->value (), "%1s%f", blokType, &adres) == 2)
    {
      wisselBlok = wisselKrijgPointer (&baanInfo, blokType[0], adres);
      if (wisselBlok == NULL)
        {
          fltk::message
            ("Het volgend blok bestaat niet %s",
             dialoog->aansluiting3->value ());
          // wijziging ongedaan gemaakt
        }
      else if (wisselBlok == pWissel->Wissel.pBlok1)
        {
          fltk::message
            ("Het volgend blok %s is hetzelfde als het wissel blok wijzing niet gedaan",
             dialoog->aansluiting3->value ());
        }
      else
        {
          // wisselBlok wijst naar een blok

          BlokEndPointDelete (&(pWissel->StopBlokPointer[0]), 0);

          pWissel->StopBlokPointer[0].blokRicht[0] = wisselBlok;
          BlokEndPointInsert (&(pWissel->StopBlokPointer[0]), 0);

        }
    }
  else
    {
      fltk::message
        ("Blok %s op aansluiting 2 voldoet niet aan B/W/w notatie.",
         dialoog->aansluiting2->value ());
    }



}
