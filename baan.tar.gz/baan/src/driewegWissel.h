
#if !defined(_DRIEWEGWISSEL_H_)
#define _DRIEWEGWISSEL_H_


int InitDriewegWissel (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayDriewegWissel (BaanInfo_t * pInfo, int WisselNummer);
int DriewegWisselAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand);
void DriewegWisselString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void DriewegWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer,int selectionX, int selectionY, int deltaX, int deltaY);
void DriewegWisselInitDialoog (class wisselInst * dialoog, int WisselNummer);
void DriewegWisselDialoogOk (class wisselInst * dialoog, int WisselNummer);

#endif // !defined(_DRIEWEGWISSEL_H_)
