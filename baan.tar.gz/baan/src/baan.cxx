// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"

#include "baanTypes.h"
#include "baanWT.h"
#include "baanDoc.h"
#include "fltk/run.h"
#include "fltk/visual.h"
#include "globalVars.h"
#include <string.h>


int
argumentParse (int argc, char **argv, int &curArg)
{
  char *in;

  in = argv[curArg];
  // increment curArg on succes
  // return non zero on succes
  // see args.cxx for some more details
  if (strncmp (in, "-editMode", 9) == 0)
    {
      editMode = 1;
      baanWin->edit->activate ();
      baanWin->save->activate ();

      // Windows geeft mij 1 sting met alles erin :(
      if (0 != in[9])           // linux heeft een 0 hier
        {
          in += 10;
        }
      else
        {
          curArg += 1;
          return 1;
        }
    }
  else
    {
      if (argv[curArg][0] == '-')
        {
          // not recognized by me
          return 0;
        }
    }
  if (in[0])
    baanDocOpen (in);
  curArg += 1;
  return 1;


}


int
main (int argc, char **argv)
{
  int ret;
  int i;

  fltk::lock ();                // you must do this before creating any threads!

  fltk::visual (fltk::DOUBLE_BUFFER);

  baanWin = new baanWindow;
  aboutWin = new about;
  // baanViewWin wordt in baanWindow.fl geinitializeerd
  // Initial global objects.

  ret = fltk::args (argc, argv, i, argumentParse);
  if (argc != ret)
    {
      printf ("Error on command line usage:\n");
      printf ("[filename]\n");
      return 1;
    }
  baanWin->show ();
  if (baanTreinenWin)
    {
      baanTreinenWin->show ();
    }

  ret = fltk::run ();

// cleanup allocated windows
  delete aboutWin;
  delete baanWin;
  return ret;
}
