#ifndef _BAANMESSAGE_H_
#define _BAANMESSAGE_H_

int baanMessagePost(int type, int value1, int value2,int value3);
int baanMessageHandlerInit();
void baanMessageHandlerStop();


#endif // _BAANMESSAGE_H_

