#if !defined(_BLOK_H_)
#define _BLOK_H_

#include <fltk/Image.h>
#include "baanTypes.h"

char * 
BlokNaam(char *string,BlokPointer_t *blok);

void BlokDisplay(BaanInfo_t *pInfo, int blokNummer, int regelaar, int actie, fltk::Image * bitmap);
void BlokInsert(BlokPointer_t *newBlok);

void BlokDelete(BlokPointer_t *delBlok);

void 
BlokEndPointDelete(BlokPointer_t * delBlok,int richting);

void
BlokEndPointInsert(BlokPointer_t * insBlok,int richting);
void
BlokPrint(BlokPointer_t * blok);

int BlokIsBlokNummer(int blokNummer); // return 0 if ok else 1
int BlokIsVrij(int blokNummer);  // return 1 if vrij
int BlokVindVrijBlok(); // return blok nummer, 0=error

#endif // !defined(_BLOK_H_)
