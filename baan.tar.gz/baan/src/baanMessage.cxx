#include "baanSemaphore.h"
#include "baanThread.h"
#include "baanQueue.h"
#include "baan.h"
#include "globalVars.h"
#include <stdio.h>

static pbaanQueue_t queue;
static int stop;
static pbaanSemaphore_t stoppedSema;
static int running;
static pbaanThread_t thread;

void *baanMessageThread (void *arg);

int
baanMessagePost (int type, int value1, int value2, int value3)
{
  int buf[4];
  int ret;

  if (queue)
    {
      buf[0] = type;
      buf[1] = value1;
      buf[2] = value2;
      buf[3] = value3;

      ret = baanQueueSend (queue, buf);
    }
  return ret;
}

int
baanMessageHandlerInit ()
{
  // eerst controleren of de message handler nog loopt
  printf ("INIT %d\n", running);
  if (running)
    return 4;
  queue = baanQueueCreate (100, "wtNaarHandler");
  if (queue == NULL)
    return 1;
  stop = 0;
  stoppedSema = baanSemaphoreCreate (0);
  if (stoppedSema == NULL)
    return 2;
  thread = baanThreadCreate (0, baanMessageThread, 0);
  if (thread == NULL)
    return 3;
  running = 1;
  return 0;
}

void
baanMessageHandlerStop ()
{
  if (running)
    {
      stop = 1;
      baanMessagePost (-1, -1, -1, -1);
      baanSemaphoreDown (stoppedSema);
      baanSemaphoreDestroy (stoppedSema);
      baanQueueDestroy (queue);
      baanThreadDestroy (thread);
      stoppedSema = NULL;
      queue = NULL;
    }
}

void *
baanMessageThread (void *arg)
{
  while (stop == 0)
    {
      int buf[4];
      int count;

      baanQueueReceive (queue, buf);
//      printf ("Received message %d %d %d %d\n",
//            buf[0], buf[1], buf[2], buf[3]);
      // handle the message
      if (stop == 0)
        {
          fltk::lock ();
          tdStart (baanInfo.tdMessage);
          do
            {
              tdValue (baanInfo.tdOnMessage, buf[0]);
              switch (buf[0])
                {
                case WM_ECHTE_SNELHEID:
                  baanInfo.RegelArray[buf[1]].Regel.OnEchteSnelheid ();
                  break;
                case WM_GEEF_PROGRESS:
                  baanInfo.RegelArray[buf[1]].Regel.view.
                    gemeten->position (buf[2]);
                  break;
                case WM_BLOK_DISPLAY:
                  baanQueueSend (baanViewWin->baanViewMessage, buf);
//                baanViewWin->redraw (fltk::DAMAGE_ALL+1);
                  baanViewWin->Update ();
                  break;
                case WM_TIMER_VERLOPEN:
                case WM_BLOK_EVENT:
                case WM_INTERNALTIMER_VERLOPEN:
                case WM_VIERKANT_DISPLAY:
                  baanQueueSend (baanViewWin->baanViewMessage, buf);
//                baanViewWin->redraw (1);
                  baanViewWin->Update ();
                  break;
                case WM_WISSEL_DISPLAY:
                  baanQueueSend (baanViewWin->baanViewMessage, buf);
//                baanViewWin->redraw (fltk::DAMAGE_ALL+1);
                  baanViewWin->Update ();
                  break;
                }
              count = baanQueueCount (queue);
              if ((count) && (stop == 0))
                baanQueueReceive (queue, buf);

            }
          while ((stop == 0) && (count));

          tdStop (baanInfo.tdMessage);
          fltk::awake ();
          fltk::unlock ();
        }
    }
  stop = 0;
  running = 0;
  baanSemaphoreUp (stoppedSema);
  return NULL;
}
