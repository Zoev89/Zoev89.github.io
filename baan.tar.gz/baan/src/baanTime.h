#if !defined(_BAANTIME_H)
#define _BAANTIME_H

extern unsigned int baanTimeGetInms();
extern unsigned int baanTimeGetInus();
#endif

