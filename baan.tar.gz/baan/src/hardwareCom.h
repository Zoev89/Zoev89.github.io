#ifndef _HARDWARECOM_H_
#define _HARDWARECOM_H_

#include "baanTypes.h"

#endif // _HARDWARECOM_H_

