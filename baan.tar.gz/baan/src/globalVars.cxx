#include "globalVars.h"

baanWindow *baanWin;
about *aboutWin;
baanView *baanViewWin;

fltk::Window * baanTreinenWin;
fltk::Browser * baanTreinenTree;

char
  blkDir[MAX_FILENAME];
char *
  blkName;

BaanInfo_t baanInfo;


#if defined(_WIN32) && !defined(__CYGWIN__)
char
  dirChar = '\\';
#else
char
  dirChar = '/';
#endif

int
  regelaarTopX,
  regelaarTopY,
  regelaarBotX,
  regelaarBotY;

int
  editMode;
int
  selectedBlok;
int
  selectedWissel = -1;
int
  selectedWisselPoint = -1, selectedWisselX, selectedWisselY;

int
  selectedOffsetX;
int
  selectedOffsetY;
