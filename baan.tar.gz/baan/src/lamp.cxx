// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "lamp.h"
#include "globalVars.h"
#include <time.h>
#include <stdio.h>
#include <fltk/ask.h>
#include <fltk/draw.h>
#include "baanMessage.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int
InitLamp (BaanInfo_t * pInfo, int WisselNummer, char *Input)
{
  IOBits_t *pWissel;
  float floatAdres;
  int x, y, w, h;

  /* Lees alle velden in */
  pWissel = &pInfo->IOBits[WisselNummer];
  if (sscanf (Input, "%d%f%d%d%d%d%d%d%d%d%d", &pWissel->Type, &floatAdres, &pWissel->Lamp.hwAan,       // niet gebruikt alleen belanrijk voor de microcontroller
              &pWissel->Lamp.hwTot,     // niet gebruikt alleen belanrijk voor de microcontroller
              &pWissel->Lamp.hwType,    // niet gebruikt alleen belanrijk voor de microcontroller
              &pWissel->Tijd, &pWissel->Lamp.UitTijd, &x, &y, &w, &h) != 11)
    {
      return 1;
    }
  pWissel->hardwareAdres = (int) (floatAdres + 0.5);
  pWissel->hardwareBit =
    (int) ((floatAdres - (float) pWissel->hardwareAdres) * 100.0 + 0.5);
  pWissel->Stand = 0;           /* default Inactief */
  pWissel->Lamp.aan = 0;

  pWissel->rec.x (x);
  pWissel->rec.y (y);
  pWissel->rec.h (h);
  pWissel->rec.w (w);

  return 0;
}



void
DisplayLamp (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;
  pWissel = &pInfo->IOBits[WisselNummer];
  fltk::Rectangle rec;

  rec = pWissel->rec;
  if (rec.w () < 0)
    {
      rec.w (-rec.w ());
      rec.h (-rec.h ());
    }

  if (pWissel->Lamp.aan == 1)
    {
      fltk::setcolor ((fltk::Color) (fltk::YELLOW));
      fltk::fillrect (rec);
    }
  else
    {
      fltk::setcolor ((fltk::Color) (fltk::GRAY60));
      fltk::fillrect (rec);
    }

}


int
LampAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand)
{
  IOBits_t *pWissel;
  hardwareArray_t bedien;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (stand == pWissel->Stand)
    {
      // status gelijk dus we hoeven niets te doen
      // geef aan alsof die bedient is
      return 0;
    }

  if (pWissel->Stand == 0)
    {
      pWissel->Stand = 1;
      pWissel->Lamp.aan = 1;
      pWissel->TijdTeller = pWissel->Tijd;      /* Initalizeer de bekrachtig tijd */
    }
  else
    {
      pWissel->Stand = 0;
      pWissel->TijdTeller = 0;
    }

  bedien.blokIO = HW_IO;
  bedien.adres = pWissel->hardwareAdres;
  bedien.data = pWissel->hardwareBit;   // default IO_COMMAND0
  bedien.nummer = WisselNummer;
  bedien.returnGewenst = 0;

  if (pWissel->Stand == 1)
    {
      // wissel gebogen
      bedien.data |= IO_COMMAND3;
      // send message alleen wanneer aan
      // het uit gaan wordt door de baanWT via TestSpoelLamp gedaan
      baanMessagePost (WM_WISSEL_DISPLAY, WisselNummer, 0, 0);
    }
  if (pInfo->hardwareHoog.nieuwItem (&bedien))
    {
      fltk::message ("hardware hoog vol info lost lamp!");
    }

  return 0;
}


/* Test of er een verandering is aan de wisselspoel
** De routine geeft een 0 terug als er geen verandering is en een
** 1 als er een verandering plaats heeft gevonden.
**/
void
TestSpoelLamp (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;
  hardwareArray_t bedien;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (pWissel->Stand == 1)
    {
      if (pWissel->TijdTeller > 0)
        {
          pWissel->TijdTeller -= 1;
        }
      if (pWissel->TijdTeller == 0)
        {
          if (pWissel->Lamp.aan == 1)
            {
              /* Spoel nog set dus reset nu */
              pWissel->Lamp.aan = 0;
              pWissel->TijdTeller = pWissel->Lamp.UitTijd;

              bedien.blokIO = HW_IO;
              bedien.adres = pWissel->hardwareAdres;
              bedien.data = pWissel->hardwareBit | IO_COMMAND0;
              bedien.nummer = WisselNummer;
              bedien.returnGewenst = 0;

              if (pInfo->hardwareHoog.nieuwItem (&bedien))
                {
                  fltk::message ("hardware hoog vol info lost lamp!");
                }
              // Als er een uittijd gespecificeerd is dan houd
              // de lamp dan zoveel cycles uit
              if (pWissel->TijdTeller <= 0)
                {
                  // Er was geen uittijd gegeven dus na een cycle
                  // moet die uit.
                  pWissel->Stand = 0;
                }
            }
          else
            {
              // De stand was nog actief dus schakel de lamp weer
              // aan.
              pWissel->Lamp.aan = 1;
              bedien.blokIO = HW_IO;
              bedien.adres = pWissel->hardwareAdres;
              bedien.data = pWissel->hardwareBit | IO_COMMAND3;
              bedien.nummer = WisselNummer;
              bedien.returnGewenst = 0;

              if (pInfo->hardwareHoog.nieuwItem (&bedien))
                {
                  fltk::message ("hardware hoog vol info lost lamp!");
                }
              pWissel->TijdTeller = pWissel->Tijd;
              // Ik hoef de TijdTeller niet te testen want dat was
              // de eerste kaar al gedaan.
            }
          baanMessagePost (WM_WISSEL_DISPLAY, WisselNummer, 0, 0);

        }
      else
        {
          /* Spoel oneindig bekrachtiged */
        }
    }
  else
    {
      /* Stand is 0 check de spoel of die nog aan is */
      if (pWissel->Lamp.aan == 1)
        {
          /* Spoel nog set dus reset nu */
          pWissel->Lamp.aan = 0;
          pWissel->Stand = 0;

          baanMessagePost (WM_WISSEL_DISPLAY, WisselNummer, 0, 0);
          bedien.blokIO = HW_IO;
          bedien.adres = pWissel->hardwareAdres;
          bedien.data = pWissel->hardwareBit | IO_COMMAND0;
          bedien.nummer = WisselNummer;
          bedien.returnGewenst = 0;

          if (pInfo->hardwareHoog.nieuwItem (&bedien))
            {
              fltk::message ("hardware hoog vol info lost lamp!");
            }

        }
    }
}

void
LampString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  IOBits_t *pWissel;


  pWissel = &pInfo->IOBits[WisselNummer];


  sprintf (string, "%d %7.2f %5d %5d %5d %5d %5d %4d %4d %4d %4d", pWissel->Type, WISSEL_ADRES, pWissel->Lamp.hwAan,    // niet gebruikt alleen belanrijk voor de microcontroller
           pWissel->Lamp.hwTot, // niet gebruikt alleen belanrijk voor de microcontroller
           pWissel->Lamp.hwType,        // niet gebruikt alleen belanrijk voor de microcontroller
           pWissel->Tijd,
           pWissel->Lamp.UitTijd,
           pWissel->rec.x (),
           pWissel->rec.y (), pWissel->rec.w (), pWissel->rec.h ());


}


void
LampNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
             int selectionY, int deltaX, int deltaY)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];

  baanViewWin->baanBitmap->draw (pWissel->rec, pWissel->rec);
  pWissel->rec.move (deltaX, deltaY);
  DisplayWissel (pInfo, WisselNummer, NULL);
}


void
LampInitDialoog (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &baanInfo.IOBits[WisselNummer];

  {
    fltk::IntInput * o = dialoog->hwAan =
      new fltk::IntInput (125, 50, 65, 25, "hwAan:");
    o->type (2);
    o->tooltip
      ("de tijd dat uitgang van de microcontroller actief is in 1/2880 sec.");
  }
  {
    fltk::IntInput * o = dialoog->hwTot =
      new fltk::IntInput (125, 75, 65, 25, "hwTot:");
    o->type (2);
    o->tooltip
      ("de totale cycle tijd dat de microcontroller actief is in 1/2880 sec.");
  }
  {
    fltk::Choice * o = dialoog->type =
      new fltk::Choice (125, 100, 95, 25, "SoortUitgang:");
    o->begin ();
    new fltk::Item ("OneShot 0/1");
    new fltk::Item ("OneShot p/n");
    new fltk::Item ("pwm 0/1");
    new fltk::Item ("freq p/n");
    o->end ();
  }
  {
    fltk::IntInput * o = dialoog->Tijd =
      new fltk::IntInput (125, 125, 65, 25, "Tijd:");
    o->type (2);
    o->tooltip ("de tijd dat de uitgang actief is in 50ms");
  }
  {
    fltk::IntInput * o = dialoog->UitTijd =
      new fltk::IntInput (125, 150, 65, 25, "UitTijd:");
    o->type (2);
    o->tooltip
      ("de tijd dat de uitgang uit is voordat die weer aangaat [50ms].");
  }
  {
    fltk::IntInput * o = dialoog->breedte =
      new fltk::IntInput (125, 175, 65, 25, "Breedte:");
    o->type (2);
    o->tooltip
      ("Geef een negatief getal als die niet bedient wordt door het gebruikers interface.");
  }
  {
    fltk::IntInput * o = dialoog->hoogte =
      new fltk::IntInput (125, 200, 65, 25, "Hoogte:");
    o->type (2);
    o->tooltip
      ("Geef een negatief getal als die niet bedient wordt door het gebruikers interface.");
  }


  dialoog->hwAan->value (pWissel->Lamp.hwAan);
  dialoog->hwTot->value (pWissel->Lamp.hwTot);
  dialoog->type->focus_index (pWissel->Lamp.hwType);
  dialoog->Tijd->value (pWissel->Lamp.aan);
  dialoog->UitTijd->value (pWissel->Lamp.UitTijd);
  dialoog->hoogte->value (pWissel->rec.h ());
  dialoog->breedte->value (pWissel->rec.w ());

}

void
LampDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &baanInfo.IOBits[WisselNummer];

  pWissel->Lamp.hwAan = dialoog->hwAan->ivalue ();
  pWissel->Lamp.hwTot = dialoog->hwTot->ivalue ();
  pWissel->Lamp.hwType = dialoog->type->focus_index ();
  pWissel->Lamp.aan = dialoog->Tijd->ivalue ();
  pWissel->Lamp.UitTijd = dialoog->UitTijd->ivalue ();
  pWissel->rec.w (dialoog->breedte->ivalue ());
  pWissel->rec.h (dialoog->hoogte->ivalue ());


}
