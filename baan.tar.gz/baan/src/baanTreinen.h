void baanCreateTreinen (int x, int y, int width, int height);
void baanAddTrein (char *soort,char *name, int regelaarNummer, fltk::Image * image);
void baanDestroyTreinen();
void baanVerwijderTrein (int regelaarNummer);
