// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "standaardWissel.h"
#include "ontkoppelaar.h"
#include "lamp.h"
#include "kruising.h"
#include "engelseWissel.h"
#include "driewegWissel.h"
#include "baanSemaphore.h"
#include "globalVars.h"
#include "blok.h"
#include <time.h>
#include "fltk/draw.h"
#include <fltk/ask.h>
#include <stdio.h>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


// Deze routine wordt tijdens de start fase aangeroepen.
// De noodzakelijke structuur velden worden een waarde gegeven 
// Return waardes
// WISSEL_ERR_INVALID_ADRES adres of invalid blok/ongebruikt blok
// WISSEL_ERR_NIET_ALLES_AANWEZIG de scanf vond niet alles
// WISSEL_ERR_INVALID_TYPE het type is onbekend
int
InitWissel (BaanInfo_t * pInfo, char *Input, int WisselNummer)
{
  int Type, ret_val;


  if (sscanf (Input, "%d", &Type) != 1)
    return 1;

  pInfo->IOBits[WisselNummer].TijdTeller = 0;
  pInfo->IOBits[WisselNummer].Wissel.Richting = 0;
  switch (Type)
    {
    case ONTKOPPELAAR:
      ret_val = InitOntkoppelaar (pInfo, WisselNummer, Input);
      break;
    case STANDAARD_WISSEL:
      ret_val = InitStandaardWissel (pInfo, WisselNummer, Input);
      break;
    case KRUISING:
      ret_val = InitKruising (pInfo, WisselNummer, Input);
      break;
    case ENGELSE_WISSEL:
      ret_val = InitEngelseWissel (pInfo, WisselNummer, Input);
      break;
    case LAMP:
      ret_val = InitLamp (pInfo, WisselNummer, Input);
      break;
    case DRIEWEG_WISSEL:
      ret_val = InitDriewegWissel (pInfo, WisselNummer, Input);
      break;
    default:
      ret_val = WISSEL_ERR_INVALID_TYPE;
    }
  return ret_val;
}

int
CheckWisselBlok (BlokPointer_t * pBlok, int Richting)
{
  int tegenRichting;

  tegenRichting = (Richting + 1) & 1;

  if ((pBlok->blokRicht[Richting] == NULL) ||
      (pBlok->blokRicht[Richting] == &baanInfo.EindBlokPointer))
    {
      return 1;
    }
  if (pBlok->blokRicht[Richting]->blokRicht[tegenRichting] != pBlok)
    {
      return 2;
    }
  return 0;
}


int
CheckWissel (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;
  int ret_val;

  ret_val = 0;
  pWissel = &pInfo->IOBits[WisselNummer];
  switch (pWissel->Type)
    {
    case ONTKOPPELAAR:
      ret_val = 0;
      break;
    case STANDAARD_WISSEL:
      if (CheckWisselBlok (pWissel->Wissel.pBlok1, pWissel->Wissel.Richting))
        {
          fltk::message
            ("StandaardWissel %d.%02d aansluiting 2 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok
          (&pWissel->StopBlokPointer[0], pWissel->Wissel.Richting))
        {
          fltk::message
            ("StandaardWissel %d.%02d aansluiting 3 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      break;
    case KRUISING:
      if (CheckWisselBlok (pWissel->Wissel.pBlok1, 0))
        {
          fltk::message
            ("Kruising %d.%02d aansluiting 3 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok (&pWissel->StopBlokPointer[0], 0))
        {
          fltk::message
            ("Kruising %d.%02d aansluiting 2 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok (&pWissel->StopBlokPointer[0], 1))
        {
          fltk::message
            ("Kruising %d.%02d aansluiting 4 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      break;
    case ENGELSE_WISSEL:
      if (CheckWisselBlok (pWissel->Wissel.pBlok1, 0))
        {
          fltk::message
            ("EngelseWissel %d.%02d aansluiting 3 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok (&pWissel->StopBlokPointer[0], 0))
        {
          fltk::message
            ("EngelseWissel %d.%02d aansluiting 2 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok (&pWissel->StopBlokPointer[0], 1))
        {
          fltk::message
            ("EngelseWissel %d.%02d aansluiting 4 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      break;
    case LAMP:
      ret_val = 0;
      break;
    case DRIEWEG_WISSEL:
      if (CheckWisselBlok (pWissel->Wissel.pBlok1, pWissel->Wissel.Richting))
        {
          fltk::message
            ("DriewegWissel %d.%02d aansluiting 3 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok
          (&pWissel->StopBlokPointer[0], pWissel->Wissel.Richting))
        {
          fltk::message
            ("DriewegWissel %d.%02d aansluiting 2 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      if (CheckWisselBlok
          (&pWissel->StopBlokPointer[2], pWissel->Wissel.Richting))
        {
          fltk::message
            ("DriewegWissel %d.%02d aansluiting 4 niet goed aangesloten!",
             pWissel->hardwareAdres, pWissel->hardwareBit);
          return 1;
        }
      break;
    default:
      ret_val = WISSEL_ERR_INVALID_TYPE;
    }
  return ret_val;

}

/* Tekenend de wissel op het scherm */
void
DisplayWissel (BaanInfo_t * pInfo, int WisselNummer, fltk::Image * bitmap)
{
  IOBits_t *pWissel;
  fltk::Rectangle rec;
  pWissel = &(pInfo->IOBits[WisselNummer]);


  rec = pWissel->rec;
  if (rec.w () < 0)
    {
      rec.w (-rec.w ());
      rec.h (-rec.h ());
    }
  if (bitmap)
    {
      bitmap->draw (rec, rec);
    }


  switch (pWissel->Type)
    {
    case ONTKOPPELAAR:
      DisplayOntkoppelaar (pInfo, WisselNummer);
      break;
    case STANDAARD_WISSEL:
      DisplayStandaardWissel (pInfo, WisselNummer);
      break;
    case KRUISING:
      DisplayKruising (pInfo, WisselNummer);
      break;
    case ENGELSE_WISSEL:
      DisplayEngelseWissel (pInfo, WisselNummer);
      break;
    case LAMP:
      DisplayLamp (pInfo, WisselNummer);
      break;
    case DRIEWEG_WISSEL:
      DisplayDriewegWissel (pInfo, WisselNummer);
      break;
    default:
      break;
    }
  if (editMode)
    {
      char string[10];
      fltk::setfont (fltk::TIMES, (float) (12));
      fltk::setcolor (fltk::BLUE);
      sprintf (string, "%d.%02d", pWissel->hardwareAdres,
               pWissel->hardwareBit);
      fltk::drawtext (string, (float) (pWissel->rec.x () + 1), (float) (pWissel->rec.y () + 8));        // grr deze functie neem the linker onderhoek

    }
}

/* Als de gebruiker een wissel wil omzetten dan word deze routine
** aangeroepen.
**/
int
WisselAanvraag (BaanInfo_t * pInfo, IOAanvraag_t * aanvraag)
{
  int Type;
  int WisselNummer;
  int ret = 0;                  //  bedient

  // bescherm van interruptie van de work thread
  baanSemaphoreDown (pInfo->semCriticalSection);
  WisselNummer = aanvraag->IONummer;
  Type = pInfo->IOBits[WisselNummer].Type;
  switch (Type)
    {
    case ONTKOPPELAAR:
      OntkoppelaarAanvraag (pInfo, WisselNummer);
      break;
    case STANDAARD_WISSEL:
      ret = StandaardWisselAanvraag (pInfo, WisselNummer, aanvraag->stand);
      break;
    case ENGELSE_WISSEL:
      ret = EngelseWisselAanvraag (pInfo, WisselNummer, aanvraag->stand);
      break;
    case LAMP:
      ret = LampAanvraag (pInfo, WisselNummer, aanvraag->stand);
      break;
    case DRIEWEG_WISSEL:
      ret = DriewegWisselAanvraag (pInfo, WisselNummer, aanvraag->stand);
      break;
    default:
      break;
    }
  baanSemaphoreUp (pInfo->semCriticalSection);
  return ret;
}



/* Als de gebruiker een wissel wil omzetten dan word deze routine
** aangeroepen.
**/
int
WisselStand (BaanInfo_t * pInfo, int *Stand, int WisselNummer)
{
  int Type, return_val = 0;

  Type = pInfo->IOBits[WisselNummer].Type;
  *Stand = 0;

  switch (Type)
    {
    case ONTKOPPELAAR:
      break;
    case STANDAARD_WISSEL:
      *Stand = pInfo->IOBits[WisselNummer].Stand;
      break;
    case KRUISING:
      break;
    case ENGELSE_WISSEL:
      *Stand = pInfo->IOBits[WisselNummer].Stand;
      break;
    case LAMP:
      break;
    case DRIEWEG_WISSEL:
      *Stand = pInfo->IOBits[WisselNummer].Stand;
      break;
    default:
      return_val = 1;
      break;
    }

  return return_val;

}



// Doorloop de timers die voor lampen en ontkoppelaars gebruikt worden
void
TestIOTimers (BaanInfo_t * pInfo)
{
  int i;

  for (i = 0; i < pInfo->AantalSpoelen; i++)
    {
      IOBits_t *pWissel;
      /* Oke er zijn meer spoelen dan wissels maar zo weet
       ** zeker dat ik alles heb
       **/
      pWissel = &pInfo->IOBits[i];
      switch (pWissel->Type)
        {
        case ONTKOPPELAAR:
          TestSpoelOntkoppelaar (pInfo, i);
          break;
        case STANDAARD_WISSEL:
          break;
        case ENGELSE_WISSEL:
          break;
        case LAMP:
          TestSpoelLamp (pInfo, i);
          break;
        case DRIEWEG_WISSEL:
          break;
        }
    }
}

// Deze routine zoekt zoekt in de IOBits array naar die wissel met
// hetzelfde adres
// Als het adres niet gevonden is wordt -1 returned
int
ZoekWisselNummer (IOBits_t * pWissel, float adres, int aantalWissels)
{
  int i;
  int hardwareAdres;
  int hardwareBit;

  hardwareAdres = (int) (adres + 0.5);
  hardwareBit = (int) ((adres - (float) hardwareAdres) * 100.0 + 0.5);

  for (i = 0; i < aantalWissels; i++)
    {
      if ((pWissel[i].hardwareAdres == hardwareAdres) &&
          (pWissel[i].hardwareBit == hardwareBit))
        {
          return i;
        }
    }
  // niet gevonden!
  return -1;
}


// Converteer een wissel adres naar een BlokPointer
// deze routine is gelijk voor alle wissels
// De routine geeft ook info terug of de eventuele
// adres al geinitializeerd is
BlokPointer_t *
wisselKrijgPointer (BaanInfo_t * pInfo, int BlokType, float adres)
{
  BlokPointer_t *pBlok;
  int index, blok;

  index = ZoekWisselNummer (pInfo->IOBits, adres, pInfo->AantalSpoelen);
  blok = (int) adres;

  switch (BlokType)
    {
    case 'B':
    case 'b':
      if (blok == -1)
        {
          pBlok = &pInfo->EindBlokPointer;
        }
      else
        {
          if ((blok < HARDWARE_MIN_ADRES) || (blok >= MAX_NOBLOKS))
            return NULL;
          pBlok = &pInfo->BlokPointer[blok];
          if (pBlok->BlokIONummer == -1)
            return NULL;
        }
      break;
    case 'W':
      if (index == -1)
        return NULL;
      pBlok = &pInfo->IOBits[index].StopBlokPointer[0];
      break;
    case 'w':
      /* Aansluiting op 4 van een drieweg wissel */
      if (index == -1)
        return NULL;
      pBlok = &pInfo->IOBits[index].StopBlokPointer[2];
      break;
    default:
      return NULL;
    }
  return pBlok;
}

void
WisselString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  int Type;

  // default initializatie op niets.

  sprintf (string, "Onbekend wissel %d\n", WisselNummer);
  Type = pInfo->IOBits[WisselNummer].Type;

  switch (Type)
    {
    case ONTKOPPELAAR:
      OntkoppelaarString (pInfo, WisselNummer, string);
      break;
    case STANDAARD_WISSEL:
      StandaardWisselString (pInfo, WisselNummer, string);
      break;
    case KRUISING:
      KruisingString (pInfo, WisselNummer, string);
      break;
    case ENGELSE_WISSEL:
      EngelseWisselString (pInfo, WisselNummer, string);
      break;
    case LAMP:
      LampString (pInfo, WisselNummer, string);
      break;
    case DRIEWEG_WISSEL:
      DriewegWisselString (pInfo, WisselNummer, string);
      break;
    default:
      break;
    }

  return;

}

void
WisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
               int selectionY, int deltaX, int deltaY)
{
  IOBits_t *pWissel;
  fltk::Rectangle rec;

  pWissel = &(pInfo->IOBits[WisselNummer]);

  rec = pWissel->rec;
  if (rec.w () < 0)
    {
      rec.w (-rec.w ());
      rec.h (-rec.h ());
    }
  // maak de box groter want in editMode zetten we ook text neer in het display verhaal
  rec.w (rec.w () + 20);
  rec.y (rec.y () - 3);
  rec.h (rec.h () + 3);
  baanViewWin->baanBitmap->draw (rec, rec);

  switch (pWissel->Type)
    {
    case ONTKOPPELAAR:
      break;
    case STANDAARD_WISSEL:
      StandaardWisselNieuwXY (pInfo, WisselNummer, selectionX, selectionY,
                              deltaX, deltaY);
      break;
    case KRUISING:
      KruisingWisselNieuwXY (pInfo, WisselNummer, selectionX, selectionY,
                             deltaX, deltaY);
      break;
      break;
    case ENGELSE_WISSEL:
      EngelseWisselNieuwXY (pInfo, WisselNummer, selectionX, selectionY,
                            deltaX, deltaY);
      break;
    case LAMP:
      LampNieuwXY (pInfo, WisselNummer, selectionX, selectionY, deltaX,
                   deltaY);
      break;
    case DRIEWEG_WISSEL:
      DriewegWisselNieuwXY (pInfo, WisselNummer, selectionX, selectionY,
                            deltaX, deltaY);
      break;
    default:
      break;
    }

  return;
}

void
WisselVeranderBlok (BaanInfo_t * pInfo, int WisselNummer,
                    BlokPointer_t * oudBlok, BlokPointer_t * nieuwBlok)
{
  IOBits_t *pWissel;
  int Type;

  pWissel = &pInfo->IOBits[WisselNummer];

  Type = pWissel->Type;

  switch (Type)
    {
    case ONTKOPPELAAR:
      break;
    case STANDAARD_WISSEL:
      if (pWissel->Wissel.pBlok1 == oudBlok)
        {
          pWissel->Wissel.pBlok1 = nieuwBlok;
        }
      break;
    case KRUISING:
      if (pWissel->Wissel.pBlok1 == oudBlok)
        {
          pWissel->Wissel.pBlok1 = nieuwBlok;
          pWissel->StopBlokPointer[0].pBlok = pWissel->Wissel.pBlok1->pBlok;
          pWissel->StopBlokPointer[0].BlokIONummer = WisselNummer;

        }
      break;
    case ENGELSE_WISSEL:
      if (pWissel->Wissel.pBlok1 == oudBlok)
        {
          pWissel->Wissel.pBlok1 = nieuwBlok;
          pWissel->StopBlokPointer[0].pBlok = pWissel->Wissel.pBlok1->pBlok;
          pWissel->StopBlokPointer[0].BlokIONummer = WisselNummer;

        }
      break;
    case LAMP:
      break;
    case DRIEWEG_WISSEL:
      if (pWissel->Wissel.pBlok1 == oudBlok)
        {
          pWissel->Wissel.pBlok1 = nieuwBlok;
        }
      break;
    default:
      break;
    }

}


void
WisselInitDialoog (class wisselInst * dialoog, int WisselNummer)
{

  IOBits_t *pWissel;
  int Type;
  float adres;

  pWissel = &baanInfo.IOBits[WisselNummer];

  Type = pWissel->Type;
  adres = WISSEL_ADRES;
  dialoog->adres->value (adres);
  dialoog->win->begin ();

  switch (Type)
    {
    case ONTKOPPELAAR:
      OntkoppelaarInitDialoog (dialoog, WisselNummer);
      break;
    case STANDAARD_WISSEL:
      StandaardWisselInitDialoog (dialoog, WisselNummer);
      break;
    case KRUISING:
      KruisingWisselInitDialoog (dialoog, WisselNummer);
      break;
    case ENGELSE_WISSEL:
      EngelseWisselInitDialoog (dialoog, WisselNummer);
      break;
    case LAMP:
      LampInitDialoog (dialoog, WisselNummer);
      break;
    case DRIEWEG_WISSEL:
      DriewegWisselInitDialoog (dialoog, WisselNummer);
      break;
    default:
      break;
    }
  dialoog->win->end ();

}

void
WisselDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;
  int Type;
  int hardwareAdres;
  int hardwareBit;
  float adres;

  pWissel = &baanInfo.IOBits[WisselNummer];
  Type = pWissel->Type;

  adres = (float) dialoog->adres->fvalue ();

  hardwareAdres = (int) (adres + 0.5);
  hardwareBit = (int) ((adres - (float) hardwareAdres) * 100.0 + 0.5);
  if ((hardwareAdres != pWissel->hardwareAdres)
      || (hardwareBit != pWissel->hardwareBit))
    {
      int i;

      i = ZoekWisselNummer (baanInfo.IOBits, adres, baanInfo.AantalSpoelen);

      if (-1 == i)
        {
          // nog niet bestaande spoel
          pWissel->hardwareAdres = hardwareAdres;
          pWissel->hardwareBit = hardwareBit;
        }
      else
        {
          fltk::message ("Bestaand adres %.2f dus niet overgenomen", adres);
        }

    }

  switch (Type)
    {
    case ONTKOPPELAAR:
      OntkoppelaarDialoogOk (dialoog, WisselNummer);
      break;
    case STANDAARD_WISSEL:
      StandaardWisselDialoogOk (dialoog, WisselNummer);
      break;
    case KRUISING:
      KruisingWisselDialoogOk (dialoog, WisselNummer);
      break;
    case ENGELSE_WISSEL:
      EngelseWisselDialoogOk (dialoog, WisselNummer);
      break;
    case LAMP:
      LampDialoogOk (dialoog, WisselNummer);
      break;
    case DRIEWEG_WISSEL:
      DriewegWisselDialoogOk (dialoog, WisselNummer);
      break;
    default:
      break;
    }
  dialoog->win->end ();
}

void
WisselNieuw (float adres, int type, int kopBlok)
{
  int hardwareAdres, hardwareBit;
  int i;

  hardwareAdres = (int) (adres + 0.5);
  hardwareBit = (int) ((adres - (float) hardwareAdres) * 100.0 + 0.5);
  if ((hardwareAdres < HARDWARE_MIN_ADRES) ||
      (hardwareAdres > HARDWARE_MAX_ADRES) ||
      (hardwareBit < HARDWARE_IO_LSB_BITNUMMER) ||
      (hardwareBit > HARDWARE_IO_MSB_BITNUMMER))
    {
      fltk::message ("Ongeldig IO adres %.2f", adres);
      return;
    }


  if (ZoekWisselNummer (baanInfo.IOBits, adres, baanInfo.AantalSpoelen) == -1)
    {
      // wissel niet gevonden dus het is een nieuwe
      IOBits_t *pWissel;
      pWissel = &baanInfo.IOBits[baanInfo.AantalSpoelen];

      switch (type)
        {
        case ONTKOPPELAAR:
        case LAMP:
          // hebben geen kopblok
          break;
        case STANDAARD_WISSEL:
        case KRUISING:
        case ENGELSE_WISSEL:
        case DRIEWEG_WISSEL:
          if ((kopBlok <= 0) || (kopBlok >= MAX_NOBLOKS)
              || (baanInfo.BlokPointer[kopBlok].BlokIONummer == -1))
            {
              fltk::message ("blok %d is ongebruikt", kopBlok);
              return;
            }
          break;
        default:
          return;
          break;
        }
      pWissel->hardwareAdres = hardwareAdres;
      pWissel->hardwareBit = hardwareBit;
      pWissel->Type = type;
      pWissel->rec.x (10);
      pWissel->rec.y (10);
      pWissel->rec.w (20);
      pWissel->rec.h (15);

      baanInfo.AantalSpoelen += 1;
      switch (type)
        {
        case ONTKOPPELAAR:
          pWissel->Ontkoppelaar.InactiefX1 = 10;
          pWissel->Ontkoppelaar.InactiefX2 = 30;
          pWissel->Ontkoppelaar.InactiefY1 = 20;
          pWissel->Ontkoppelaar.InactiefY2 = 20;
          pWissel->Ontkoppelaar.ActiefX1 = 10;
          pWissel->Ontkoppelaar.ActiefX2 = 30;
          pWissel->Ontkoppelaar.ActiefY1 = 10;
          pWissel->Ontkoppelaar.ActiefY2 = 10;
          break;
        case LAMP:
          pWissel->Lamp.hwAan = 1;
          pWissel->Lamp.hwTot = 8;
          pWissel->Lamp.hwType = 2;
          pWissel->Lamp.UitTijd = -1;
          pWissel->Tijd = -1;
          // hebben geen kopblok
          break;
        case STANDAARD_WISSEL:
        case KRUISING:
        case ENGELSE_WISSEL:
        case DRIEWEG_WISSEL:
          pWissel->Wissel.pBlok1 = &baanInfo.BlokPointer[kopBlok];
          pWissel->Stand = 13;
          pWissel->rec.x (pWissel->Wissel.pBlok1->pBlok->XCoord + 40);
          pWissel->rec.y (pWissel->Wissel.pBlok1->pBlok->YCoord);
          pWissel->Wissel.Coord1X = pWissel->rec.x () + 2;
          pWissel->Wissel.Coord1Y = pWissel->rec.b () - 2;
          pWissel->Wissel.Coord2X = pWissel->rec.r () - 2;
          pWissel->Wissel.Coord2Y = pWissel->rec.b () - 2;
          pWissel->Wissel.Coord3X = pWissel->rec.r () - 2;
          pWissel->Wissel.Coord3Y = pWissel->rec.y () + 2;
          pWissel->Wissel.Coord4X = pWissel->rec.x () + 2;
          pWissel->Wissel.Coord4Y = pWissel->rec.y () + 2;
          pWissel->Wissel.Richting = 0;
          pWissel->Wissel.MaxSnelheid12 = -1;
          pWissel->Wissel.MaxSnelheid13 = -1;
          pWissel->Wissel.MaxSnelheid14 = -1;
          pWissel->Wissel.Lengte12 = -1;
          pWissel->Wissel.Lengte13 = -1;
          pWissel->Wissel.Lengte14 = -1;
          pWissel->Wissel.Lengte42 = -1;
          pWissel->Wissel.Lengte43 = -1;
          // default init naar eind blokken
          for (i = 0; i < AANTAL_BLOKS_PER_WISSEL; i++)
            {
              pWissel->StopBlokPointer[i].pVolgendBlok =
                &baanInfo.EindBlokPointer;
              pWissel->StopBlokPointer[i].pVorigBlok =
                &baanInfo.EindBlokPointer;
              pWissel->StopBlokPointer[i].pBlok = &(pWissel->StopBlok[i]);
            }
          if ((KRUISING == type) || (ENGELSE_WISSEL == type))
            {
              pWissel->StopBlokPointer[0].pBlok =
                pWissel->Wissel.pBlok1->pBlok;
            }

          break;
        }
    }
  else
    {
      fltk::message ("Adres al bekend %.2f", adres);
    }


}

// Zijeffect baanInfo.AantalSpoelen -= 1;
void
WisselVerwijder (int WisselNummer)
{
  int offset;
  BlokPointer_t *start, *einde;
  int i, w, r;
  BlokPointer_t *p;
  // Nu zit er een gat in de IOBits array dit moeten we weer recht brijen.
  // De array is dusdanig geinitializeerd dat er nooit een gat in mag zitten
  // Dus vul het gat weer op door alle bovenliggende wissels 1 naar voren
  // te plaatsen

  // Eerst verplaatsen dan de pointers modificeren
  for (i = WisselNummer + 1; i < baanInfo.AantalSpoelen; i++)
    {
      baanInfo.IOBits[i - 1] = baanInfo.IOBits[i];
      if (baanInfo.IOBits[i - 1].StopBlokPointer[0].BlokIONummer == i)
        {
          // kruising en engelse wissel initializeren dit met hun IOBits nummer
          baanInfo.IOBits[i - 1].StopBlokPointer[0].BlokIONummer = i - 1;
        }
    }
  baanInfo.AantalSpoelen -= 1;
  start = &(baanInfo.IOBits[WisselNummer].StopBlokPointer[0]);
  einde =
    &(baanInfo.IOBits[baanInfo.AantalSpoelen -
                      1].StopBlokPointer[AANTAL_BLOKS_PER_WISSEL - 1]);
  offset =
    (char *) &(baanInfo.IOBits[1].StopBlokPointer[0]) -
    (char *) &(baanInfo.IOBits[0].StopBlokPointer[0]);

  // trek de offset af bij alle pointers die in de range liggen voor alle wissels
  for (i = 0; i < baanInfo.AantalSpoelen; i++)
    {
      for (w = 0; w < AANTAL_BLOKS_PER_WISSEL; w++)
        {
          for (r = 0; r < 2; r++)
            {
              p = baanInfo.IOBits[i].StopBlokPointer[w].blokRicht[r];
              if ((p >= start) && (p <= einde))
                {
                  baanInfo.IOBits[i].StopBlokPointer[w].blokRicht[r] =
                    (BlokPointer_t
                     *) ((char *) (baanInfo.IOBits[i].
                                   StopBlokPointer[w].blokRicht[r]) - offset);
                }
            }
        }
    }

  // Doen nu hetzelfde voor alle baan blokken
  for (i = 0; i < baanInfo.AantalBlokken; i++)
    {
      for (r = 0; r < 2; r++)
        {
          p = baanInfo.BlokPointer[i].blokRicht[r];
          if ((p >= start) && (p <= einde))
            {
              baanInfo.BlokPointer[i].blokRicht[r] = (BlokPointer_t *) ((char
                                                                         *)
                                                                        (baanInfo.BlokPointer
                                                                         [i].blokRicht
                                                                         [r])
                                                                        -
                                                                        offset);
            }
        }
    }

}



// PASOP zijeffect is dat baanInfo.aantalSpoelen verlaagt wordt
void
WisselDelete (int WisselNummer)
{
  int type;
  IOBits_t *pWissel;

  pWissel = &baanInfo.IOBits[WisselNummer];
  type = pWissel->Type;
  pWissel->hardwareAdres = 0;
  pWissel->hardwareBit = 0;

  switch (type)
    {
    case KRUISING:
    case ENGELSE_WISSEL:
      // engelse en kruising zijn aan beiden zijde aangesloten
      BlokEndPointDelete (&(pWissel->StopBlokPointer[0]), 1);
    case STANDAARD_WISSEL:
    case DRIEWEG_WISSEL:
      BlokEndPointDelete (&(pWissel->StopBlokPointer[0]),
                          pWissel->Wissel.Richting);
      if (DRIEWEG_WISSEL == type)
        {
          BlokEndPointDelete (&(pWissel->StopBlokPointer[2]),
                              pWissel->Wissel.Richting);
        }
      break;
    }

  pWissel->Type = 0;
  WisselVerwijder (WisselNummer);
}
