#include "baanTypes.h"
#include "baanWT.h"
#include <string.h>
#include "fltk/Window.h"
#include "fltk/Browser.h"
#include "fltk/Item.h"

#define AANTALIO 40




static
  fltk::Window *
  ioWin;
static
  fltk::Browser *
  ioTree;


static
  fltk::Widget *
addIo (fltk::Group * parent, const char *name, fltk::Image * image)
{
  parent->begin ();
  fltk::Item * o = new fltk::Item ();
  o->copy_label (name);
  o->align (fltk::ALIGN_LEFT | fltk::ALIGN_INSIDE | fltk::ALIGN_CLIP);
  if (image)
    o->image (image);
  return o;
}

void
ioOverzichtDestroy ()
{
  if (ioWin)
    {
      ioWin->destroy ();
      delete ioTree;
      delete ioWin;
      ioWin = NULL;
      ioTree = NULL;
    }

}

void
ioOverzicht (BaanInfo_t * pInfo)
{
  int i, p;
  int ios[AANTALIO][17];

  memset (ios, 0, sizeof (ios));

  // we zoeken alle spoelen af en maken een tabel per io controller
  for (i = 0; i < pInfo->AantalSpoelen; i++)
    {
      int Type;
      IOBits_t *pWissel;

      pWissel = &pInfo->IOBits[i];
      Type = pWissel->Type;
      for (p = 0; p < AANTALIO; p++)
        {
          if ((0 == ios[p][0]) || (pWissel->hardwareAdres == ios[p][0]))
            {
              // gevonden of een nieuwe entry
              ios[p][0] = pWissel->hardwareAdres;
              ios[p][pWissel->hardwareBit + 1] = pWissel->Type;
              if (DRIEWEG_WISSEL == Type)
                {
                  ios[p][pWissel->hardwareBit + 2] = pWissel->Type;
                }
              break;
            }
        }


    }
  // tabel opgebouwed nu het displayen

  if (NULL == ioWin)
    {
      // is nog niet erder aangeroepen dus creer het window
      int width = 533;
      int height = 200;
      int widths[] = {
        40,
        30, 30, 30, 30,
        30, 30, 30, 30,
        30, 30, 30, 30,
        30, 30, 30, 30
      };
      ioWin = new fltk::Window (width, height, "IO's");
      ioWin->begin ();
      ioTree = new fltk::Browser (0, 0, width, height);
      ioTree->indented (0);
      ioTree->column_widths (widths);
//      ioWin->resizable (ioTree);
      ioWin->end ();
      ioWin->set_non_modal ();
    }
  else
    {
      // vernietig de oude inhoud
      ioTree->clear ();
    }


  addIo (ioTree, " IO\t0\t1\t2\t3\t4\t5\t6\t7\t8\t9\t10\t11\t12\t13\t14\t15",
         NULL);
  for (p = 0; p < AANTALIO; p++)
    {
      char inhoud[100];
      if (0 == ios[p][0])
        {
          break;
        }
      else
        {
          sprintf (inhoud, "%d", ios[p][0]);
          for (i = 1; i < 17; i++)
            {
              const char *t;
              switch (ios[p][i])
                {
                case 0:
                  t = "vrij";
                  break;
                case 1:
                  t = "ont";
                  break;
                case 2:
                  t = "wis";
                  break;
                case 3:
                  t = "kruis";
                  break;
                case 4:
                  t = "eng";
                  break;
                case 5:
                  t = "drie";
                  break;
                case 6:
                  t = "lamp";
                  break;
                default:
                  t = "?";
                }
              sprintf (inhoud, "%s\t%s", inhoud, t);
            }
          addIo (ioTree, inhoud, NULL);
        }

    }
  ioWin->show ();
}
