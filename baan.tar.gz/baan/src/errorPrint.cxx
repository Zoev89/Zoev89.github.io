#include <stdio.h>

#include "errorPrint.h"
#include "globalVars.h"

static FILE *errorFile;

void
errorPrint (const char *msg, ...)
{
  va_list arg_ptr;
  char string[50];

  if (errorFile == NULL)
    {
      errorFile = fopen ("baanLog.txt", "w");
    }

  va_start (arg_ptr, msg);
  sprintf (string, "[%dm %2ds %3dms] ", baanInfo.tickTimer / (10 * 60),
           (baanInfo.tickTimer / 10) % 60, baanInfo.tickTimer % (10) * 100);
  printf ("%s", string);
  vprintf (msg, arg_ptr);
  if (errorFile)
    {
      fprintf (errorFile, "%s", string);
      vfprintf (errorFile, msg, arg_ptr);
    }
  va_end (arg_ptr);

}

void
errorPrintClose (void)
{
  if (errorFile)
    {
      fclose (errorFile);
      errorFile = NULL;
    }
}
