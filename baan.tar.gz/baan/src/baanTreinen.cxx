#include "globalVars.h"
#include "baanTreinen.h"
#include <string.h>

void
baanTreinenCallback (fltk::Widget * browser, void *)
{
  fltk::Widget * w = ((fltk::Browser *) browser)->item ();
  if (w)
    {
      int regelaar = w->argument ();
      if ((regelaar >= 0) && (regelaar < MAX_AANTAL_REGELAARS))
        {
          baanDocPlaatsRegelaar (regelaar);
          baanInfo.RegelArray[regelaar].Regel.view.regelaarWindow->show ();
        }
    }
}


void
baanCreateTreinen (int x, int y, int width, int height)
{
  baanTreinenWin = new fltk::Window (x, y, width, height, "De Treinen");
  baanTreinenWin->begin ();
  baanTreinenTree = new fltk::Browser (0, 0, width, height);
  baanTreinenTree->indented (1);
  baanTreinenTree->callback (baanTreinenCallback);
  baanTreinenWin->resizable (baanTreinenTree);
  baanTreinenWin->end ();
  baanTreinenWin->set_non_modal ();
  baanTreinenWin->show ();
}

void
baanDestroyTreinen ()
{
  if (baanTreinenWin)
    {
      baanTreinenWin->destroy ();
      delete baanTreinenTree;
      delete baanTreinenWin;
      baanTreinenWin = NULL;
      baanTreinenTree = NULL;
    }
}

static
  fltk::Widget *
addTrein (fltk::Group * parent, const char *name, int regelaarNummer,
          fltk::Image * image)
{
  parent->begin ();
  fltk::Item * o = new fltk::Item (name);
  o->align (fltk::ALIGN_LEFT | fltk::ALIGN_INSIDE | fltk::ALIGN_CLIP);
  if (image)
    o->image (image);
  o->argument (regelaarNummer);
  return o;
}


void
baanAddTrein (char *soort, char *name, int regelaarNummer,
              fltk::Image * image)
{
  int i;
  for (i = 0; i < baanTreinenTree->size (); i++)
    {
      fltk::Widget * w = baanTreinenTree->goto_index (i);
      if (w)
        {
          if (0 == strcmp (soort, w->label ()))
            {
              baanTreinenTree->set_item_opened (true);

              addTrein ((fltk::Group *) w, name, regelaarNummer, image);
              return;
            }
        }
    }

  // trein soort nog niet bekend dus voeg deze groep toe en dan de trein  
  baanTreinenTree->begin ();
  fltk::ItemGroup * o = new fltk::ItemGroup (soort);
  o->align (fltk::ALIGN_LEFT | fltk::ALIGN_INSIDE | fltk::ALIGN_CLIP);
  o->argument (-1);
  addTrein (o, name, regelaarNummer, image);
  baanTreinenTree->end ();
  // eerst het toegevoegde soort current maken en dan kunnen
  // hem openklappen
  baanTreinenTree->goto_index (baanTreinenTree->size () - 1);

  baanTreinenTree->set_item_opened (true);
}

void
baanVerwijderTrein (int regelaarNummer)
{

  fltk::Widget * w = baanTreinenTree->goto_index (0);
  while (w)
    {
      if (w->argument () == regelaarNummer)
        {
          fltk::Group * g = w->parent ();
          g->remove (w);
          delete w;
          g->relayout ();
          w = NULL;
        }
      else
        {
          w = baanTreinenTree->next ();
        }

    }

}
