#ifndef ERRORPRINT_H_
#define ERRORPRINT_H_

#include <stdarg.h>

void errorPrint(const char * msg,...);
void errorPrintClose(void);

#endif /*ERRORPRINT_H_*/
