// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "standaardWissel.h"
#include "baanMessage.h"
#include "leesdata.h"
#include "blok.h"
#include "globalVars.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fltk/ask.h>
#include <fltk/draw.h>


// Construction/Destruction
//////////////////////////////////////////////////////////////////////
static void
StandaardWisselUpdateRec (IOBits_t * pWissel)
{
  int i;

  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X < i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X < i)
    i = pWissel->Wissel.Coord3X;
  pWissel->rec.x (i - 3);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y < i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y < i)
    i = pWissel->Wissel.Coord3Y;
  pWissel->rec.y (i - 3);
  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X > i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X > i)
    i = pWissel->Wissel.Coord3X;
  pWissel->rec.w (i - pWissel->rec.x () + 3);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y > i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y > i)
    i = pWissel->Wissel.Coord3Y;
  pWissel->rec.h (i - pWissel->rec.y () + 3);
}


int
InitStandaardWissel (BaanInfo_t * pInfo, int WisselNummer, char *Input)
{
  IOBits_t *pWissel;
  float floatAdres;
  int Blok1;
  char Blok3Type[2];
  float adres3;
  BlokPointer_t *pBlok3;

  /* Lees alle velden in */
  pWissel = &pInfo->IOBits[WisselNummer];
  if (sscanf (Input, "%d%f%d%d%d%d%d%d%d%1s%f%d%d%d%d",
              &pWissel->Type,
              &floatAdres,
              &pWissel->Wissel.Coord1X,
              &pWissel->Wissel.Coord1Y,
              &pWissel->Wissel.Coord2X,
              &pWissel->Wissel.Coord2Y,
              &pWissel->Wissel.Coord3X,
              &pWissel->Wissel.Coord3Y,
              &Blok1,
              Blok3Type,
              &adres3,
              &pWissel->Wissel.Lengte12,
              &pWissel->Wissel.Lengte13,
              &pWissel->Wissel.MaxSnelheid12,
              &pWissel->Wissel.MaxSnelheid13) != 15)
    return WISSEL_ERR_NIET_ALLES_AANWEZIG;

  StandaardWisselUpdateRec (pWissel);


  if ((Blok1 < HARDWARE_MIN_ADRES) || (Blok1 >= MAX_NOBLOKS))
    {
      return WISSEL_ERR_INVALID_ADRES;
    }
  if (pInfo->BlokPointer[Blok1].BlokIONummer == -1)
    {
      return WISSEL_ERR_INVALID_ADRES;
    }

  pWissel->Wissel.pBlok1 = &pInfo->BlokPointer[Blok1];


  pBlok3 = wisselKrijgPointer (pInfo, Blok3Type[0], adres3);
  if (pBlok3 == NULL)
    return WISSEL_ERR_INVALID_ADRES;

  if (-1 == adres3)
    {
      pWissel->Wissel.Richting = 1;
    }
  else
    {
      pWissel->Wissel.Richting = 0;
    }


  pWissel->Stand = 12;          /* default wijzen we naar 2 */

  /* Controleer of de maximum snelheid gebruikt wordt */
  if (pWissel->Wissel.MaxSnelheid12 >= 0)
    {
      /* omdat deze maximum snelheid gebruikt wordt zet hem op de baan */
      pWissel->Wissel.pBlok1->pBlok->MaxSnelheid =
        pWissel->Wissel.MaxSnelheid12;
    }


  /* stand is 12 dus init baan lengte */
  if (pWissel->Wissel.Lengte12 >= 0)
    pWissel->Wissel.pBlok1->Lengte = pWissel->Wissel.Lengte12;


  if (pWissel->Wissel.Richting == 0)
    {
      /* de richting is voorwaards */
      if (&pInfo->EindBlokPointer != pWissel->StopBlokPointer[0].pVolgendBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 3 is al aangesloten met blok %d\n%s\nRichting misschien fout of aansluiting 2 met 3 verwisseld?",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit,
             pWissel->StopBlokPointer[0].pVolgendBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }

      if (&pInfo->EindBlokPointer != pBlok3->pVorigBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 3 is het volgend blok zijn TERUG weg al belegd met blok %d\n%s",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit, pBlok3->pVorigBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }
      pWissel->StopBlokPointer[0].pVolgendBlok = pBlok3;
      pBlok3->pVorigBlok = &pWissel->StopBlokPointer[0];
    }
  else
    {
      /* de richting is achteruit */
      // niets te doen de andere doen dit.
      // maar aansluiting 2 moet er al zijn dus die controleren we
      if (pWissel->Wissel.pBlok1->pVolgendBlok == &pInfo->EindBlokPointer)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 2 is nog niet aangesloten dit had in de blok sectie al gedaan moeten zijn\n%s",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }

    }


  return 0;
}





void
DisplayStandaardWissel (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];

  fltk::line_style (fltk::SOLID, 5);
  if (WisselNummer == selectedWissel)
    {
      fltk::setcolor ((fltk::Color) (fltk::RED));
    }
  else
    {
      fltk::setcolor ((fltk::Color) (fltk::BLACK));
    }
  if (pWissel->Stand == 12)
    fltk::drawline (pWissel->Wissel.Coord1X,
                    pWissel->Wissel.Coord1Y,
                    pWissel->Wissel.Coord2X, pWissel->Wissel.Coord2Y);
  else
    fltk::drawline (pWissel->Wissel.Coord1X,
                    pWissel->Wissel.Coord1Y,
                    pWissel->Wissel.Coord3X, pWissel->Wissel.Coord3Y);
}

void
StandaardWisselBedien (BaanInfo_t * pInfo, IOBits_t * pWissel,
                       int WisselNummer)
{
  hardwareArray_t bedien;

  bedien.blokIO = HW_IO;
  bedien.adres = pWissel->hardwareAdres;
  bedien.data = pWissel->hardwareBit;   // default IO_COMMAND0
  bedien.nummer = WisselNummer;
  bedien.returnGewenst = 0;

  if (pWissel->Stand == 13)
    {
      // wissel gebogen
      bedien.data |= IO_COMMAND3;
    }
  if (pInfo->hardwareHoog.nieuwItem (&bedien))
    {
      fltk::message ("hardware hoog vol info lost standaard wissel!");
    }
}

int
StandaardWisselAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand)
{
  IOBits_t *pWissel;
  BlokPointer_t *pBlok1;
  BlokPointer_t *pBlok2;
  BlokPointer_t *pBlok3;
  int RegelaarNummer;
  int richting;
  int tegenRichting;
  BlokPointer_t *pStopBlok;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (IOAANVRAAG_REFRESH == stand)
    {
      StandaardWisselBedien (pInfo, pWissel, WisselNummer);
      return 0;
    }
  if (IOAANVRAAG_DEFAULT == stand)
    {
      stand = 12;
    }
  if (pWissel->Stand == stand)
    {
      // als de stand gelijk is dan meteen terug alsof die bedient is
      return 0;
    }

  pBlok1 = pWissel->Wissel.pBlok1;
  RegelaarNummer = pBlok1->pBlok->RegelaarNummer;
  if ((pBlok1->pBlok->State != BLOK_VRIJ) && (pBlok1->pBlok->Snelheid != 0))
    {
      return IOGEWIJGERD;
    }
  richting = pWissel->Wissel.Richting;
  tegenRichting = (richting + 1) & 1;

  pBlok2 = pBlok1->blokRicht[richting];


  if ((pBlok1->pBlok->State != BLOK_VRIJ) &&
      (RegelaarNummer == pBlok2->pBlok->RegelaarNummer))
    {
      /* snelheid is nul van wege de bovenste conditie */
      if ((pBlok1->pBlok->State == BLOK_VOORUITCHECK) ||
          (pBlok1->pBlok->State == BLOK_ACHTERUITCHECK))
        {
          /* geef dit blok vrij want dat kan wel */
          GeefBlokVrij (pInfo, pBlok1);
        }
      else
        {
          if ((pBlok2->pBlok->State == BLOK_VOORUITCHECK) ||
              (pBlok2->pBlok->State == BLOK_ACHTERUITCHECK))
            {
              /* geef dit blok vrij want dat kan wel */
              GeefBlokVrij (pInfo, pBlok2);
            }
          else
            {
              /* beiden blokken bezet dus niet bedienen */
              return IOGEWIJGERD;
            }
        }
    }
#ifdef ZET_CHECKING_UIT
  if (((pBlok2->pBlok->State & BLOK_BEZET_MASK) != BLOK_VRIJ) &&
      (pBlok2->pBlok->Snelheid != 0))
    {
      return IOGEWIJGERD;       /* Wissel is bezet dus niet omschakelen */
    }
#endif

  pStopBlok = &pWissel->StopBlokPointer[0];

  pBlok3 = pStopBlok->blokRicht[richting];

  pBlok1->blokRicht[richting] = pBlok3;
  pBlok3->blokRicht[tegenRichting] = pBlok1;
  pBlok2->blokRicht[tegenRichting] = pStopBlok;
  pStopBlok->blokRicht[richting] = pBlok2;


  if (pWissel->Stand == 12)
    {
      /* De wissel staat op 12 */

      pWissel->Stand = 13;
      /* Zet de maximum snelheid op */
      if (pWissel->Wissel.MaxSnelheid13 >= 0)
        pBlok1->pBlok->MaxSnelheid = pWissel->Wissel.MaxSnelheid13;

      /* Zet de lengte info */
      if (pWissel->Wissel.Lengte13 >= 0)
        pBlok1->Lengte = pWissel->Wissel.Lengte13;

    }
  else
    {
      pWissel->Stand = 12;
      /* Zet de maximum snelheid op */
      if (pWissel->Wissel.MaxSnelheid12 >= 0)
        pBlok1->pBlok->MaxSnelheid = pWissel->Wissel.MaxSnelheid12;

      /* Zet de lengte info */
      if (pWissel->Wissel.Lengte12 >= 0)
        pBlok1->Lengte = pWissel->Wissel.Lengte12;
    }

  StandaardWisselBedien (pInfo, pWissel, WisselNummer);

  baanMessagePost (WM_WISSEL_DISPLAY, WisselNummer, 0, 0);
  return 0;
}


void
StandaardWisselString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  IOBits_t *pWissel;
  char sString[20];
  char bString[20];


  pWissel = &pInfo->IOBits[WisselNummer];

  if (pWissel->Wissel.Richting)
    {
      // richting terug
      strcpy (sString, "B-1");
    }
  else
    {
      BlokNaam (sString, pWissel->StopBlokPointer[0].pVolgendBlok);
    }
  BlokNaam (bString, pWissel->Wissel.pBlok1);

  sprintf (string, "%d %7.2f %4d %4d %4d %4d %4d %4d %8s %8s %4d %4d %4d %4d",
           pWissel->Type,
           WISSEL_ADRES,
           pWissel->Wissel.Coord1X,
           pWissel->Wissel.Coord1Y,
           pWissel->Wissel.Coord2X,
           pWissel->Wissel.Coord2Y,
           pWissel->Wissel.Coord3X,
           pWissel->Wissel.Coord3Y,
           &bString[1],
           sString,
           pWissel->Wissel.Lengte12,
           pWissel->Wissel.Lengte13,
           pWissel->Wissel.MaxSnelheid12, pWissel->Wissel.MaxSnelheid13);
}

void
StandaardWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
                        int selectionY, int deltaX, int deltaY)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (selectedWisselPoint == -1)
    {
      int afstand1, afstand2, x, y;
      afstand1 = SQR (pWissel->Wissel.Coord1X - selectionX) +
        SQR (pWissel->Wissel.Coord1Y - selectionY);
      if (pWissel->Stand == 12)
        {
          selectedWisselPoint = 2;
          x = pWissel->Wissel.Coord2X;
          y = pWissel->Wissel.Coord2Y;
        }
      else
        {
          selectedWisselPoint = 3;
          x = pWissel->Wissel.Coord3X;
          y = pWissel->Wissel.Coord3Y;
        }
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand1 < afstand2)
        {
          afstand2 = afstand1;
          selectedWisselPoint = 1;
        }
      x = pWissel->rec.center_x ();
      y = pWissel->rec.center_y ();
      afstand1 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand1 < afstand2)
        {
          selectedWisselPoint = 4;
        }

    }

  pWissel = &pInfo->IOBits[WisselNummer];
  switch (selectedWisselPoint)
    {
    case 1:
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      break;
    case 2:
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      break;
    case 3:
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      break;
    case 4:
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      break;
    }
  baanViewWin->baanBitmap->draw (pWissel->rec, pWissel->rec);
  StandaardWisselUpdateRec (pWissel);

  DisplayWissel (pInfo, WisselNummer, NULL);
}

void
StandaardWisselInitDialoog (class wisselInst * dialoog, int WisselNummer)
{
  int y;
  IOBits_t *pWissel;
  char string[20];

  pWissel = &baanInfo.IOBits[WisselNummer];
  y = 25;
  {
    fltk::Widget * o = dialoog->uitleg =
      new fltk::Widget (5, y += 25, 1, 200,
                        "12 is de rechte kant en 13 is buigend.\n"
                        "Een gebogen wissel 12 is de grote bocht en 13 is\n"
                        "de krappe bocht.\n"
                        "Een wissel kan op twee manieren liggen namelijk:\n"
                        "  Voorwaards         Achterwaards\n"
                        "       /----2--    --3----\n"
                        " -1---/                   /---1-\n"
                        "        ----3--    --2----/\n"
                        "Een voorwaardse wissel 3 is het volgende blok/wissel.\n"
                        "Een achterwaardse wissel 3 is B-1 deze wordt dan door\n"
                        "een andere wissel of baanvak ingevult (Wxxxx.yy)\n"
                        "Bij een negatieve lengte wordt de lengte van het\n"
                        "blok genomen\n");
    o->labelfont (fltk::COURIER);
    o->align (fltk::ALIGN_RIGHT);
    o->box (fltk::NO_BOX);
  }


  {
    fltk::Input * o = dialoog->aansluiting3 =
      new fltk::Input (130, y += 200, 65, 25, "Aansluiting3:");
    o->tooltip
      ("Gebruik de B/W/w notatie geef B-1 voor een wissel in tegen richting");
  }
  {
    fltk::IntInput * o = dialoog->lengte12 =
      new fltk::IntInput (130, y += 25, 65, 25, "lengte12 [cm]:");
    o->type (2);
    o->tooltip
      ("de lengte in stand 12. Geef -1 als de lengte van blok 1 correct is.");
  }
  {
    fltk::IntInput * o = dialoog->lengte13 =
      new fltk::IntInput (130, y += 25, 65, 25, "lengte13 [cm]:");
    o->type (2);
    o->tooltip
      ("de lengte in stand 13. Geef -1 als de lengte van blok 1 correct is.");
  }
  {
    fltk::IntInput * o = dialoog->Msnel12 =
      new fltk::IntInput (130, y += 25, 65, 25, "Max snelheid 12 [km/h]:");
    o->type (2);
    o->tooltip
      ("Geef de snelheid limitatie voor 12 stand. Geef -1 voor geen limiet.");
  }
  {
    fltk::IntInput * o = dialoog->Msnel13 =
      new fltk::IntInput (130, y += 25, 65, 25, "Max snelheid 13 [km/h]:");
    o->type (2);
    o->tooltip
      ("Geef de snelheid limitatie voor 13 stand. Geef -1 voor geen limiet.");
  }

  if (pWissel->Wissel.Richting)
    {
      sprintf (string, "B-1");
    }
  else
    {
      BlokNaam (string, pWissel->StopBlokPointer[0].blokRicht[0]);
    }
  dialoog->aansluiting3->value (string);

  dialoog->lengte12->value (pWissel->Wissel.Lengte12);
  dialoog->lengte13->value (pWissel->Wissel.Lengte13);
  dialoog->Msnel12->value (pWissel->Wissel.MaxSnelheid12);
  dialoog->Msnel13->value (pWissel->Wissel.MaxSnelheid13);
}

void
StandaardWisselDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;
  BlokPointer_t *wisselBlok;
  char blokType[2];
  float adres;
  int richting;

  pWissel = &baanInfo.IOBits[WisselNummer];

  pWissel->Wissel.Lengte12 = dialoog->lengte12->ivalue ();
  pWissel->Wissel.Lengte13 = dialoog->lengte13->ivalue ();
  pWissel->Wissel.MaxSnelheid12 = dialoog->Msnel12->ivalue ();
  pWissel->Wissel.MaxSnelheid13 = dialoog->Msnel13->ivalue ();


  // volgend blok gewijzigd
  if (sscanf
      (dialoog->aansluiting3->value (), "%1s%f", blokType, &adres) == 2)
    {
      wisselBlok = wisselKrijgPointer (&baanInfo, blokType[0], adres);
      if (wisselBlok == NULL)
        {
          fltk::message
            ("Het volgend blok bestaat niet %s",
             dialoog->aansluiting3->value ());
          // wijziging ongedaan gemaakt
        }
      else if (wisselBlok == pWissel->Wissel.pBlok1)
        {
          fltk::message
            ("Het volgend blok %s is hetzelfde als het wissel blok wijzing niet gedaan",
             dialoog->aansluiting3->value ());
        }
      else
        {
          // wisselBlok wijst naar een blok
          if (wisselBlok == &baanInfo.EindBlokPointer)
            {
              richting = 1;
            }
          else
            {
              richting = 0;
            }
          if ((richting != pWissel->Wissel.Richting) || (richting == 0))
            {

              BlokEndPointDelete (&(pWissel->StopBlokPointer[0]),
                                  pWissel->Wissel.Richting);

              pWissel->StopBlokPointer[0].blokRicht[richting] = wisselBlok;
              BlokEndPointInsert (&(pWissel->StopBlokPointer[0]), richting);
              pWissel->Wissel.Richting = richting;
            }

        }
    }
  else
    {
      fltk::message
        ("Blok %s op aansluiting 3 voldoet niet aan B/W/w notatie.",
         dialoog->aansluiting3->value ());
    }



}
