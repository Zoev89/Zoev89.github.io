// BaanWT.h: interface for the BaanWorkerThreadInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_STANDAARDWISSEL_H_)
#define _STANDAARDWISSEL_H_


int InitStandaardWissel (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayStandaardWissel (BaanInfo_t * pInfo, int WisselNummer);
int StandaardWisselAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand);
void StandaardWisselString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void 
StandaardWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer,int selectionX, int selectionY, int deltaX, int deltaY);
void
StandaardWisselInitDialoog (class wisselInst * dialoog, int WisselNummer);
void
StandaardWisselDialoogOk (class wisselInst * dialoog, int WisselNummer);


#endif // !defined(_BAANWT_H_)
