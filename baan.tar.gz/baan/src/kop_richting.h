#if !defined(AFX_KOP_RICHTING_H__F6BB77A1_728A_11D2_A616_444553540000__INCLUDED_)
#define AFX_KOP_RICHTING_H__F6BB77A1_728A_11D2_A616_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// kop_richting.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// kop_richting dialog

class kop_richting:public CDialog
{
// Construction
public:
  kop_richting (CWnd * pParent = NULL);	// standard constructor

// Dialog Data
  //{{AFX_DATA(kop_richting)
  enum
  { IDD = IDD_REG_KOP_RICHTING };
  CButton m_NeemKopBlokMee;
  CSliderCtrl m_VooruitTerug;
  int m_Kop;
  CString m_ErrorText;
  int m_Lengte;
  //}}AFX_DATA


// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(kop_richting)
protected:
    virtual void DoDataExchange (CDataExchange * pDX);	// DDX/DDV support
  //}}AFX_VIRTUAL

// Implementation
public:
  int m_Richting;
  int MaxBloks;			/* Deze moet gezet worden voor je DoModal doet */
  int NeemKopBlokMee;

protected:

  // Generated message map functions
  //{{AFX_MSG(kop_richting)
    virtual BOOL OnInitDialog ();
  afx_msg void OnHScroll (UINT nSBCode, UINT nPos, CScrollBar * pScrollBar);
  afx_msg void OnKopRichtingNeemMee ();
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP ()};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KOP_RICHTING_H__F6BB77A1_728A_11D2_A616_444553540000__INCLUDED_)
