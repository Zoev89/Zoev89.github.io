// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "ontkoppelaar.h"
#include "globalVars.h"
#include <time.h>
#include <stdio.h>
#include <fltk/ask.h>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int
InitOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer, char *Input)
{
  IOBits_t *pWissel;
  float floatAdres;

  /* Lees alle velden in */
  pWissel = &pInfo->IOBits[WisselNummer];
  if (sscanf (Input, "%d%f%d%d%d%d%d%d%d%d%d", &pWissel->Type, &floatAdres,     /* skip spoel nummer */
              &pWissel->Tijd,
              &pWissel->Ontkoppelaar.InactiefX1,
              &pWissel->Ontkoppelaar.InactiefY1,
              &pWissel->Ontkoppelaar.InactiefX2,
              &pWissel->Ontkoppelaar.InactiefY2,
              &pWissel->Ontkoppelaar.ActiefX1,
              &pWissel->Ontkoppelaar.ActiefY1,
              &pWissel->Ontkoppelaar.ActiefX2,
              &pWissel->Ontkoppelaar.ActiefY2) != 11)
    {
      return 1;
    }

  pWissel->hardwareAdres = (int) (floatAdres + 0.5);
  pWissel->hardwareBit =
    (int) ((floatAdres - (float) pWissel->hardwareAdres) * 100.0 + 0.5);

  pWissel->Stand = 0;           /* default Inactief */
  return 0;

}



void
DisplayOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];


  if (pWissel->Stand == 0)
    {
//            pInfo->pDC->MoveTo(pWissel->Ontkoppelaar.InactiefX1, pWissel->Ontkoppelaar.InactiefY1);
//            pInfo->pDC->LineTo(pWissel->Ontkoppelaar.InactiefX2, pWissel->Ontkoppelaar.InactiefY2);
    }
  else
    {
//            pInfo->pDC->MoveTo(pWissel->Ontkoppelaar.ActiefX1, pWissel->Ontkoppelaar.ActiefY1);
//            pInfo->pDC->LineTo(pWissel->Ontkoppelaar.ActiefX2, pWissel->Ontkoppelaar.ActiefY2);
    }


}

void
OntkoppelaarAanvraag (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;
  hardwareArray_t bedien;

  pWissel = &pInfo->IOBits[WisselNummer];

  if (pWissel->Stand == 0)
    {
      pWissel->Stand = 1;
      DisplayOntkoppelaar (pInfo, WisselNummer);
    }

  bedien.blokIO = HW_IO;
  bedien.adres = pWissel->hardwareAdres;
  bedien.data = pWissel->hardwareBit | IO_COMMAND3;
  bedien.nummer = WisselNummer;
  bedien.returnGewenst = 0;

  if (pInfo->hardwareHoog.nieuwItem (&bedien))
    {
      fltk::message ("hardware hoog vol info lost ontkoppelaar!");
    }

  pWissel->TijdTeller = pWissel->Tijd;  /* Initalizeer de bekrachtig tijd */

}


/* Test of er een verandering is aan de wisselspoel
** De routine geeft een 0 terug als er geen verandering is en een
** 1 als er een verandering plaats heeft gevonden.
**/
void
TestSpoelOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;
  hardwareArray_t bedien;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (pWissel->Stand == 1)
    {

      if (pWissel->TijdTeller > 0)
        {
          pWissel->TijdTeller -= 1;
        }
      else
        {
          if (pWissel->TijdTeller == 0)
            {
              bedien.blokIO = HW_IO;
              bedien.adres = pWissel->hardwareAdres;
              bedien.data = pWissel->hardwareBit | IO_COMMAND0;
              bedien.nummer = WisselNummer;
              bedien.returnGewenst = 0;

              if (pInfo->hardwareHoog.nieuwItem (&bedien))
                {
                  fltk::message ("hardware hoog vol info lost ontkoppelaar!");
                }
              pWissel->Stand = 0;
              DisplayOntkoppelaar (pInfo, WisselNummer);
            }
          else
            {
              /* Spoel oneindig bekrachtiged */
            }
        }
    }
}

void
OntkoppelaarString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];

  sprintf (string, "%d %7.2f %4d %4d %4d %4d %4d %4d %4d %4d %4d",
           pWissel->Type,
           WISSEL_ADRES,
           pWissel->Tijd,
           pWissel->Ontkoppelaar.InactiefX1,
           pWissel->Ontkoppelaar.InactiefY1,
           pWissel->Ontkoppelaar.InactiefX2,
           pWissel->Ontkoppelaar.InactiefY2,
           pWissel->Ontkoppelaar.ActiefX1,
           pWissel->Ontkoppelaar.ActiefY1,
           pWissel->Ontkoppelaar.ActiefX2, pWissel->Ontkoppelaar.ActiefY2);


}


void
OntkoppelaarInitDialoog (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &baanInfo.IOBits[WisselNummer];

  {
    fltk::IntInput * o = dialoog->Tijd =
      new fltk::IntInput (125, 50, 65, 25, "Tijd:");
    o->type (2);
    o->tooltip ("de tijd dat uitgang van ontkoppelaar actief is in 50ms.");
  }
  dialoog->Tijd->value (pWissel->Tijd);
}

void
OntkoppelaarDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &baanInfo.IOBits[WisselNummer];

  pWissel->Tijd = dialoog->Tijd->ivalue ();
}
