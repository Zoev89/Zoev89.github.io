#include "baanTypes.h"
#include "baanWT.h"
#include <string.h>
#include "fltk/Window.h"
#include "fltk/Browser.h"
#include "fltk/Item.h"





static
  fltk::Window *
  ioWin;
static
  fltk::Browser *
  ioTree;


static
  fltk::Widget *
addIo (fltk::Group * parent, const char *name, fltk::Image * image)
{
  parent->begin ();
  fltk::Item * o = new fltk::Item ();
  o->copy_label (name);
  o->align (fltk::ALIGN_LEFT | fltk::ALIGN_INSIDE | fltk::ALIGN_CLIP);
  if (image)
    o->image (image);
  return o;
}

void
baanOverzichtDestroy ()
{
  if (ioWin)
    {
      ioWin->destroy ();
      delete ioTree;
      delete ioWin;
      ioWin = NULL;
      ioTree = NULL;
    }

}

void
baanOverzicht (BaanInfo_t * pInfo)
{
  int i;
  int aantal[7];
  int blokken = 0;
  char inhoud[100];
  int laatsteBlok;

  memset (aantal, 0, sizeof (aantal));

  for (i = 1; i < MAX_NOBLOKS; i++)
    {
      if (pInfo->BlokPointer[i].BlokIONummer > 0)
        {
          // blok gebruikt dus tel op
          aantal[0] += pInfo->BlokPointer[i].Lengte;
          blokken += 1;
          laatsteBlok = i;
        }
    }

  // we zoeken alle spoelen af en maken een tabel per io controller
  for (i = 0; i < pInfo->AantalSpoelen; i++)
    {
      int Type;
      IOBits_t *pWissel;

      pWissel = &pInfo->IOBits[i];
      Type = pWissel->Type;
      aantal[Type] += 1;
    }

  // tabel opgebouwed nu het displayen

  if (NULL == ioWin)
    {
      // is nog niet erder aangeroepen dus creer het window
      int width = 350;
      int height = 200;
      ioWin = new fltk::Window (width, height, "baanOverzicht");
      ioWin->begin ();
      ioTree = new fltk::Browser (0, 0, width, height);
      ioTree->indented (0);
//      ioWin->resizable (ioTree);
      ioWin->end ();
      ioWin->set_non_modal ();
    }
  else
    {
      // vernietig de oude inhoud
      ioTree->clear ();
    }

  sprintf (inhoud, "%dm\trails", aantal[0] / 100);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tblokken", blokken);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tlampjes", aantal[6]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tontkoppelaars", aantal[1]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tstandaard wissels", aantal[2]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tkruisingen", aantal[3]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tengelse wissels", aantal[4]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tdrieweg wissels", aantal[5]);
  addIo (ioTree, inhoud, NULL);
  sprintf (inhoud, "%d\tTotaal wissels", aantal[5] + aantal[2] + aantal[4]);
  addIo (ioTree, inhoud, NULL);

  for (i = 1; i <= laatsteBlok; i++)
    {
      sprintf (inhoud, "blok %3d\t%s", i,
               (pInfo->BlokPointer[i].BlokIONummer >
                0) ? "Gebruikt" : "Vrij");
      addIo (ioTree, inhoud, NULL);
    }


  ioWin->show ();
}
