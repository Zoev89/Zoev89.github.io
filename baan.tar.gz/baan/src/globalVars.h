#ifndef _globalVars_h_
#define _globalVars_h_

#include "baanWindow.h"
#include "about.h"
#include "baanView.h"
#include "baanTypes.h"
#include "fltk/Window.h"
#include "fltk/Browser.h"

extern class baanWindow *baanWin;
extern class about      *aboutWin;
extern class baanView   *baanViewWin;

extern class fltk::Window *baanTreinenWin;
extern class fltk::Browser *baanTreinenTree;

#define MAX_FILENAME 1024

extern char blkDir[MAX_FILENAME];
extern char *blkName;

extern BaanInfo_t baanInfo;
extern char dirChar;
extern int
  regelaarTopX,
  regelaarTopY,
  regelaarBotX,
  regelaarBotY;

extern int editMode;
extern int selectedBlok;  // wordt alleen in editMode gebruikt
extern int selectedWissel;
extern int selectedWisselPoint,selectedWisselX,selectedWisselY;
extern int selectedOffsetX;
extern int selectedOffsetY;

 // offset voor de regelaars
#endif // _globalVars_h_

