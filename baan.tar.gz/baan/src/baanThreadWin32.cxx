#include "baanThread.h"
#include <stdio.h>
#include <windows.h>


struct _baanThread_t
{
  HANDLE thread;

};


pbaanThread_t baanThreadCreate(int timeCritical, void *(*start_routine) (void *)  , void *arg)
{
    pbaanThread_t thread  = new _baanThread_t;
	DWORD dwThreadId;
    if (thread == NULL) return NULL;

    thread->thread = CreateThread(NULL,0,
		(LPTHREAD_START_ROUTINE)start_routine, arg,0,&dwThreadId); //AfxBeginThread(start_routine, arg);


    if (timeCritical)
        SetThreadPriority(thread->thread,THREAD_PRIORITY_TIME_CRITICAL);
    return thread;
}

void baanThreadDestroy(pbaanThread_t thread)
{
    delete thread;
}
