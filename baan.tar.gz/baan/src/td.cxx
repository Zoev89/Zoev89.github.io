// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include <stdio.h>
#include <time.h>
#include <assert.h>
#include "td.h"

static int gId;
static int gAantalLogs;
static int gKop;
static int gStaart;
static int gLogging;
static int gStringId;

#define TD_MAX_NAMES 100

typedef enum
{
  TD_START,
  TD_STOP,
  TD_NAM,
  TD_DSC,
} tag_t;

typedef struct
{
  tag_t tag;
  int id;
  LongLong time;
} tdData_t, *ptdData_t;

typedef struct
{
  const char *string;
} tdNameData_t, *ptdNameData_t;
static tdNameData_t tdNameData[TD_MAX_NAMES];
static tdNameData_t tdStringData[TD_MAX_NAMES];

static ptdData_t gLogs;


/////////////////////////////////////////////////////////////////////////////

LongLong
readTSC (void)
{
  LongLong t;
#if defined(_WIN32)
  unsigned int a, b;
  unsigned int *c = (unsigned int *) &t;
  _asm
  {
    _emit 0x0f;
    _emit 0x31;
    mov a, eax;                 // low
    mov b, edx;                 // high
  }
  c[0] = a;
  c[1] = b;
#else
  unsigned int msec;
  struct timespec cur_time;

  clock_gettime (CLOCK_REALTIME, &cur_time);
  t =
    (LongLong) cur_time.tv_nsec +
    (LongLong) cur_time.tv_sec * (LongLong) 1000000000;
//  __asm__ volatile (".byte 0x0f,0x31":"=A" (t));
#endif

  return t;
}

LongLong
tdClock (int metDelta)
{
  static int vorigeClock;
  static double delta;
  LongLong t;

  t = readTSC ();
  {
    static LongLong save;
    if (save == 0)
      {
        save = t;
      }
    t = t - save;
  }
  return t;

}



void
tdInit (int aantalLogs)
{
  gLogs = new tdData_t[aantalLogs];
  if (gLogs != NULL)
    {
      gAantalLogs = aantalLogs;
      gKop = 0;
      gStaart = 0;
      gLogging = 1;
    }

}

void
tdUnInit ()
{
  if (gLogs != NULL)
    {
      delete gLogs;
      gLogs = NULL;
    }
}

void
tdCreate (int *id)
{
  *id = gId++;
}

void
tdName (int id, const char *string)
{
  assert (id < gId);
  if (id < TD_MAX_NAMES)
    {
      tdNameData[id].string = string;
    }
}

void
tdValueString (int *stringId, const char *string)
{
  *stringId = gStringId++;
  if (*stringId < TD_MAX_NAMES)
    {
      tdStringData[*stringId].string = string;
    }
}

void
tdValue (int id, int value)
{
  assert (id < gStringId);
  if (gLogging)
    {
      ptdData_t pLogs;

      pLogs = &gLogs[gKop++];
      if (gKop == gAantalLogs)
        {
          gKop = 0;
        }
      if (gKop == gStaart)
        {
          gStaart += 1;
          if (gStaart == gAantalLogs)
            {
              gStaart = 0;
            }
        }
      pLogs->tag = TD_DSC;
      pLogs->id = id;
      pLogs->time = value;
    }
}

void
tdStart (int id)
{
  if (gLogging)
    {
      ptdData_t pLogs;


      pLogs = &gLogs[gKop++];
      if (gKop == gAantalLogs)
        {
          gKop = 0;
        }
      if (gKop == gStaart)
        {
          gStaart += 1;
          if (gStaart == gAantalLogs)
            {
              gStaart = 0;
            }
        }
      pLogs->tag = TD_START;
      pLogs->id = id;
      pLogs->time = tdClock (0);
    }
}

void
tdStop (int id)
{
  if (gLogging)
    {
      ptdData_t pLogs;


      pLogs = &gLogs[gKop++];
      if (gKop == gAantalLogs)
        {
          gKop = 0;
        }
      if (gKop == gStaart)
        {
          gStaart += 1;
          if (gStaart == gAantalLogs)
            {
              gStaart = 0;
            }
        }
      pLogs->tag = TD_STOP;
      pLogs->id = id;
      pLogs->time = tdClock (1);

    }
}

void
tdDump ()
{
  FILE *file;
  int x, log;
  LongLong offset = 0;

  // schakel het loggen uit
  log = gLogging;
  gLogging = 0;
  file = fopen ("baan.tdi", "w");
  fprintf (file, "CPU x86\n");
  fprintf (file, "TIME 1000000000\n");  // tijd referentie in ns op linux
  fprintf (file, "SPEED 1000000000\n");
  fprintf (file, "MEMSPEED 1000\n");

  for (x = 0; x < gId; x++)
    {
      if (tdNameData[x].string != NULL)
        {
          fprintf (file, "NAM 0 %d %s\n", x, tdNameData[x].string);
        }
    }
  for (x = 0; x < gStringId; x++)
    {
      if (tdStringData[x].string != NULL)
        {
          fprintf (file, "DNM 0 %d %s\n", x, tdStringData[x].string);
        }
    }

  // alleen als er een logging was
  offset = gLogs[gStaart].time;
  for (x = 0; (x < gAantalLogs) && (gStaart != gKop); x++)
    {
      ptdData_t pLogs;

      pLogs = &gLogs[gStaart++];
      if (gStaart == gAantalLogs)
        {
          gStaart = 0;
        }

      switch (pLogs->tag)
        {
        case TD_START:
          fprintf (file, "STA 0 %d %-10.9lg\n", pLogs->id,
                   (double) (pLogs->time - offset));
          break;
        case TD_STOP:
          fprintf (file, "STO 0 %d %-10.9lg\n", pLogs->id,
                   (double) (pLogs->time - offset));
          break;
        case TD_DSC:
          fprintf (file, "DSC 0 %d %lg\n", pLogs->id, (double) pLogs->time);

        }
    }
  fprintf (file, "END\n");
  fclose (file);
  gStaart = 0;
  gKop = 0;
  gLogging = log;
}
