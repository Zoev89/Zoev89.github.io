// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.

#include "baan.h"
#include "baanTypes.h"
#include "baanWT.h"
#include "wissel.h"
#include "driewegWissel.h"
#include "baanMessage.h"
#include "leesdata.h"
#include "globalVars.h"
#include "blok.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fltk/ask.h>
#include <fltk/draw.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
static void
DriewegWisselUpdateRec (IOBits_t * pWissel)
{
  int i;

  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X < i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X < i)
    i = pWissel->Wissel.Coord3X;
  if (pWissel->Wissel.Coord4X < i)
    i = pWissel->Wissel.Coord4X;
  pWissel->rec.x (i - 3);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y < i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y < i)
    i = pWissel->Wissel.Coord3Y;
  if (pWissel->Wissel.Coord4Y < i)
    i = pWissel->Wissel.Coord4Y;
  pWissel->rec.y (i - 3);
  i = (pWissel->Wissel.Coord1X);
  if (pWissel->Wissel.Coord2X > i)
    i = pWissel->Wissel.Coord2X;
  if (pWissel->Wissel.Coord3X > i)
    i = pWissel->Wissel.Coord3X;
  if (pWissel->Wissel.Coord4X > i)
    i = pWissel->Wissel.Coord4X;
  pWissel->rec.w (i - pWissel->rec.x () + 3);
  i = (pWissel->Wissel.Coord1Y);
  if (pWissel->Wissel.Coord2Y > i)
    i = pWissel->Wissel.Coord2Y;
  if (pWissel->Wissel.Coord3Y > i)
    i = pWissel->Wissel.Coord3Y;
  if (pWissel->Wissel.Coord4Y > i)
    i = pWissel->Wissel.Coord4Y;
  pWissel->rec.h (i - pWissel->rec.y () + 3);
}


int
InitDriewegWissel (BaanInfo_t * pInfo, int WisselNummer, char *Input)
{
  /* Deze init routine belegt gebruikt voor:
   ** 2  spoel + 0
   ** 3  spoel + 1
   ** 4  spoel + 2
   ** Dus als een wissel wil aansluiten op 4 dan moet die w inplaats van W 
   ** geven en dan nemen we het stopblok van spoel + 2
   **/
  IOBits_t *pWissel;
  float floatAdres;
  int Blok1;
  char Blok2Type[2];
  char Blok4Type[2];
  float adres2;
  float adres4;

  BlokPointer_t *pBlok2, *pBlok4;

  /* Lees alle velden in */
  pWissel = &pInfo->IOBits[WisselNummer];
  if (sscanf
      (Input, "%d%f%d%d%d%d%d%d%d%d%d%1s%f%1s%f%d%d%d%d%d%d",
       &pWissel->Type, &floatAdres,
       &pWissel->Wissel.Coord1X,
       &pWissel->Wissel.Coord1Y,
       &pWissel->Wissel.Coord2X,
       &pWissel->Wissel.Coord2Y,
       &pWissel->Wissel.Coord3X,
       &pWissel->Wissel.Coord3Y,
       &pWissel->Wissel.Coord4X,
       &pWissel->Wissel.Coord4Y, &Blok1, Blok2Type, &adres2,
       Blok4Type, &adres4,
       &pWissel->Wissel.Lengte12,
       &pWissel->Wissel.Lengte13,
       &pWissel->Wissel.Lengte14,
       &pWissel->Wissel.MaxSnelheid12,
       &pWissel->Wissel.MaxSnelheid13, &pWissel->Wissel.MaxSnelheid14) != 21)
    return WISSEL_ERR_NIET_ALLES_AANWEZIG;

  if (adres2 == -1)
    {
      pWissel->Wissel.Richting = 1;
    }
  else
    {
      pWissel->Wissel.Richting = 0;
    }

  if ((Blok1 < HARDWARE_MIN_ADRES) || (Blok1 >= MAX_NOBLOKS))
    {
      return WISSEL_ERR_INVALID_ADRES;
    }
  if (pInfo->BlokPointer[Blok1].BlokIONummer == -1)
    {
      return WISSEL_ERR_INVALID_ADRES;
    }
  pWissel->Wissel.pBlok1 = &pInfo->BlokPointer[Blok1];

  pBlok2 = wisselKrijgPointer (pInfo, Blok2Type[0], adres2);
  if (pBlok2 == NULL)
    return WISSEL_ERR_INVALID_ADRES;
  pBlok4 = wisselKrijgPointer (pInfo, Blok4Type[0], adres4);
  if (pBlok4 == NULL)
    return WISSEL_ERR_INVALID_ADRES;

  pWissel->Stand = 13;          /* default wijzen we naar 3 */

  /* Controleer of de maximum snelheid gebruikt wordt */
  if (pWissel->Wissel.MaxSnelheid13 >= 0)
    {
      /* omdat deze maximum snelheid gebruikt wordt zet hem op de baan */
      pWissel->Wissel.pBlok1->pBlok->MaxSnelheid =
        pWissel->Wissel.MaxSnelheid13;
    }


  /* stand is 13 dus init baan lengte */
  if (pWissel->Wissel.Lengte13 >= 0)
    pWissel->Wissel.pBlok1->Lengte = pWissel->Wissel.Lengte13;

  if (pWissel->Wissel.Richting == 0)
    {
      /* de richting is voorwaards */
      // check of 2 vrij is
      if (&pInfo->EindBlokPointer != pWissel->StopBlokPointer[0].pVolgendBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 2 is al aangesloten met blok %d\n%s\nRichting misschien fout of aansluiting 2 met 3,4 verwisseld?",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit,
             pWissel->StopBlokPointer[0].pVolgendBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }

      if (&pInfo->EindBlokPointer != pBlok2->pVorigBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 2 is het volgend blok zijn TERUG weg al belegd met blok %d\n%s",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit, pBlok2->pVorigBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }

      // check of 4 vrij is
      if (&pInfo->EindBlokPointer != pWissel->StopBlokPointer[2].pVolgendBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 4 is al aangesloten met blok %d\n%s\nRichting misschien fout of aansluiting 2 met 3,4 verwisseld?",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit,
             pWissel->StopBlokPointer[2].pVolgendBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }

      if (&pInfo->EindBlokPointer != pBlok4->pVorigBlok)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 4 is het volgend blok zijn TERUG weg al belegd met blok %d\n%s",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit, pBlok2->pVorigBlok->BlokIONummer, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }
      pWissel->StopBlokPointer[0].pVolgendBlok = pBlok2;
      pWissel->StopBlokPointer[1].pVolgendBlok =
        pWissel->Wissel.pBlok1->pVolgendBlok;
      pWissel->StopBlokPointer[2].pVolgendBlok = pBlok4;
      pBlok2->pVorigBlok = &pWissel->StopBlokPointer[0];
      pBlok4->pVorigBlok = &pWissel->StopBlokPointer[2];
    }
  else
    {
      /* de richting is achteruit */
      pWissel->StopBlokPointer[1].pVorigBlok =
        pWissel->Wissel.pBlok1->pVorigBlok;
      // maar aansluiting 2 moet er al zijn dus die controleren we
      if (pWissel->Wissel.pBlok1->pVolgendBlok == &pInfo->EindBlokPointer)
        {
          // we hebben een probleem
          fltk::message
            ("Regel %d: Van Wissel %d.%02d aansluiting 3 is nog niet aangesloten dit had in de blok sectie al gedaan moeten zijn\n%s",
             EricFgetsGetLastLineCount (), pWissel->hardwareAdres,
             pWissel->hardwareBit, Input);
          return WISSEL_ERR_MESSAGE_AL_GEGEVEN;
        }
    }

  DriewegWisselUpdateRec (pWissel);
  return 0;

}




void
DisplayDriewegWissel (BaanInfo_t * pInfo, int WisselNummer)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];

  fltk::line_style (fltk::SOLID, 5);
  if (WisselNummer == selectedWissel)
    {
      fltk::setcolor ((fltk::Color) (fltk::RED));
    }
  else
    {
      fltk::setcolor ((fltk::Color) (fltk::BLACK));
    }



  if (pWissel->Stand == 12)
    {

      fltk::drawline (pWissel->Wissel.Coord1X,
                      pWissel->Wissel.Coord1Y,
                      pWissel->Wissel.Coord2X, pWissel->Wissel.Coord2Y);


    }
  else
    {
      if (pWissel->Stand == 13)
        {
          fltk::drawline (pWissel->Wissel.Coord1X,
                          pWissel->Wissel.Coord1Y,
                          pWissel->Wissel.Coord3X, pWissel->Wissel.Coord3Y);


        }
      else
        {
          fltk::drawline (pWissel->Wissel.Coord1X,
                          pWissel->Wissel.Coord1Y,
                          pWissel->Wissel.Coord4X, pWissel->Wissel.Coord4Y);

        }
    }
}

void
DriewegWisselBedien (BaanInfo_t * pInfo, IOBits_t * pWissel, int WisselNummer)
{
  hardwareArray_t bedien;


  bedien.blokIO = HW_IO;
  bedien.adres = pWissel->hardwareAdres;
  bedien.data = pWissel->hardwareBit;   // default IO_COMMAND0
  bedien.nummer = WisselNummer;
  bedien.returnGewenst = 0;

  if (pWissel->Stand == 12)
    {
      // wissel gebogen
      bedien.data |= IO_COMMAND3;
    }
  if (pInfo->hardwareHoog.nieuwItem (&bedien))
    {
      fltk::message ("hardware hoog vol info lost drieweg wissel!");
    }

  bedien.data = pWissel->hardwareBit + 1;       // default IO_COMMAND0
  if (pWissel->Stand == 14)
    {
      // wissel gebogen
      bedien.data |= IO_COMMAND3;
    }
  if (pInfo->hardwareHoog.nieuwItem (&bedien))
    {
      fltk::message ("hardware hoog vol info lost drieweg wissel!");
    }
}

int
DriewegWisselAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand)
{
  IOBits_t *pWissel;
  int NieuweStand;
  BlokPointer_t *pBlok1, *pBlokOld, *pBlokOldStop, *pBlokNieuw,
    *pBlokNieuwStop;
  int RegelaarNummer;
  int MaxSnelheid;
  int Lengte;
  int richting;
  int tegenRichting;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (IOAANVRAAG_REFRESH == stand)
    {
      DriewegWisselBedien (pInfo, pWissel, WisselNummer);
      return 0;
    }

  if (IOAANVRAAG_DEFAULT == stand)
    {
      stand = 13;
    }


  pBlok1 = pWissel->Wissel.pBlok1;
  if ((pBlok1->pBlok->State != BLOK_VRIJ) && (pBlok1->pBlok->Snelheid != 0))
    {
      return IOGEWIJGERD;
    }

  richting = pWissel->Wissel.Richting;
  tegenRichting = (richting + 1) & 1;

  // TODO de standaardWissel geeft eventueel het check blok vrij
  // Deze doet dat nog niet
  RegelaarNummer = pBlok1->pBlok->RegelaarNummer;


  /* de richting is voorwaards */

  pBlokOld = pBlok1->blokRicht[richting];

  if ((pBlok1->pBlok->State != BLOK_VRIJ) &&
      (RegelaarNummer == pBlokOld->pBlok->RegelaarNummer))
    {
      return IOGEWIJGERD;       /* wissel + huidig blok zijn bezet met dezelfde regelaar */
    }

  if (((pBlokOld->pBlok->State & BLOK_BEZET_MASK) != BLOK_VRIJ) &&
      (pBlokOld->pBlok->Snelheid != 0))
    {
      return IOGEWIJGERD;       /* Wissel is bezet dus niet omschakelen */
    }

  if (stand == IOAANVRAAG_TOGGLE)
    {
      NieuweStand = pWissel->Stand + 1;
      if (NieuweStand > 14)
        {
          NieuweStand = 12;
        }
    }
  else
    {
      // test of de stand binnen bereik ligt
      if ((stand < 12) || (stand > 14))
        return IOGEWIJGERD;
      NieuweStand = stand;
    }

  if (NieuweStand == pWissel->Stand)
    return 0;                   /* Zelfde stand gewenst */

  switch (pWissel->Stand)
    {
    case 12:
      pBlokOldStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[0];
      break;
    case 13:
      pBlokOldStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[1];
      break;
    case 14:
      pBlokOldStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[2];
      break;
    }
  /* Richting is vooruit */
  switch (NieuweStand)
    {
    case 12:
      pBlokNieuwStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[0];
      break;
    case 13:
      pBlokNieuwStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[1];
      break;
    case 14:
      pBlokNieuwStop = &pInfo->IOBits[WisselNummer].StopBlokPointer[2];
      break;
    }
  pBlokNieuw = pBlokNieuwStop->blokRicht[richting];


  pBlok1->blokRicht[richting] = pBlokNieuw;
  pBlokNieuw->blokRicht[tegenRichting] = pBlok1;
  pBlokOld->blokRicht[tegenRichting] = pBlokOldStop;
  pBlokOldStop->blokRicht[richting] = pBlokOld;

  pWissel->Stand = NieuweStand;

  switch (NieuweStand)
    {
    case 12:
      MaxSnelheid = pWissel->Wissel.MaxSnelheid12;
      Lengte = pWissel->Wissel.Lengte12;
      break;
    case 13:
      MaxSnelheid = pWissel->Wissel.MaxSnelheid13;
      Lengte = pWissel->Wissel.Lengte13;
      break;
    case 14:
      MaxSnelheid = pWissel->Wissel.MaxSnelheid14;
      Lengte = pWissel->Wissel.Lengte14;
      break;
    }
  if (MaxSnelheid >= 0)
    pBlok1->pBlok->MaxSnelheid = MaxSnelheid;

  /* Zet de lengte info */
  if (Lengte >= 0)
    pBlok1->Lengte = Lengte;

  DriewegWisselBedien (pInfo, pWissel, WisselNummer);
  baanMessagePost (WM_WISSEL_DISPLAY, WisselNummer, 0, 0);
  return 0;
}

void
DriewegWisselString (BaanInfo_t * pInfo, int WisselNummer, char *string)
{
  IOBits_t *pWissel;
  char s1String[20];
  char s2String[20];
  char bString[20];

  pWissel = &pInfo->IOBits[WisselNummer];

  if (pWissel->Wissel.Richting)
    {
      // richting terug
      strcpy (s1String, "B-1");
      strcpy (s2String, "B-1");
    }
  else
    {
      BlokNaam (s1String, pWissel->StopBlokPointer[0].pVolgendBlok);
      BlokNaam (s2String, pWissel->StopBlokPointer[2].pVolgendBlok);
    }
  BlokNaam (bString, pWissel->Wissel.pBlok1);

  sprintf (string,
           "%d %7.2f %4d %4d %4d %4d %4d %4d %4d %4d %8s %8s %8s %4d %4d %4d %4d %4d %4d",
           pWissel->Type,
           WISSEL_ADRES,
           pWissel->Wissel.Coord1X,
           pWissel->Wissel.Coord1Y,
           pWissel->Wissel.Coord2X,
           pWissel->Wissel.Coord2Y,
           pWissel->Wissel.Coord3X,
           pWissel->Wissel.Coord3Y,
           pWissel->Wissel.Coord4X,
           pWissel->Wissel.Coord4Y,
           &bString[1],
           s1String,
           s2String,
           pWissel->Wissel.Lengte12,
           pWissel->Wissel.Lengte13,
           pWissel->Wissel.Lengte14,
           pWissel->Wissel.MaxSnelheid12,
           pWissel->Wissel.MaxSnelheid13, pWissel->Wissel.MaxSnelheid14);

}

void
DriewegWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
                      int selectionY, int deltaX, int deltaY)
{
  IOBits_t *pWissel;

  pWissel = &pInfo->IOBits[WisselNummer];
  if (selectedWisselPoint == -1)
    {
      int afstand1, afstand2, x, y;
      afstand1 = SQR (pWissel->Wissel.Coord1X - selectionX) +
        SQR (pWissel->Wissel.Coord1Y - selectionY);
      switch (pWissel->Stand)
        {
        case 12:
          selectedWisselPoint = 2;
          x = pWissel->Wissel.Coord2X;
          y = pWissel->Wissel.Coord2Y;
          break;
        case 13:
          selectedWisselPoint = 3;
          x = pWissel->Wissel.Coord3X;
          y = pWissel->Wissel.Coord3Y;
          break;
        case 14:
          selectedWisselPoint = 4;
          x = pWissel->Wissel.Coord4X;
          y = pWissel->Wissel.Coord4Y;
          break;
        }
      afstand2 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand1 < afstand2)
        {
          afstand2 = afstand1;
          selectedWisselPoint = 1;
        }
      x = pWissel->rec.center_x ();
      y = pWissel->rec.center_y ();
      afstand1 = SQR (x - selectionX) + SQR (y - selectionY);
      if (afstand1 < afstand2)
        {
          selectedWisselPoint = 5;
        }

    }

  pWissel = &pInfo->IOBits[WisselNummer];
  switch (selectedWisselPoint)
    {
    case 1:
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      break;
    case 2:
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      break;
    case 3:
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      break;
    case 4:
      pWissel->Wissel.Coord4X += deltaX;
      pWissel->Wissel.Coord4Y += deltaY;
      break;
    case 5:
      pWissel->Wissel.Coord1X += deltaX;
      pWissel->Wissel.Coord1Y += deltaY;
      pWissel->Wissel.Coord2X += deltaX;
      pWissel->Wissel.Coord2Y += deltaY;
      pWissel->Wissel.Coord3X += deltaX;
      pWissel->Wissel.Coord3Y += deltaY;
      pWissel->Wissel.Coord4X += deltaX;
      pWissel->Wissel.Coord4Y += deltaY;
      break;
    }
  baanViewWin->baanBitmap->draw (pWissel->rec, pWissel->rec);
  DriewegWisselUpdateRec (pWissel);

  DisplayWissel (pInfo, WisselNummer, NULL);
}

void
DriewegWisselInitDialoog (class wisselInst * dialoog, int WisselNummer)
{
  int y;
  IOBits_t *pWissel;
  char string[20];

  pWissel = &baanInfo.IOBits[WisselNummer];
  y = 25;
  {
    fltk::Widget * o = dialoog->uitleg =
      new fltk::Widget (3, y += 25, 1, 200,
                        "13 is de rechte kant\n"
                        "Een wissel kan op twee manieren liggen namelijk:\n"
                        "  Voorwaards         Achterwaards\n"
                        "       /----2--      --4----\n"
                        " -1---/  ---3--      --3---  /---1-\n"
                        "        ----4--      --2----/\n"
                        "13 word door de blok database gedaan.\n"
                        "Voorwaardse wissel 2 en 4 is het volgende blok/wissel.\n"
                        "Achterwaardse wissel 2 en 4 is B-1 deze wordt dan\n"
                        "door een andere wissel of baanvak ingevult\n"
                        "2=Wxxxx.yy en 4=wxxxx.yy\n"
                        "Bij een negatieve lengte wordt de lengte van het\n"
                        "blok genomen.\n");
    o->labelfont (fltk::COURIER);
    o->align (fltk::ALIGN_RIGHT);
    o->box (fltk::NO_BOX);
  }



  {
    fltk::Input * o = dialoog->aansluiting2 =
      new fltk::Input (90, y += 200, 55, 25, "Aansluiting2:");
    o->tooltip
      ("Gebruik de B/W/w notatie geef B-1 voor een wissel in tegen richting");
  }
  {
    fltk::Input * o = dialoog->aansluiting4 =
      new fltk::Input (280, y, 55, 25, "Aansluiting4:");
    o->tooltip
      ("Gebruik de B/W/w notatie geef B-1 voor een wissel in tegen richting");
  }
  {
    fltk::IntInput * o = dialoog->lengte12 =
      new fltk::IntInput (90, y += 25, 55, 25, "lengte12 [cm]:");
    o->type (2);
    o->tooltip
      ("de lengte in stand 12. Geef -1 als de lengte van blok 1 correct is.");
  }
  {
    fltk::IntInput * o = dialoog->lengte13 =
      new fltk::IntInput (90, y += 25, 55, 25, "lengte13 [cm]:");
    o->type (2);
    o->tooltip
      ("de lengte in stand 13. Geef -1 als de lengte van blok 1 correct is.");
  }
  {
    fltk::IntInput * o = dialoog->lengte14 =
      new fltk::IntInput (90, y += 25, 55, 25, "lengte14 [cm]:");
    o->type (2);
    o->tooltip
      ("de lengte in stand 13. Geef -1 als de lengte van blok 1 correct is.");
  }
  {
    fltk::IntInput * o = dialoog->Msnel12 =
      new fltk::IntInput (280, y -= 50, 55, 25, "Max snelheid 12 [km/h]:");
    o->type (2);
    o->tooltip
      ("Geef de snelheid limitatie voor 12 stand. Geef -1 voor geen limiet.");
  }
  {
    fltk::IntInput * o = dialoog->Msnel13 =
      new fltk::IntInput (280, y += 25, 55, 25, "Max snelheid 13 [km/h]:");
    o->type (2);
    o->tooltip
      ("Geef de snelheid limitatie voor 13 stand. Geef -1 voor geen limiet.");
  }
  {
    fltk::IntInput * o = dialoog->Msnel14 =
      new fltk::IntInput (280, y += 25, 55, 25, "Max snelheid 14 [km/h]:");
    o->type (2);
    o->tooltip
      ("Geef de snelheid limitatie voor 14 stand. Geef -1 voor geen limiet.");
  }

  if (pWissel->Wissel.Richting)
    {
      sprintf (string, "B-1");
    }
  else
    {
      BlokNaam (string, pWissel->StopBlokPointer[0].blokRicht[0]);
    }
  dialoog->aansluiting2->value (string);

  if (pWissel->Wissel.Richting)
    {
      sprintf (string, "B-1");
    }
  else
    {
      BlokNaam (string, pWissel->StopBlokPointer[2].blokRicht[0]);
    }
  dialoog->aansluiting4->value (string);

  dialoog->lengte12->value (pWissel->Wissel.Lengte12);
  dialoog->lengte13->value (pWissel->Wissel.Lengte13);
  dialoog->lengte14->value (pWissel->Wissel.Lengte14);
  dialoog->Msnel12->value (pWissel->Wissel.MaxSnelheid12);
  dialoog->Msnel13->value (pWissel->Wissel.MaxSnelheid13);
  dialoog->Msnel14->value (pWissel->Wissel.MaxSnelheid14);
}

void
DriewegWisselDialoogOk (class wisselInst * dialoog, int WisselNummer)
{
  IOBits_t *pWissel;
  BlokPointer_t *wisselBlok2;
  BlokPointer_t *wisselBlok4;
  char blokType[2];
  float adres;
  int richting;

  pWissel = &baanInfo.IOBits[WisselNummer];

  pWissel->Wissel.Lengte12 = dialoog->lengte12->ivalue ();
  pWissel->Wissel.Lengte13 = dialoog->lengte13->ivalue ();
  pWissel->Wissel.Lengte14 = dialoog->lengte14->ivalue ();
  pWissel->Wissel.MaxSnelheid12 = dialoog->Msnel12->ivalue ();
  pWissel->Wissel.MaxSnelheid13 = dialoog->Msnel13->ivalue ();
  pWissel->Wissel.MaxSnelheid14 = dialoog->Msnel14->ivalue ();

  wisselBlok2 = wisselBlok4 = NULL;

  if (sscanf
      (dialoog->aansluiting2->value (), "%1s%f", blokType, &adres) == 2)
    {
      wisselBlok2 = wisselKrijgPointer (&baanInfo, blokType[0], adres);
    }
  else
    {
      fltk::message
        ("Blok %s op aansluiting 2 voldoet niet aan B/W/w notatie.",
         dialoog->aansluiting2->value ());
    }
  if (sscanf
      (dialoog->aansluiting4->value (), "%1s%f", blokType, &adres) == 2)
    {
      wisselBlok4 = wisselKrijgPointer (&baanInfo, blokType[0], adres);
    }
  else
    {
      fltk::message
        ("Blok %s op aansluiting 4 voldoet niet aan B/W/w notatie.",
         dialoog->aansluiting2->value ());
    }

  if (wisselBlok2 == NULL)
    {
      fltk::message
        ("Het volgend blok %s aanluiting 2 bestaat niet %s",
         dialoog->aansluiting2->value ());
      // wijziging ongedaan gemaakt
    }
  if (wisselBlok4 == NULL)
    {
      fltk::message
        ("Het volgend blok %s aanluiting 4 bestaat niet %s",
         dialoog->aansluiting4->value ());
      // wijziging ongedaan gemaakt
    }

  if (wisselBlok2 == pWissel->Wissel.pBlok1)
    {
      fltk::message
        ("Het volgend blok %s aansluiting 2 is hetzelfde als het wissel blok wijzing niet gedaan",
         dialoog->aansluiting2->value ());
      wisselBlok2 = NULL;
    }
  if (wisselBlok4 == pWissel->Wissel.pBlok1)
    {
      fltk::message
        ("Het volgend blok %s aansluiting 4 is hetzelfde als het wissel blok wijzing niet gedaan",
         dialoog->aansluiting4->value ());
      wisselBlok4 = NULL;
    }



  if ((wisselBlok2 != NULL) && (wisselBlok4 != NULL))
    {
      // wisselBlok wijst naar een blok
      if ((wisselBlok2 == &baanInfo.EindBlokPointer) &&
          (wisselBlok4 == &baanInfo.EindBlokPointer))
        {
          richting = 1;
        }
      else
        {
          richting = 0;
        }
      if ((richting != pWissel->Wissel.Richting) || (richting == 0))
        {

          BlokEndPointDelete (&(pWissel->StopBlokPointer[0]),
                              pWissel->Wissel.Richting);

          pWissel->StopBlokPointer[0].blokRicht[richting] = wisselBlok2;
          BlokEndPointInsert (&(pWissel->StopBlokPointer[0]), richting);

          BlokEndPointDelete (&(pWissel->StopBlokPointer[2]),
                              pWissel->Wissel.Richting);

          pWissel->StopBlokPointer[2].blokRicht[richting] = wisselBlok4;
          BlokEndPointInsert (&(pWissel->StopBlokPointer[2]), richting);

          pWissel->Wissel.Richting = richting;
        }

    }
}
