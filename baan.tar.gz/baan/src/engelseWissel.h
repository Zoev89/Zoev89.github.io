#if !defined(_ENGELSE_WISSEL_H_)
#define _ENGELSE_WISSEL_H_


int InitEngelseWissel (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayEngelseWissel (BaanInfo_t * pInfo, int WisselNummer);
int EngelseWisselAanvraag (BaanInfo_t * pInfo, int WisselNummer, int stand);
void EngelseWisselString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void EngelseWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer,int selectionX, int selectionY, int deltaX, int deltaY);
void EngelseWisselInitDialoog (class wisselInst * dialoog, int WisselNummer);
void EngelseWisselDialoogOk (class wisselInst * dialoog, int WisselNummer);


#endif // !defined(_ENGELSE_WISSEL_H_)
