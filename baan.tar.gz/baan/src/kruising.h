#if !defined(_KRUISING_H_)
#define _KRUISING_H_


int InitKruising (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayKruising (BaanInfo_t * pInfo, int WisselNummer);
void KruisingString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void KruisingWisselNieuwXY (BaanInfo_t * pInfo, int WisselNummer, int selectionX,
		      int selectionY, int deltaX, int deltaY);
void KruisingWisselInitDialoog (class wisselInst * dialoog, int WisselNummer);
void KruisingWisselDialoogOk (class wisselInst * dialoog, int WisselNummer);


#endif // !defined(_KRUISING_H_)
