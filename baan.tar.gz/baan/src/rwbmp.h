int LoadBitmapFile (char *pFileName, CBitmap * pBitmap);
