// BaanWT.h: interface for the BaanWorkerThreadInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_BAANWT_H_)
#define _BAANWT_H_

#include "baanTypes.h"

#define BLOK_VRIJ           0x00	// Vrij te gebruiken
#define BLOK_VOORUIT        0x05 
#define BLOK_ACHTERUIT      0x06        // BLOK_ACHTERUIT = BLOK_VOORUIT +1 hou dit
#define BLOK_VOORUITCHECK   0x07	// Het blok waar de trein in gaat komen
#define BLOK_ACHTERUITCHECK 0x08	// Het blok waar de trein in gaat komen
#define BLOK_STOP           0xf0	// Gebruikt voor eind blokken
#define BLOK_BEZET_MASK     0x0f

#define HARDWARE_MIN_ADRES    1
#define HARDWARE_MAX_ADRES 1023

#define HARDWARE_IO_LSB_BITNUMMER 0
#define HARDWARE_IO_MSB_BITNUMMER 15

#define HW_POS   1		// default gebruik de pInfo->vooruit/achteruit voor de actuele waarde
#define HW_NEG   2
#define HW_SEIN_GROEN 61
#define HW_SEIN_GEEL  62
#define HW_SEIN_ROOD  63

#define IO_COMMAND0 0
#define IO_COMMAND1 (1<<4)
#define IO_COMMAND2 (2<<4)
#define IO_COMMAND3 (3<<4)


#define MAX_SNELHEID 1000


#define ONTKOPPELAAR     1
#define STANDAARD_WISSEL 2
#define KRUISING         3
#define ENGELSE_WISSEL   4
#define DRIEWEG_WISSEL   5
#define LAMP             6
#define LAATSTE_ENTRY    7  // wordt gebruikt de blk file te saven.

#define DOT_SIZE          6	// grootte van de dot van een bezet blok
#define KLEINE_DOT_SIZE   4	// grootte van de dot van een check blok
#define RESET_SIZE 16

void DrawRect ();

void ericSleep (int tijd);

void DisplayBlok ();
int InitWissel (BaanInfo_t * pInfo, char *Input, int WisselNummer);
void InitWorkThread (BaanInfo_t * pInfo);
void GeefBlokVrij (BaanInfo_t * pInfo, BlokPointer_t * pBlok);

void * BaanWorkerThreadProc (void *arg);

#endif // !defined(_BAANWT_H_)
