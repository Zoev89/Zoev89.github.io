#include "baanTypes.h"
#include "baanWT.h"
#include <string.h>
#include "fltk/Window.h"
#include "fltk/Browser.h"
#include "fltk/Item.h"

#define AANTALIO 40




static
  fltk::Window *
  foutWin;
static
  fltk::Browser *
  foutTree;


static
  fltk::Widget *
addIo (fltk::Group * parent, const char *name, fltk::Image * image)
{
  parent->begin ();
  fltk::Item * o = new fltk::Item ();
  o->copy_label (name);
  o->align (fltk::ALIGN_LEFT | fltk::ALIGN_INSIDE | fltk::ALIGN_CLIP);
  if (image)
    o->image (image);
  return o;
}

void
foutStatistiekDestroy ()
{
  if (foutWin)
    {
      foutWin->destroy ();
      delete foutTree;
      delete foutWin;
      foutWin = NULL;
      foutTree = NULL;
    }
}

void
foutStatistiek (BaanInfo_t * pInfo)
{
  int i, p;



  if (NULL == foutWin)
    {
      // is nog niet erder aangeroepen dus creer het window
      int width = 500;
      int height = 200;
      int widths[] = { 70, 100, 0 };
      foutWin = new fltk::Window (width, height, "Fouten");
      foutWin->begin ();
      foutTree = new fltk::Browser (0, 0, width, height);
      foutTree->indented (0);
      foutTree->column_widths (widths);
      // foutWin->resizable (foutTree);
      foutWin->end ();
      foutWin->set_non_modal ();
    }
  else
    {
      // vernietig de oude inhoud
      foutTree->clear ();
    }


  addIo (foutTree, "BLOK\taantal fouten", NULL);
  for (i = 0; i < MAX_NOBLOKS; i++)
    {
      char inhoud[100];

      if (pInfo->BlokPointer[i].BlokIONummer != -1)
        {
          int total;
          total = 0;
          // dit blok wordt gebruikt 
          for (p = 0; p < MAX_AANTAL_REGELAARS; p++)
            {
              if (pInfo->RegelArray[p].Gebruikt)
                {
                  total += pInfo->RegelArray[p].Regel.aantalFouten[i];
                }
            }
          if (total)
            {
              sprintf (inhoud, "%d\t%d", i, total);
              addIo (foutTree, inhoud, NULL);
            }
        }

    }
  foutWin->show ();
}
