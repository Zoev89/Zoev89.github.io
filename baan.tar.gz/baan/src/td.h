// Baan: A railway model controlling program
// Copyright (C) 1998 - 2001 Eric Kathmann
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston,
// MA  02111-1307, USA.
#ifndef TD_H
#define TD_H

/////////////////////////////////////////////////////////////////////////////
// 

#ifdef _WIN32
typedef _int64 LongLong;
#else
typedef long long LongLong;
#endif

void tdInit (int aantalLogs);
void tdUnInit ();

void tdCreate (int *id);
// verbing een naam met een id
void tdName (int id, const char *string);

void tdStart (int id);
void tdStop (int id);
void tdDump ();

void tdValueString (int *stringId, const char *string);
// print een getal in de logging
// precondition is het aanmelden met tdValueString
void tdValue (int stringId, int value);
LongLong readTSC (void);

#endif // TD_H

