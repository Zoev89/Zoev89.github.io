#ifndef _baanView_h_
#define _baanView_h_

//#include <FL/Fl_Widget.H>
#include <fltk/Widget.h>
#include <fltk/SharedImage.h>
#include "baanQueue.h"

class baanView : public fltk::Widget {
  void draw();
  int handle(int event);
public:
  baanView(int X,int Y,int W,int H,const char* L);
  int loadBitmap(char *filename);
  fltk::SharedImage * baanBitmap;
  pbaanQueue_t baanViewMessage;
  void Update();
private:
  void baanViewBlokXY(int blok,int x,int y);
};

#endif // _baanView_h_

