// BaanWT.h: interface for the BaanWorkerThreadInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ONTKOPPELAAR_H_)
#define _ONTKOPPELAAR_H_


int InitOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer, char *Input);
void DisplayOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer);
void OntkoppelaarAanvraag (BaanInfo_t * pInfo, int WisselNummer);
void TestSpoelOntkoppelaar (BaanInfo_t * pInfo, int WisselNummer);
void OntkoppelaarString(BaanInfo_t *pInfo, int WisselNummer, char *string);
void OntkoppelaarInitDialoog (class wisselInst * dialoog, int WisselNummer);
void OntkoppelaarDialoogOk (class wisselInst * dialoog, int WisselNummer);


#endif // !defined(_ONTKOPPELAAR_H_)
