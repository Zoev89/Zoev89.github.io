#ifndef FOUTSTATISTIEK_H
#define FOUTSTATISTIEK_H

#include "baanTypes.h"

void foutStatistiek(BaanInfo_t *pInfo);
void foutStatistiekDestroy();

#endif
